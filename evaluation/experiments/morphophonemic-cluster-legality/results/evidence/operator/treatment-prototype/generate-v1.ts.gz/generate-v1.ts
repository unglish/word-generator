import { repairFinalNuclei } from "./final-nucleus.js";
import { FinalSpelling } from "./final-spelling.js";
import { FinalPhones } from "./final-phones.js";
import { finalizeMorphologySpelling } from "./morphology/finalize.js";
import { ClusterContext, Phoneme, WordGenerationContext, WordGenerationOptions, Word, Syllable, SyllableShapePlan, GenerationMode } from "../types.js";
import { RNG, createSeededRng, createDefaultRng } from "../utils/random.js";
import getWeightedOption from "../utils/getWeightedOption.js";
import { LanguageConfig, computeSonorityLevels, defaultFallbackBridgeOnsets, validateConfig, ClusterLimits, SonorityConstraints, expandClusterConstraintBans, ResolvedStressRules, resolveStressRules, resolveAspirationRules } from "../config/language.js";
import { englishConfig } from "../config/english.js";
import { applyStress, generatePronunciation, PronunciationRuntimeConfig } from "./pronounce.js";
import { createWrittenFormGenerator } from "./write.js";
import { createGapSpellingApplicator } from "./gap-spelling.js";
import { classifySspViolation, hasRisingCodaTowardBoundary, validateJunction } from "./junction.js";
import { repairClusters, repairFinalCoda, repairClusterShape, repairHAfterBackVowel } from "./repair.js";
import { repairStressedNuclei } from "./stress-repair.js";
import { planMorphology, prepareMorphology, writeMorphology } from "./morphology/index.js";
import { cloneSyllables } from "./lexical.js";
import {
  computePhonemeTargetBounds,
  derivePhonemeTargets,
  getPlannedMorphologyPhonemeDelta,
  scoreGenerationAttempt,
  resolveMorphologyPhonemeDelta,
} from "./length-semantics.js";
import { TraceCollector } from "./trace.js";
import { clusterCandidateRejection, getClusterWeightMap, findClusterWeightMultiplier, NO_CLUSTER_WEIGHT } from "./cluster-validation.js";
import { maximumCodaLength } from "./coda-shape.js";
import { isStop } from "../utils/phonemes.js";

// ---------------------------------------------------------------------------
// Runtime: pre-computed data derived from a LanguageConfig
// ---------------------------------------------------------------------------

interface GeneratorRuntime {
  config: LanguageConfig;
  resolvedStress: ResolvedStressRules;
  resolvedPronunciation: PronunciationRuntimeConfig;
  sonorityLevels: Map<Phoneme, number>;
  /** Sonority level by phoneme sound string (for quick lookup). */
  sonorityBySound: Map<string, number>;
  /** Phoneme by sound string (avoids repeated config.phonemes.find). */
  phonemeBySound: Map<string, Phoneme>;
  positionPhonemes: { onset: Phoneme[]; coda: Phoneme[]; nucleus: Phoneme[] };
  invalidClusterRegexes: {
    onset: RegExp | null;
    coda: RegExp | null;
    /** Maps to config.invalidClusters.boundary — keyed "nucleus" because
     *  ClusterContext.position uses "nucleus" as the catch-all third position. */
    nucleus: RegExp | null;
  };
  generateWrittenForm: (context: WordGenerationContext) => void;
  applyGapSpellings: (context: WordGenerationContext) => void;
  bannedSet?: Set<string>;
  clusterRepair?: "drop-coda" | "drop-onset";
  allowedFinalSet?: Set<string>;
  bannedCodaSet?: Set<string>;
  /** Map from nucleus sound to set of banned coda sounds. */
  bannedNucleusCodaMap?: Map<string, Set<string>>;
  clusterLimits?: ClusterLimits;
  sonorityConstraints?: SonorityConstraints;
  codaAppendantSet?: Set<string>;
  onsetPrependerSet?: Set<string>;
  sonorityExemptSet?: Set<string>;
  attestedOnsetSet?: Set<string>;
  attestedCodaSet?: Set<string>;
  attestedOnsetPrefixSet?: Set<string>;
  attestedCodaPrefixSet?: Set<string>;
  clusterWeights?: {
    onset?: Map<string, number>;
    coda?: Map<string, number> | {
      final?: Map<string, number>;
      nonFinal?: Map<string, number>;
    };
  };
  /** Pre-resolved bridge phoneme options for vowel hiatus repair. */
  bridgePhonemeOptions: [Phoneme, number][];
}

const DEFAULT_PLAN_GUARD_PROBABILITY = 98;
const DEFAULT_POST_VOWEL_GLIDE_MULTIPLIER = 0.08;

/**
 * Fast boolean probability check — equivalent to
 * `getWeightedOption([[true, p], [false, 100 - p]], rand)`
 * but avoids allocating two tuple arrays per call.
 */
function coinFlip(rand: RNG, probability: number): boolean {
  return rand() * 100 < probability;
}
/** Shared empty set for ClusterContext.ignoreSet when no phonemes should be ignored. */
const _emptySet: ReadonlySet<string> = Object.freeze(new Set<string>());

function getPlanGuardProbability(rt: GeneratorRuntime): number {
  return rt.config.hiatusPolicy?.planGuardProbability ?? DEFAULT_PLAN_GUARD_PROBABILITY;
}

function getPostVowelGlideMultiplier(rt: GeneratorRuntime): number {
  return rt.config.hiatusPolicy?.postVowelGlideMultiplier ?? DEFAULT_POST_VOWEL_GLIDE_MULTIPLIER;
}

/** Build a set of all proper prefixes for attested clusters (excludes the full key). */
function buildPrefixSet(clusters: string[][]): Set<string> {
  const set = new Set<string>();
  for (const parts of clusters) {
    for (let i = 1; i < parts.length; i++) {
      set.add(parts.slice(0, i).join("|"));
    }
  }
  return set;
}

function buildRuntime(config: LanguageConfig): GeneratorRuntime {
  validateConfig(config);
  const sonorityLevels = computeSonorityLevels(config);
  const resolvedStress = resolveStressRules(config.pronunciation.stress);
  const resolvedPronunciation: PronunciationRuntimeConfig = {
    aspiration: resolveAspirationRules(config.pronunciation.aspiration),
    vowelReduction: config.pronunciation.vowelReduction,
  };

  const positionPhonemes = {
    onset: Array.from(config.phonemeMaps.onset.values()).flat(),
    coda: Array.from(config.phonemeMaps.coda.values()).flat(),
    nucleus: Array.from(config.phonemeMaps.nucleus.values()).flat(),
  };

  const makeRegex = (patterns: string[]) =>
    patterns.length > 0 ? new RegExp(patterns.join("|"), "i") : null;

  const invalidClusterRegexes = {
    onset: makeRegex(config.invalidClusters.onset),
    coda: makeRegex(config.invalidClusters.coda),
    nucleus: makeRegex(config.invalidClusters.boundary),
  };

  const generateWrittenForm = createWrittenFormGenerator(config);
  const applyGapSpellings = createGapSpellingApplicator(config);

  const bannedPairs = expandClusterConstraintBans(config);
  const bannedSet = bannedPairs.length > 0
    ? new Set(bannedPairs.map(([a, b]) => `${a}|${b}`))
    : undefined;

  const sonorityBySound = new Map<string, number>();
  const phonemeBySound = new Map<string, Phoneme>();
  for (const [phoneme, level] of sonorityLevels) {
    sonorityBySound.set(phoneme.sound, level);
    phonemeBySound.set(phoneme.sound, phoneme);
  }

  const cl = config.clusterLimits;
  const sc = config.sonorityConstraints;

  // Build cluster weight maps from config
  const clusterWeights = config.clusterWeights ? {
    onset: config.clusterWeights.onset ? new Map(Object.entries(config.clusterWeights.onset)) : undefined,
    coda: config.clusterWeights.coda ? (
      // Check if position-based format (has 'final' or 'nonFinal' keys)
      typeof config.clusterWeights.coda === "object" &&
      ("final" in config.clusterWeights.coda || "nonFinal" in config.clusterWeights.coda)
        ? {
          final: config.clusterWeights.coda.final ? new Map(Object.entries(config.clusterWeights.coda.final)) : undefined,
          nonFinal: config.clusterWeights.coda.nonFinal ? new Map(Object.entries(config.clusterWeights.coda.nonFinal)) : undefined,
        }
        : new Map(Object.entries(config.clusterWeights.coda as Record<string, number>))
    ) : undefined,
  } : undefined;

  // Build banned nucleus+coda map for efficient lookup during coda selection
  const bannedNucleusCodaMap = config.codaConstraints?.bannedNucleusCodaCombinations
    ? (() => {
      const map = new Map<string, Set<string>>();
      for (const { nucleus, coda } of config.codaConstraints.bannedNucleusCodaCombinations) {
        for (const n of nucleus) {
          if (!map.has(n)) map.set(n, new Set());
          for (const c of coda) {
              map.get(n)!.add(c);
          }
        }
      }
      return map;
    })()
    : undefined;

  // Pre-resolve bridge phoneme options for vowel hiatus repair
  const bridgePairs = config.hiatusPolicy?.fallbackBridgeOnsets ?? defaultFallbackBridgeOnsets();
  const bridgePhonemeOptions: [Phoneme, number][] = [];
  for (const [sound, weight] of bridgePairs) {
    const p = phonemeBySound.get(sound);
    if (p && weight > 0) bridgePhonemeOptions.push([p, weight]);
  }

  return {
    config,
    resolvedStress,
    resolvedPronunciation,
    sonorityLevels,
    sonorityBySound,
    phonemeBySound,
    positionPhonemes,
    invalidClusterRegexes,
    generateWrittenForm,
    applyGapSpellings,
    bannedSet,
    clusterRepair: config.clusterConstraint?.repair,
    allowedFinalSet: config.codaConstraints?.allowedFinal
      ? new Set(config.codaConstraints.allowedFinal)
      : undefined,
    bannedCodaSet: config.codaConstraints?.bannedCodas
      ? new Set(config.codaConstraints.bannedCodas)
      : undefined,
    bannedNucleusCodaMap,
    clusterLimits: cl,
    sonorityConstraints: sc,
    codaAppendantSet: cl?.codaAppendants ? new Set(cl.codaAppendants) : undefined,
    onsetPrependerSet: cl?.onsetPrependers ? new Set(cl.onsetPrependers) : undefined,
    sonorityExemptSet: sc?.exempt ? new Set(sc.exempt) : undefined,
    attestedOnsetSet: cl?.attestedOnsets
      ? new Set(cl.attestedOnsets.map(a => a.join("|")))
      : undefined,
    attestedCodaSet: cl?.attestedCodas
      ? new Set(cl.attestedCodas.map(a => a.join("|")))
      : undefined,
    attestedOnsetPrefixSet: cl?.attestedOnsets
      ? buildPrefixSet(cl.attestedOnsets)
      : undefined,
    attestedCodaPrefixSet: cl?.attestedCodas
      ? buildPrefixSet(cl.attestedCodas)
      : undefined,
    clusterWeights,
    bridgePhonemeOptions,
  };
}

// ---------------------------------------------------------------------------
// Sonority
// ---------------------------------------------------------------------------

function getSonority(rt: GeneratorRuntime, phoneme: Phoneme): number {
  return rt.sonorityLevels.get(phoneme) ?? 0;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Cluster building
// ---------------------------------------------------------------------------

function buildCluster(rt: GeneratorRuntime, context: ClusterContext): Phoneme[] {
  const allPositionPhonemes = rt.positionPhonemes[context.position];
  // Reusable buffer for valid candidates — avoids allocating a new array each iteration.
  const validBuf: Phoneme[] = [];

  while (context.cluster.length < context.maxLength) {
    validBuf.length = 0;
    for (let i = 0; i < allPositionPhonemes.length; i++) {
      if (isValidCandidate(allPositionPhonemes[i], rt, context)) {
        validBuf.push(allPositionPhonemes[i]);
      }
    }
    if (validBuf.length === 0) break;

    const newPhoneme = selectPhoneme(validBuf, context, rt);
    if (!newPhoneme) break;

    context.cluster.push(newPhoneme);
    context.clusterSounds.push(newPhoneme.sound);
    if (shouldStopClusterGrowth(context, rt)) break;
  }

  return context.cluster;
}

function isValidCandidate(p: Phoneme, rt: GeneratorRuntime, context: ClusterContext): boolean {
  return clusterCandidateRejection(p, rt, context) === undefined;
}

function isValidCluster(rt: GeneratorRuntime, cluster: Phoneme[], position: "onset" | "coda" | "nucleus"): boolean {
  const regex = rt.invalidClusterRegexes[position];
  if (!regex) return true;
  let potentialCluster = "";
  for (let i = 0; i < cluster.length; i++) potentialCluster += cluster[i].sound;
  return !regex.test(potentialCluster);
}

// ---------------------------------------------------------------------------
// Sonority checks
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Phoneme selection
// ---------------------------------------------------------------------------

function selectPhoneme(validCandidates: Phoneme[], context: ClusterContext, rt?: GeneratorRuntime): Phoneme | null {
  const { position, isStartOfWord, isEndOfWord, rand, clusterSounds } = context;

  // Pre-compute cluster weight map once for all candidates
  let weightMap: Map<string, number> | undefined;
  if (rt && (clusterSounds.length > 0 || context.maxLength >= 2) && rt.clusterWeights) {
    const weightsForPosition = position === "onset" ? rt.clusterWeights.onset : rt.clusterWeights.coda;
    if (weightsForPosition) {
      weightMap = getClusterWeightMap(weightsForPosition, isEndOfWord);
    }
  }

  const applyGlide = position === "onset" && context.followingOpenNucleus && clusterSounds.length === 0;
  const glideMultiplier = applyGlide
    ? (rt ? getPostVowelGlideMultiplier(rt) : DEFAULT_POST_VOWEL_GLIDE_MULTIPLIER)
    : 1;

  const weightedCandidates: [Phoneme, number][] = new Array(validCandidates.length);
  for (let i = 0; i < validCandidates.length; i++) {
    const p = validCandidates[i];
    const positionWeight = p[position] ?? 0;
    const wordPositionModifier =
      (isStartOfWord && p.startWord) ||
      (isEndOfWord && p.endWord) ||
      p.midWord || 1;

    let baseWeight = positionWeight * wordPositionModifier;

    if (weightMap) {
      const multiplier = findClusterWeightMultiplier(clusterSounds, p.sound, weightMap);
      if (multiplier !== NO_CLUSTER_WEIGHT) {
        baseWeight *= multiplier;
      }
    }

    if (applyGlide && (p.sound === "j" || p.sound === "w")) {
      baseWeight *= glideMultiplier;
    }

    weightedCandidates[i] = [p, baseWeight];
  }

  return getWeightedOption(weightedCandidates, rand);
}

function shouldStopClusterGrowth(context: ClusterContext, rt: GeneratorRuntime): boolean {
  const { position, cluster } = context;

  // Check cluster length limits
  if (rt.clusterLimits) {
    const cl = rt.clusterLimits;
    if (position === "onset" && cluster.length >= cl.maxOnset) return true;
    if (position === "coda") {
      const effectiveMax = maximumCodaLength(cluster[cluster.length - 1]?.sound ?? "", cl, rt.codaAppendantSet);
      if (cluster.length >= effectiveMax) return true;
    }
  }

  // For onsets with attested whitelist: stop if current cluster is an exact match
  // and no longer attested onset extends it
  if (position === "onset" && rt.attestedOnsetSet && cluster.length >= 2) {
    const key = context.clusterSounds.join("|");
    if (rt.attestedOnsetSet.has(key)) {
      const hasLonger = rt.attestedOnsetPrefixSet?.has(key) ?? false;
      if (!hasLonger) return true;
    }
  }

  // For codas with attested whitelist: stop if current cluster is an exact match
  // and no longer attested coda extends it
  if (position === "coda" && rt.attestedCodaSet && cluster.length >= 2) {
    const key = context.clusterSounds.join("|");
    if (rt.attestedCodaSet.has(key)) {
      const hasLonger = rt.attestedCodaPrefixSet?.has(key) ?? false;
      if (!hasLonger) return true;
    }
  }

  return false;
}

// ---------------------------------------------------------------------------
// Syllable picking
// ---------------------------------------------------------------------------

function pickOnset(
  rt: GeneratorRuntime,
  context: WordGenerationContext,
  isStartOfWord: boolean,
  monosyllabic: boolean,
  targetLength?: number,
): Phoneme[] {
  const prevSyllable = context.word.syllables[context.currSyllableIndex - 1];
  const isFollowingNucleus = prevSyllable && prevSyllable.coda.length === 0;
  const syllableCount = context.syllableCount;
  const { onsetLength } = rt.config.generationWeights;

  const rand = context.rand;
  const polysyllabicWeights = isFollowingNucleus
    ? onsetLength.followingNucleus
    : (syllableCount >= 3 && onsetLength.long) ? onsetLength.long : onsetLength.default;
  const maxLength = targetLength ?? (monosyllabic
    ? getWeightedOption(onsetLength.monosyllabic, rand)
    : getWeightedOption(polysyllabicWeights, rand));

  if (maxLength === 0) return [];

  const toIgnore = prevSyllable ? new Set(prevSyllable.coda.map((coda) => coda.sound)) : _emptySet;

  return buildCluster(rt, {
    rand,
    position: "onset",
    cluster: [],
    clusterSounds: [],
    ignoreSet: toIgnore,
    isStartOfWord,
    isEndOfWord: false,
    syllableCount,
    maxLength,
    followingOpenNucleus: !!isFollowingNucleus,
  });
}

function pickNucleus(rt: GeneratorRuntime, context: WordGenerationContext, isStartOfWord: boolean, isEndOfWord: boolean): Phoneme[] {
  return buildCluster(rt, {
    rand: context.rand,
    position: "nucleus",
    cluster: [],
    clusterSounds: [],
    ignoreSet: _emptySet,
    isStartOfWord,
    isEndOfWord,
    maxLength: 1,
    syllableCount: context.syllableCount,
  });
}

function codaExtensionRejection(candidate: Phoneme, rt: GeneratorRuntime, context: ClusterContext): CodaExtensionRejectionReason | undefined {
  const reason = clusterCandidateRejection(candidate, rt, context);
  if (reason) return reason;
  if (!rt.clusterLimits && context.cluster.length + 1 > rt.config.syllableStructure.maxCodaLength) return "length";
  if (rt.allowedFinalSet && !rt.allowedFinalSet.has(candidate.sound)) return "word-final";
  // A completed extension must be licensed itself, not merely lead toward a
  // longer listed cluster which this operation will never finish building.
  if (rt.attestedCodaSet && context.cluster.length > 0) {
    const completed = [...context.clusterSounds, candidate.sound].join("|");
    if (!rt.attestedCodaSet.has(completed)) return "attestation";
  }
  return undefined;
}

function canExtendCoda(
  candidate: Phoneme,
  rt: GeneratorRuntime,
  clusterContext: ClusterContext,
  context: WordGenerationContext,
  extension: "finalS" | "nasalStopExtension",
): boolean {
  const reason = codaExtensionRejection(candidate, rt, clusterContext);
  if (!reason) return true;
  context.trace?.recordStructural({
    event: "codaExtensionRejected",
    extension,
    candidate: candidate.sound,
    coda: [...clusterContext.clusterSounds],
    reason,
    syllableIndex: context.currSyllableIndex,
  });
  return false;
}

function appendCoda(candidate: Phoneme, context: ClusterContext): void {
  context.cluster.push(candidate);
  context.clusterSounds.push(candidate.sound);
}

function pickCoda(
  rt: GeneratorRuntime,
  context: WordGenerationContext,
  newSyllable: Syllable,
  isEndOfWord: boolean,
  monosyllabic: boolean,
  targetLength?: number,
): Phoneme[] {
  // In plan-driven mode (targetLength set), suppress count-mutating extensions
  // when the coda already matches the plan. This avoids burning retries on
  // overshoots while still allowing mutations when the cluster builder
  // under-fills (giving mutations a chance to close the gap).
  const planDriven = targetLength !== undefined;
  const syllableCount = context.syllableCount;
  const onsetLen = newSyllable.onset.length;
  const { codaLength, probability } = rt.config.generationWeights;

  const weights: [number, number][] = monosyllabic
    ? (codaLength.monosyllabic[onsetLen] ?? codaLength.monosyllabicDefault)
    : [
      [0, isEndOfWord ? codaLength.zeroWeightEndOfWord : codaLength.zeroWeightMidWord],
      ...codaLength.polysyllabicNonzero,
    ];

  const rand = context.rand;
  const maxLength: number = targetLength ?? getWeightedOption(weights, rand);
  if (maxLength === 0) return [];

  const codaContext: ClusterContext = {
    rand: context.rand,
    position: "coda",
    cluster: [],
    clusterSounds: [],
    ignoreSet: _emptySet,
    isStartOfWord: false,
    isEndOfWord,
    syllableCount,
    maxLength,
    nucleus: newSyllable.nucleus,
  };
  const coda = buildCluster(rt, codaContext);

  // Extend word-final singleton nasal codas with their voiced homorganic stop
  // In plan-driven mode, allow mutations when coda under-filled OR exactly at
  // target (since mutations close the gap toward the phoneme count target —
  // the outer loop will reject if the total overshoots).
  const nasalExt = probability.nasalStopExtension ?? 0;
  const allowMutations = !planDriven || coda.length <= targetLength;
  if (allowMutations && isEndOfWord && nasalExt > 0 && coda.length === 1 &&
      coda[0].mannerOfArticulation === "nasal" &&
      coinFlip(rand, nasalExt)) {
    const nasal = coda[0];
    const stops = rt.positionPhonemes.coda.filter(candidate =>
      isStop(candidate) && candidate.voiced && candidate.placeOfArticulation === nasal.placeOfArticulation
      && canExtendCoda(candidate, rt, codaContext, context, "nasalStopExtension"));
    if (stops.length > 0) {
      const stop = stops.length === 1 ? stops[0] : selectPhoneme(stops, codaContext, rt);
      if (stop) {
        appendCoda(stop, codaContext);
        context.trace?.recordStructural({
          event: "nasalStopExtension",
          nasal: nasal.sound,
          appendedStop: stop.sound,
          probability: nasalExt,
          syllableIndex: context.currSyllableIndex,
        });
      }
    }
  }

  // Add 's' to the end of the last syllable occasionally
  if (allowMutations && isEndOfWord) {
    let finalSProbability = probability.finalS;
    let shouldSkipFinalS = false;
    
    // Apply cluster-specific weight if appending /s/ would create a weighted cluster
    if (coda.length > 0 && rt.clusterWeights?.coda) {
      const weightMap = getClusterWeightMap(rt.clusterWeights.coda, isEndOfWord);
      
      const weight = findClusterWeightMultiplier(codaContext.clusterSounds, "s", weightMap);
      if (weight !== NO_CLUSTER_WEIGHT) {
        finalSProbability *= weight;
        shouldSkipFinalS = weight < 0.01;
      }
    }
    
    if (!shouldSkipFinalS && coinFlip(rand, finalSProbability)) {
      const sPhoneme = rt.positionPhonemes.coda.find(phoneme => phoneme.sound === "s");
      if (sPhoneme && canExtendCoda(sPhoneme, rt, codaContext, context, "finalS")) {
        appendCoda(sPhoneme, codaContext);
        const clusterWeightApplied = finalSProbability !== probability.finalS;
        context.trace?.recordStructural({
          event: "finalS",
          probability: finalSProbability,
          clusterWeightApplied: clusterWeightApplied || undefined,
          clusterWeight: clusterWeightApplied && probability.finalS > 0
            ? finalSProbability / probability.finalS
            : undefined,
          syllableIndex: context.currSyllableIndex,
        });
      }
    }
  }

  return coda;
}

// ---------------------------------------------------------------------------
// Boundary adjustment
// ---------------------------------------------------------------------------

/**
 * Adjusts two adjacent syllables based on sonority and phonological rules.
 *
 * Two checks, applied in sequence:
 * 1. Equal-sonority boundary drop (original): 90% chance to drop coda-final
 *    when it has the same fine-grained sonority as the onset-initial.
 * 2. Full-cluster SSP validation: if the combined coda+onset cluster violates
 *    the Sonority Sequencing Principle (using coarse manner-class groupings),
 *    drop coda phonemes until the cluster is valid. This prevents impossible
 *    consonant clusters from ever reaching the write phase.
 */
function adjustBoundary(
  rt: GeneratorRuntime,
  prevSyllable: Syllable,
  currentSyllable: Syllable,
  rand: RNG,
  rightSyllableIndex: number,
  trace?: TraceCollector,
): [Syllable, Syllable] {
  const leftSyllableIndex = rightSyllableIndex - 1;
  const lastCodaPhoneme = prevSyllable.coda.at(-1);
  const firstOnsetPhoneme = currentSyllable.onset[0];

  if (!lastCodaPhoneme || !firstOnsetPhoneme) return [prevSyllable, currentSyllable];

  // Check 1: equal-sonority probabilistic drop (fine-grained levels)
  const lastCodaSonority = getSonority(rt, lastCodaPhoneme);
  const firstOnsetSonority = getSonority(rt, firstOnsetPhoneme);
  const { equalSonorityDrop, risingCodaDrop } = rt.config.generationWeights.boundaryPolicy;
  if (firstOnsetSonority === lastCodaSonority && coinFlip(rand, equalSonorityDrop)) {
    trace?.recordStructural({
      event: "boundaryDrop",
      dropped: lastCodaPhoneme.sound,
      beforeOnset: firstOnsetPhoneme.sound,
      equalSonority: lastCodaSonority,
      probability: equalSonorityDrop,
      leftSyllableIndex,
      rightSyllableIndex,
    });
    prevSyllable.coda.pop();
  }

  // Check 2: rising-coda probabilistic drop (coarse manner-class levels)
  if (
    prevSyllable.coda.length > 0 &&
    currentSyllable.onset.length > 0 &&
    hasRisingCodaTowardBoundary(prevSyllable.coda, rt.config) &&
    coinFlip(rand, risingCodaDrop)
  ) {
    const preDropCoda = prevSyllable.coda.map(p => p.sound);
    const dropped = prevSyllable.coda.pop()!;
    trace?.recordStructural({
      event: "risingCodaBoundaryDrop",
      dropped: dropped.sound,
      preDropCoda,
      remainingCoda: prevSyllable.coda.map(p => p.sound),
      onset: currentSyllable.onset.map(p => p.sound),
      probability: risingCodaDrop,
      leftSyllableIndex,
      rightSyllableIndex,
    });
  }

  // Check 3: full junction validation safety loop.
  // Drop coda-final phonemes until boundary junction is valid or coda is empty.
  const maxDrops = prevSyllable.coda.length;
  for (let d = 0; d < maxDrops; d++) {
    if (prevSyllable.coda.length === 0) break;
    if (validateJunction(prevSyllable.coda, currentSyllable.onset, rt.config)) break;
    const violation = classifySspViolation(prevSyllable.coda, currentSyllable.onset, rt.config);
    const preDropCoda = prevSyllable.coda.map(p => p.sound);
    const dropped = prevSyllable.coda.pop()!;
    if (violation) {
      trace?.recordStructural({
        event: "sspBoundaryDrop",
        dropped: dropped.sound,
        preDropCoda,
        remainingCoda: prevSyllable.coda.map(p => p.sound),
        onset: currentSyllable.onset.map(p => p.sound),
        violation,
        leftSyllableIndex,
        rightSyllableIndex,
      });
      continue;
    }
    trace?.recordStructural({
      event: "junctionBoundaryDrop",
      dropped: dropped.sound,
      preDropCoda,
      remainingCoda: prevSyllable.coda.map(p => p.sound),
      onset: currentSyllable.onset.map(p => p.sound),
      leftSyllableIndex,
      rightSyllableIndex,
    });
  }

  return [prevSyllable, currentSyllable];
}

// ---------------------------------------------------------------------------
// Syllable generation
// ---------------------------------------------------------------------------

function getOnsetLengthWeights(
  rt: GeneratorRuntime,
  syllableCount: number,
  prevCodaLength: number,
): [number, number][] {
  const { onsetLength } = rt.config.generationWeights;
  if (syllableCount === 1) return onsetLength.monosyllabic;
  if (prevCodaLength === 0) return onsetLength.followingNucleus;
  if (syllableCount >= 3 && onsetLength.long) return onsetLength.long;
  return onsetLength.default;
}

function getCodaLengthWeights(
  rt: GeneratorRuntime,
  syllableCount: number,
  onsetLen: number,
  isEndOfWord: boolean,
): [number, number][] {
  const { codaLength } = rt.config.generationWeights;
  if (syllableCount === 1) {
    return codaLength.monosyllabic[onsetLen] ?? codaLength.monosyllabicDefault;
  }
  return [
    [0, isEndOfWord ? codaLength.zeroWeightEndOfWord : codaLength.zeroWeightMidWord],
    ...codaLength.polysyllabicNonzero,
  ];
}

function getLengthWeight(weights: [number, number][], length: number): number {
  return weights.find(([len]) => len === length)?.[1] ?? 0.0001;
}

function getTopDownPhonemeLengthWeights(rt: GeneratorRuntime, mode: GenerationMode): [number, number][] {
  const weights = rt.config.phonemeLengthWeights[mode];
  if (!weights?.length) {
    throw new Error(`Missing phonemeLengthWeights.${mode} in language config`);
  }
  return weights;
}

function getTopDownSyllableWeights(rt: GeneratorRuntime, mode: GenerationMode, phonemeCount: number): [number, number][] {
  const table = rt.config.phonemeToSyllableWeights[mode];
  if (!table) {
    throw new Error(`Missing phonemeToSyllableWeights.${mode} in language config`);
  }
  const weights = table[phonemeCount];
  if (!weights?.length) {
    throw new Error(`Missing phonemeToSyllableWeights.${mode}.${phonemeCount} in language config`);
  }
  return weights;
}

function sampleTargetPhonemeCount(
  rt: GeneratorRuntime,
  mode: GenerationMode,
  rand: RNG,
  forcedSyllableCount?: number,
): number {
  const allWeights = getTopDownPhonemeLengthWeights(rt, mode);
  if (!forcedSyllableCount) return getWeightedOption(allWeights, rand);

  const maxOnset = rt.clusterLimits?.maxOnset ?? rt.config.syllableStructure.maxOnsetLength;
  const maxCoda = rt.clusterLimits?.maxCoda ?? rt.config.syllableStructure.maxCodaLength;
  // +1 provides headroom for rare plan overshoots (e.g. repair passes).
  const maxPhonemes = forcedSyllableCount + forcedSyllableCount * (maxOnset + maxCoda) + 1;

  const filtered = allWeights.filter(([phonemeCount]) =>
    phonemeCount >= forcedSyllableCount && phonemeCount <= maxPhonemes,
  );
  const pool = filtered.length > 0 ? filtered : allWeights;
  return getWeightedOption(pool, rand);
}

function sampleSyllableCountForTarget(
  rt: GeneratorRuntime,
  mode: GenerationMode,
  targetPhonemes: number,
  rand: RNG,
  forcedSyllableCount?: number,
): number {
  if (forcedSyllableCount && forcedSyllableCount > 0) return forcedSyllableCount;

  const maxOnset = rt.clusterLimits?.maxOnset ?? rt.config.syllableStructure.maxOnsetLength;
  const maxCoda = rt.clusterLimits?.maxCoda ?? rt.config.syllableStructure.maxCodaLength;
  const canSatisfy = (syllableCount: number) => {
    const maxPhonemes = syllableCount + syllableCount * (maxOnset + maxCoda) + 1;
    return targetPhonemes <= maxPhonemes;
  };

  const weights = getTopDownSyllableWeights(rt, mode, targetPhonemes);
  const feasible = weights.filter(([syllableCount]) => canSatisfy(syllableCount));
  if (feasible.length > 0) {
    return getWeightedOption(feasible, rand);
  }
  return getWeightedOption(weights, rand);
}

function sampleConsonantPlan(rt: GeneratorRuntime, syllableCount: number, rand: RNG): SyllableShapePlan[] {
  const plan: SyllableShapePlan[] = [];
  let prevCodaLength = 0;

  for (let i = 0; i < syllableCount; i++) {
    const isEndOfWord = i === syllableCount - 1;
    const onsetWeights = getOnsetLengthWeights(rt, syllableCount, prevCodaLength);
    const onsetLength = getWeightedOption(onsetWeights, rand);
    const codaWeights = getCodaLengthWeights(rt, syllableCount, onsetLength, isEndOfWord);
    const codaLength = getWeightedOption(codaWeights, rand);
    plan.push({ onsetLength, codaLength });
    prevCodaLength = codaLength;
  }

  return plan;
}

function tweakConsonantPlanToBudget(
  rt: GeneratorRuntime,
  plan: SyllableShapePlan[],
  targetConsonants: number,
  rand: RNG,
): SyllableShapePlan[] {
  const adjusted = plan.map(s => ({ ...s }));
  const syllableCount = adjusted.length;
  const maxOnset = rt.clusterLimits?.maxOnset ?? rt.config.syllableStructure.maxOnsetLength;
  const maxCoda = rt.clusterLimits?.maxCoda ?? rt.config.syllableStructure.maxCodaLength;
  const createsHiatus = (
    index: number,
    position: "onset" | "coda",
    nextLen: number,
  ): boolean => {
    if (position === "onset") {
      if (index === 0) return false;
      return adjusted[index - 1].codaLength === 0 && nextLen === 0;
    }
    if (index >= adjusted.length - 1) return false;
    return nextLen === 0 && adjusted[index + 1].onsetLength === 0;
  };
  const planGuardProbability = getPlanGuardProbability(rt);
  const shouldBlockHiatusMutation = (wouldCreateHiatus: boolean): boolean => {
    if (!wouldCreateHiatus) return false;
    return coinFlip(rand, planGuardProbability);
  };

  let total = adjusted.reduce((sum, s) => sum + s.onsetLength + s.codaLength, 0);

  while (total < targetConsonants) {
    const candidates: Array<{
      syllableIndex: number;
      position: "onset" | "coda";
      weight: number;
    }> = [];

    for (let i = 0; i < syllableCount; i++) {
      const isEndOfWord = i === syllableCount - 1;
      const prevCodaLength = i === 0 ? 0 : adjusted[i - 1].codaLength;
      const onsetWeights = getOnsetLengthWeights(rt, syllableCount, prevCodaLength);
      const codaWeights = getCodaLengthWeights(rt, syllableCount, adjusted[i].onsetLength, isEndOfWord);

      if (adjusted[i].onsetLength < maxOnset) {
        const next = adjusted[i].onsetLength + 1;
        candidates.push({ syllableIndex: i, position: "onset", weight: getLengthWeight(onsetWeights, next) });
      }
      if (adjusted[i].codaLength < maxCoda) {
        const next = adjusted[i].codaLength + 1;
        candidates.push({ syllableIndex: i, position: "coda", weight: getLengthWeight(codaWeights, next) });
      }
    }

    if (candidates.length === 0) break;
    const picked = getWeightedOption(candidates.map(c => [c, c.weight]), rand);
    adjusted[picked.syllableIndex][picked.position === "onset" ? "onsetLength" : "codaLength"]++;
    total++;
  }

  while (total > targetConsonants) {
    const candidates: Array<{
      syllableIndex: number;
      position: "onset" | "coda";
      weight: number;
    }> = [];

    for (let i = 0; i < syllableCount; i++) {
      const isEndOfWord = i === syllableCount - 1;
      const prevCodaLength = i === 0 ? 0 : adjusted[i - 1].codaLength;
      const onsetWeights = getOnsetLengthWeights(rt, syllableCount, prevCodaLength);
      const codaWeights = getCodaLengthWeights(rt, syllableCount, adjusted[i].onsetLength, isEndOfWord);

      if (adjusted[i].onsetLength > 0) {
        const curr = adjusted[i].onsetLength;
        const next = curr - 1;
        if (!shouldBlockHiatusMutation(createsHiatus(i, "onset", next))) {
          candidates.push({ syllableIndex: i, position: "onset", weight: 1 / getLengthWeight(onsetWeights, curr) });
        }
      }
      if (adjusted[i].codaLength > 0) {
        const curr = adjusted[i].codaLength;
        const next = curr - 1;
        if (!shouldBlockHiatusMutation(createsHiatus(i, "coda", next))) {
          candidates.push({ syllableIndex: i, position: "coda", weight: 1 / getLengthWeight(codaWeights, curr) });
        }
      }
    }

    if (candidates.length === 0) break;
    const picked = getWeightedOption(candidates.map(c => [c, c.weight]), rand);
    adjusted[picked.syllableIndex][picked.position === "onset" ? "onsetLength" : "codaLength"]--;
    total--;
  }

  return adjusted;
}

function distributePhonemes(
  rt: GeneratorRuntime,
  targetPhonemes: number,
  syllableCount: number,
  rand: RNG,
): SyllableShapePlan[] {
  const maxOnset = rt.clusterLimits?.maxOnset ?? rt.config.syllableStructure.maxOnsetLength;
  const maxCoda = rt.clusterLimits?.maxCoda ?? rt.config.syllableStructure.maxCodaLength;
  const maxConsonants = syllableCount * (maxOnset + maxCoda);

  // Clamp target consonants to feasible range instead of throwing.
  const rawTargetConsonants = targetPhonemes - syllableCount;
  const targetConsonants = Math.max(0, Math.min(rawTargetConsonants, maxConsonants));

  // Sample one natural plan, then tweak to match the budget.
  // The old approach tried 200 random samples hoping for an exact match —
  // this is O(syllableCount) instead of O(200 × syllableCount).
  const plan = sampleConsonantPlan(rt, syllableCount, rand);
  const consonants = plan.reduce((sum, s) => sum + s.onsetLength + s.codaLength, 0);
  if (consonants === targetConsonants) return plan;
  return tweakConsonantPlanToBudget(rt, plan, targetConsonants, rand);
}

function generateSyllable(rt: GeneratorRuntime, context: WordGenerationContext, syllablePlan: SyllableShapePlan): Syllable {
  const isEndOfWord = context.currSyllableIndex === context.syllableCount - 1;
  const isStartOfWord = context.currSyllableIndex === 0;
  const syllableCount = context.syllableCount;
  const monosyllabic = syllableCount === 1;

  const newSyllable: Syllable = {
    onset: [],
    nucleus: [],
    coda: [],
  };

  if (syllablePlan.onsetLength > 0) {
    newSyllable.onset = pickOnset(rt, context, isStartOfWord, monosyllabic, syllablePlan.onsetLength);
  }

  newSyllable.nucleus = pickNucleus(rt, context, isStartOfWord, isEndOfWord);

  if (syllablePlan.codaLength > 0) {
    newSyllable.coda = pickCoda(rt, context, newSyllable, isEndOfWord, monosyllabic, syllablePlan.codaLength);
  }

  return newSyllable;
}

function generateSyllables(rt: GeneratorRuntime, context: WordGenerationContext, mode: GenerationMode) {
  if (!context.syllablePlans || context.syllablePlans.length === 0) {
    const forcedSyllableCount = context.syllableCount > 0 ? context.syllableCount : undefined;
    const targetPhonemeCount = sampleTargetPhonemeCount(rt, mode, context.rand, forcedSyllableCount);
    const sampledSyllableCount = sampleSyllableCountForTarget(rt, mode, targetPhonemeCount, context.rand, forcedSyllableCount);
    context.syllableCount = sampledSyllableCount;
    context.targetPhonemeCount = targetPhonemeCount;
    context.syllablePlans = distributePhonemes(rt, targetPhonemeCount, sampledSyllableCount, context.rand);
  }

  if (context.syllablePlans.length !== context.syllableCount) {
    throw new Error(`Top-down syllable plan mismatch: expected ${context.syllableCount}, got ${context.syllablePlans.length}`);
  }

  // Use context.word.syllables directly so generateSyllable can see
  // previous syllables (needed for post-vowel onset weighting in pickOnset).
  context.word.syllables = new Array(context.syllableCount);
  let prevSyllable: Syllable | undefined;

  for (let i = 0; i < context.syllableCount; i++) {
    const syllablePlan = context.syllablePlans[i];
    let newSyllable = generateSyllable(rt, context, syllablePlan);

    if (prevSyllable) {
      [prevSyllable, newSyllable] = adjustBoundary(
        rt,
        prevSyllable,
        newSyllable,
        context.rand,
        i,
        context.trace,
      );
    }

    context.word.syllables[i] = newSyllable;
    prevSyllable = newSyllable;
    context.currSyllableIndex++;
  }

  const syllables = context.word.syllables;

  // Repair vowel hiatus: insert glide onset when two nuclei meet with no
  // intervening consonant (no coda on prev + no onset on current).
  repairVowelHiatus(rt, syllables, context.rand, context.trace);

  context.word.syllables = syllables;
}

/**
 * Insert a neutral onset to break vowel hiatus at syllable boundaries.
 *
 * When two consecutive syllables have no consonant between them (prev has no
 * coda, current has no onset), /h/ is inserted as a fallback onset of the
 * second syllable.
 */
function repairVowelHiatus(rt: GeneratorRuntime, syllables: Syllable[], rand: RNG, trace?: TraceCollector): void {
  if (rt.bridgePhonemeOptions.length === 0) return;

  for (let i = 1; i < syllables.length; i++) {
    const prev = syllables[i - 1];
    const curr = syllables[i];

    if (prev.coda.length === 0 && curr.onset.length === 0) {
      const bridge = getWeightedOption(rt.bridgePhonemeOptions, rand);
      curr.onset.unshift(bridge);
      trace?.recordStructural({
        event: "vowelHiatusFallback",
        inserted: bridge.sound,
        leftSyllableIndex: i - 1,
        rightSyllableIndex: i,
      });
    }
  }
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * A word generator instance created from a {@link LanguageConfig}.
 */
export interface WordGenerator {
  /** Generate a single random word. */
  generateWord: (options?: WordGenerationOptions) => Word;
}

// ---------------------------------------------------------------------------
// Pipeline
// ---------------------------------------------------------------------------

/**
 * Resolve the RNG from generation options.
 *
 * Priority: `options.rand` > seeded RNG from `options.seed` > default (Math.random).
 * When both `rand` and `seed` are provided, `seed` is silently ignored.
 */
function resolveRng(options: WordGenerationOptions): RNG {
  return options.rand ?? (options.seed !== undefined ? createSeededRng(options.seed) : createDefaultRng());
}

/** Maximum retries for letter-length rejection sampling. */
const MAX_LENGTH_RETRIES = 3;
/** Maximum retries for top-down phoneme target matching. */
const MAX_TOPDOWN_RETRIES = 16;

function countPhonemes(syllables: Syllable[]): number {
  let total = 0;
  for (const syl of syllables) {
    total += syl.onset.length + syl.nucleus.length + syl.coda.length;
  }
  return total;
}

/**
 * Generate a single word with letter-length rejection sampling.
 *
 * Builds a fresh context on each attempt. After {@link MAX_LENGTH_RETRIES}
 * failed length checks, the last word is accepted unconditionally.
 */
function generateOneWord(
  rt: GeneratorRuntime,
  rand: RNG,
  mode: GenerationMode,
  syllableCount: number,
  applyMorph: boolean = false,
  enableTrace: boolean = false,
): Word {
  // Plan morphology before generating root (to adjust syllable count)
  const morphConfig = rt.config.morphology;
  const morphPlan = morphConfig?.enabled && applyMorph
    ? planMorphology(morphConfig, mode, rand)
    : undefined;

  // Guard: if "both" template would reduce root below 1 syllable, downgrade to single affix
  if (morphPlan && morphPlan.plan.template === "both" && syllableCount > 0) {
    const rootAfterReduction = syllableCount - morphPlan.syllableReduction;
    if (rootAfterReduction < 1) {
      // Drop prefix, keep suffix (more natural in English)
      if (morphPlan.plan.prefix) {
        morphPlan.syllableReduction -= morphPlan.plan.prefix.syllableCount;
        morphPlan.plan.prefix = undefined;
        morphPlan.plan.template = "suffixed";
      }
    }
  }

  const maxAttempts = MAX_LENGTH_RETRIES + MAX_TOPDOWN_RETRIES;
  let lastContext: WordGenerationContext | undefined;
  let lastTraceCollector: TraceCollector | undefined;
  let lastMorphApplied = false;
  let bestContext: WordGenerationContext | undefined;
  let bestTraceCollector: TraceCollector | undefined;
  let bestMorphApplied = false;
  let bestAttempt = 0;
  let bestScore = Infinity;

  // Adjust syllable count for affix syllables.
  let rootSyllableCount = syllableCount;
  if (morphPlan && morphPlan.syllableReduction > 0 && rootSyllableCount > 0) {
    rootSyllableCount = Math.max(1, rootSyllableCount - morphPlan.syllableReduction);
  }

  const forcedFinalSyllableCount = syllableCount > 0 ? syllableCount : undefined;
  const forcedRootSyllableCount = rootSyllableCount > 0 ? rootSyllableCount : undefined;
  const plannedMorphologyDelta = getPlannedMorphologyPhonemeDelta(morphPlan?.plan);
  const maxOnset = rt.clusterLimits?.maxOnset ?? rt.config.syllableStructure.maxOnsetLength;
  const maxCoda = rt.clusterLimits?.maxCoda ?? rt.config.syllableStructure.maxCodaLength;
  const bounds = computePhonemeTargetBounds(forcedRootSyllableCount, maxOnset, maxCoda);
  const sampledFinalTarget = sampleTargetPhonemeCount(rt, mode, rand, forcedFinalSyllableCount);
  const { finalTarget: targetPhonemeCountFinal, rootTarget: targetPhonemeCountRoot } = derivePhonemeTargets(
    sampledFinalTarget,
    plannedMorphologyDelta.planned,
    bounds,
  );
  const sampledSyllableCount = sampleSyllableCountForTarget(rt, mode, targetPhonemeCountRoot, rand, forcedRootSyllableCount);

  for (let attempt = 0; attempt <= maxAttempts; attempt++) {
    const syllablePlans = distributePhonemes(rt, targetPhonemeCountRoot, sampledSyllableCount, rand);

    const traceCollector = enableTrace ? new TraceCollector() : undefined;
    if (traceCollector && morphPlan) {
      traceCollector.morphologyTrace = {
        template: morphPlan.plan.template,
        prefix: morphPlan.plan.prefix?.written,
        suffix: morphPlan.plan.suffix?.written,
        syllableReduction: morphPlan.syllableReduction,
      };
    }
    const context: WordGenerationContext = {
      rand,
      word: {
        syllables: [],
        pronunciation: "",
        written: { clean: "", hyphenated: "" },
      },
      syllableCount: sampledSyllableCount,
      currSyllableIndex: 0,
      targetPhonemeCount: targetPhonemeCountRoot,
      syllablePlans,
      trace: traceCollector,
    };
    runPipeline(rt, context, mode);

    const rootPhonemeCount = countPhonemes(context.word.syllables);
    const lexicalRoot = cloneSyllables(context.word.syllables);
    if (traceCollector) {
      const ledger = new FinalPhones();
      context.finalPhoneState = { ledger, ids: ledger.register("root", context.word.syllables) };
    }

    traceCollector?.beforeStage("assembleMorphology", context.word.syllables);
    const preparedMorphology = morphPlan ? prepareMorphology(rt, context, morphPlan.plan) : undefined;
    traceCollector?.afterStage("assembleMorphology", context.word.syllables);
    const rootSyllableStart = preparedMorphology?.rootSyllableStart ?? 0;

    // Final primary stress may fall on a formerly unstressed root vowel. Repair
    // the lexical choice before spelling, while retaining genuine alternations
    // (such as -ity shortening) as separate base and derived segments.
    traceCollector?.beforeStage("repairFinalStressedNuclei", context.word.syllables);
    repairFinalNuclei(context, lexicalRoot, rootSyllableStart, rt.positionPhonemes.nucleus, rt.resolvedStress);
    traceCollector?.afterStage("repairFinalStressedNuclei", context.word.syllables);
    context.word.lexical = {
      root: lexicalRoot,
      syllables: cloneSyllables(context.word.syllables),
      rootSyllableStart,
    };

    const rootContext: WordGenerationContext = {
      ...context,
      word: { syllables: lexicalRoot, written: { clean: "", hyphenated: "" }, pronunciation: "" },
      orthographySource: { kind: "lexical-root", wordSyllableStart: rootSyllableStart },
    };
    traceCollector?.beforeStage("generateWrittenForm", lexicalRoot);
    if (traceCollector) traceCollector.writerInput = structuredClone(lexicalRoot);
    rt.generateWrittenForm(rootContext);
    context.word.written = rootContext.word.written;
    context.baseSpelling = rootContext.baseSpelling;
    if (traceCollector) {
      traceCollector.writerOutput = { ...context.word.written };
      context.finalSpelling = new FinalSpelling(context.word.written.clean, context.baseSpelling?.current().cells);
    }
    traceCollector?.afterStage("generateWrittenForm", lexicalRoot);

    // Realize spelling from the same resolved attachment used for the phones.
    const morphApplied = !!morphPlan;
    if (morphPlan) {
      const morphology = preparedMorphology
        ? writeMorphology(context, preparedMorphology)
        : { parts: [{ role: "root" as const, text: context.word.written.clean }], spelling: context.finalSpelling };
      finalizeMorphologySpelling(rt.config, context, morphology);
    }
    traceCollector?.beforeStage("generatePronunciation", context.word.syllables);
    generatePronunciation(context, rt.resolvedPronunciation, context.finalPhoneState ? change => {
      const { ledger, ids } = context.finalPhoneState!;
      ledger.realize(ids[change.syllableIndex][change.segment][change.index], change.before, change.after, change.rule);
    } : undefined);
    if (traceCollector?.morphologyTrace?.realization && context.finalPhoneState) {
      const { ledger, ids } = context.finalPhoneState;
      traceCollector.morphologyTrace.realization.finalPhones = ledger.snapshot(ids, context.word.syllables);
    }
    traceCollector?.afterStage("generatePronunciation", context.word.syllables);
    // Gap spellings are exact bare-word overrides. Affixed forms should be
    // handled by morphology or more general rule systems instead.
    if (!morphPlan || morphPlan.plan.template === "bare") {
      rt.applyGapSpellings(context);
    }
    if (traceCollector && context.finalSpelling && context.finalPhoneState) {
      const spelling = context.finalSpelling.snapshot();
      if (spelling.surface !== context.word.written.clean) throw new Error("Final spelling surface mismatch");
      traceCollector.finalWord = { version: 1, spelling,
        phones: context.finalPhoneState.ledger.snapshot(context.finalPhoneState.ids, context.word.syllables) };
    }
    const finalPhonemeCount = countPhonemes(context.word.syllables);
    const morphologyDelta = resolveMorphologyPhonemeDelta(rootPhonemeCount, finalPhonemeCount, plannedMorphologyDelta);
    const targetPhonemeCount = morphApplied ? targetPhonemeCountFinal : targetPhonemeCountRoot;
    const generatedPhonemeCount = morphApplied ? finalPhonemeCount : rootPhonemeCount;
    const attemptScore = scoreGenerationAttempt(
      generatedPhonemeCount,
      targetPhonemeCount,
      context.word.written.clean.length,
      context.word.syllables.length,
      rt.config.syllableStructure.letterLengthTargets,
    );

    lastContext = context;
    lastTraceCollector = traceCollector;
    lastMorphApplied = morphApplied;

    if (attemptScore.total < bestScore) {
      bestScore = attemptScore.total;
      bestContext = context;
      bestTraceCollector = traceCollector;
      bestMorphApplied = morphApplied;
      bestAttempt = attempt;
    }

    const perfectMatch = attemptScore.phonemeDistance === 0 && attemptScore.letterPenalty === 0;
    const goodEnoughAfterWarmup =
      attempt >= MAX_LENGTH_RETRIES &&
      attemptScore.phonemeDistance === 0 &&
      attemptScore.letterPenalty <= 0.5 &&
      morphologyDelta.resolved !== undefined;

    if (perfectMatch || goodEnoughAfterWarmup) {
      if (traceCollector) {
        traceCollector.syllableCount = context.syllableCount;
        traceCollector.attempts = attempt;
        context.word.trace = traceCollector.toTrace(morphApplied);
      }
      return context.word;
    }
  }

  if (!bestContext && !lastContext) {
    throw new Error("Failed to generate word");
  }
  const fallbackContext = bestContext ?? lastContext!;
  const fallbackTraceCollector = bestTraceCollector ?? lastTraceCollector;
  const fallbackMorphApplied = bestContext ? bestMorphApplied : lastMorphApplied;
  const fallbackAttempts = bestContext ? bestAttempt : maxAttempts;
  if (fallbackTraceCollector) {
    fallbackTraceCollector.syllableCount = fallbackContext.syllableCount;
    fallbackTraceCollector.attempts = fallbackAttempts;
    fallbackContext.word.trace = fallbackTraceCollector.toTrace(fallbackMorphApplied);
  }
  return fallbackContext.word;
}

/**
 * Build a lexical root; morphology, spelling and surface realization follow.
 */
function runPipeline(rt: GeneratorRuntime, context: WordGenerationContext, mode: GenerationMode = "lexicon"): void {
  const t = context.trace;

  t?.beforeStage("generateSyllables", context.word.syllables);
  generateSyllables(rt, context, mode);
  t?.afterStage("generateSyllables", context.word.syllables);

  t?.beforeStage("repairClusters", context.word.syllables);
  if (rt.bannedSet) repairClusters(context.word.syllables, rt.bannedSet, rt.clusterRepair!, t);
  t?.afterStage("repairClusters", context.word.syllables);

  t?.beforeStage("repairFinalCoda", context.word.syllables);
  if (rt.allowedFinalSet) repairFinalCoda(context.word.syllables, rt.allowedFinalSet, t);
  t?.afterStage("repairFinalCoda", context.word.syllables);

  t?.beforeStage("repairClusterShape", context.word.syllables);
  if (rt.clusterLimits || rt.config.codaConstraints?.voicingAgreement || rt.config.codaConstraints?.homorganicNasalStop) {
    repairClusterShape(context.word.syllables, {
      clusterLimits: rt.clusterLimits,
      sonorityConstraints: rt.sonorityConstraints,
      codaConstraints: rt.config.codaConstraints,
      sonorityBySound: rt.sonorityBySound,
      codaAppendantSet: rt.codaAppendantSet,
      sonorityExemptSet: rt.sonorityExemptSet,
    }, t);
  }
  t?.afterStage("repairClusterShape", context.word.syllables);

  t?.beforeStage("repairHAfterBackVowel", context.word.syllables);
  repairHAfterBackVowel(context.word.syllables, t);
  t?.afterStage("repairHAfterBackVowel", context.word.syllables);

  const stressRules = rt.resolvedStress;

  t?.beforeStage("applyStress", context.word.syllables);
  applyStress(context, stressRules);
  t?.afterStage("applyStress", context.word.syllables);

  t?.beforeStage("repairStressedNuclei", context.word.syllables);
  repairStressedNuclei(context, rt.positionPhonemes.nucleus, stressRules);
  t?.afterStage("repairStressedNuclei", context.word.syllables);
}

const MAX_FORCED_SYLLABLE_COUNT = 7;
const MAX_BATCH_COUNT = 1_000_000;

function resolveForcedSyllableCount(options: WordGenerationOptions): number {
  const syllableCount = options.syllableCount;
  if (syllableCount === undefined || syllableCount === 0) return 0;
  if (!Number.isInteger(syllableCount) || syllableCount < 1 || syllableCount > MAX_FORCED_SYLLABLE_COUNT) {
    throw new RangeError("options.syllableCount must be an integer from 1 to 7 (or 0/undefined for automatic sampling).");
  }
  return syllableCount;
}

function resolveBatchCount(count: number): number {
  if (!Number.isInteger(count) || count < 0) {
    throw new RangeError("count must be a non-negative integer.");
  }
  if (count > MAX_BATCH_COUNT) {
    throw new RangeError(`count must be less than or equal to ${MAX_BATCH_COUNT}.`);
  }
  return count;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Creates a word generator from a {@link LanguageConfig}.
 *
 * All phoneme inventories, grapheme maps, sonority levels, and cluster
 * constraints are derived from the config at creation time — no global
 * state is referenced during generation.
 *
 *
 * @param config - The language configuration to build from.
 * @returns A {@link WordGenerator} instance.
 *
 * @example
 * ```ts
 * import { createGenerator, englishConfig } from "word-generator";
 *
 * const gen = createGenerator(englishConfig);
 * const word = gen.generateWord({ seed: 42 });
 * console.log(word.written.clean);
 * ```
 */
export function createGenerator(config: LanguageConfig): WordGenerator {
  const rt = buildRuntime(config);

  return {
    generateWord: (options: WordGenerationOptions = {}): Word => {
      return generateOneWord(rt, resolveRng(options), options.mode ?? "lexicon", resolveForcedSyllableCount(options), options.morphology ?? true, options.trace ?? false);
    },
  };
}

// ---------------------------------------------------------------------------
// Default English instance (built once, shared by public API + test helpers)
// ---------------------------------------------------------------------------

const defaultRuntime = buildRuntime(englishConfig);

/**
 * Generates a random English-like word. Shorthand for the default English generator.
 *
 * @example
 * ```ts
 * import { generateWord } from "word-generator";
 * const word = generateWord();
 * const affixed = generateWord({ morphology: true });
 * ```
 */
export const generateWord = (options: WordGenerationOptions = {}): Word => {
  return generateOneWord(defaultRuntime, resolveRng(options), options.mode ?? "lexicon", resolveForcedSyllableCount(options), options.morphology ?? true, options.trace ?? false);
};

/**
 * Generate multiple words sharing a single RNG instance.
 *
 * With a shared RNG, `generateWords(50, { seed: 42 })` is deterministic AND
 * produces different words for each index. This is **not** equivalent to
 * calling `generateWord({ seed: 42 })` 50 times — the latter creates 50
 * identical RNG streams and therefore 50 identical words.
 *
 * @param count - Number of words to generate. Must be an integer from 0 to 1,000,000.
 * @param options - Generation options (seed, rand, syllableCount, etc.).
 * @returns An array of generated {@link Word} objects.
 *
 * @example
 * ```ts
 * import { generateWords } from "word-generator";
 * const words = generateWords(50, { seed: 42 });
 * // All 50 words are different but fully deterministic.
 * const affixed = generateWords(50, { morphology: true });
 * ```
 */
export const generateWords = (count: number, options: WordGenerationOptions = {}): Word[] => {
  const total = resolveBatchCount(count);
  const rand = resolveRng(options);
  const mode = options.mode ?? "lexicon";
  const syllableCount = resolveForcedSyllableCount(options);
  const results: Word[] = [];
  for (let i = 0; i < total; i++) {
    results.push(generateOneWord(defaultRuntime, rand, mode, syllableCount, options.morphology ?? true, options.trace ?? false));
  }
  return results;
};

export default generateWord;

// ---------------------------------------------------------------------------
// Test helpers — exported for unit tests, not part of the public API
// ---------------------------------------------------------------------------

/** @internal Build a cluster using the default English runtime. For tests only. */
export function _buildCluster(context: ClusterContext): Phoneme[] {
  return buildCluster(defaultRuntime, context);
}

/** @internal Check cluster validity using the default English runtime. For tests only. */
export function _isValidCluster(cluster: Phoneme[], position: "onset" | "coda" | "nucleus"): boolean {
  return isValidCluster(defaultRuntime, cluster, position);
}

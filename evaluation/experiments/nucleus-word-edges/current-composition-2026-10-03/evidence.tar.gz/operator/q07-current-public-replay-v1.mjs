import assert from "node:assert/strict";
import {createReadStream,readFileSync,writeFileSync} from "node:fs";
import {createInterface} from "node:readline";
import {createGunzip} from "node:zlib";
import {createHash} from "node:crypto";
import {pathToFileURL} from "node:url";
const directory="/private/tmp/q07-current-composition-v1";
const sha=bytes=>createHash("sha256").update(bytes).digest("hex");
const registration=JSON.parse(readFileSync(directory+"/registration.json"));
assert(JSON.parse(readFileSync(directory+"/native-complete.json")).executionPassed);
const nodePin=sha(readFileSync(process.execPath));
const loader="/Users/ryanbetts/Code/unglish/word-generator/node_modules/tsx/dist/loader.mjs";
const loaderPin=sha(readFileSync(loader));
const checkSource=arm=>{
  for(const pin of registration.currentHeadFilePins[arm]){
    const bytes=readFileSync(directory+"/"+arm+"/"+pin.file);
    assert.equal(bytes.length,pin.bytes,pin.file);assert.equal(sha(bytes),pin.sha256,pin.file);
  }
};
const report={startedAt:new Date().toISOString(),heads:registration.heads,nodeVersion:process.version,nodeSha256:nodePin,tsxLoaderSha256:loaderPin,arms:{},
  scope:"All400000words and complete traces replayed through untouched current source public generateWord with original profile options,seeds and continuous streams. RNG callback counts/next values are observed replay diagnostics,not paired to unrecorded capture RNG counts. Fixed seeds do not prove probabilistic independence; no current-main beyond named heads,human gain or timing claim."};
for(const arm of ["control","candidate"]){
  checkSource(arm);
  const api=await import(pathToFileURL(directory+"/"+arm+"/src/index.ts").href);
  const manifest=JSON.parse(readFileSync(directory+"/"+arm+"-run/manifest.json")).manifest;
  assert.deepEqual(manifest.protocol,registration.protocol);
  const streams=[];
  for(const profile of registration.protocol.profiles){
    for(const seed of profile.seeds.development){
      const filename="words/"+profile.id+"-"+seed+".jsonl.gz";
      const pin=manifest.artifacts.find(p=>p.file===filename);
      assert(pin);
      const compressed=readFileSync(directory+"/"+arm+"-run/"+filename);
      assert.equal(compressed.length,pin.bytes);assert.equal(sha(compressed),pin.sha256);
      const seeded=api.createSeededRng(seed);let rngCalls=0,index=0;
      const rand=()=>{rngCalls++;return seeded();};
      const input=createReadStream(directory+"/"+arm+"-run/"+filename).pipe(createGunzip());
      const lines=createInterface({input,crlfDelay:Infinity});
      const actualHash=createHash("sha256"),archivedHash=createHash("sha256");
      for await(const line of lines){
        const draw=JSON.parse(line);
        assert.equal(draw.profile,profile.id);assert.equal(draw.seed,seed);assert.equal(draw.drawIndex,index);
        const actual=JSON.parse(JSON.stringify(api.generateWord({...profile.options,rand,trace:true})));
        assert.deepEqual(actual,draw.word,arm+"/"+profile.id+"/"+seed+"/"+index);
        actualHash.update(JSON.stringify(actual)+"\n");archivedHash.update(JSON.stringify(draw.word)+"\n");
        index++;
      }
      assert.equal(index,10000);assert.equal(index,registration.protocol.wordsPerReplicate);
      const actualDigest=actualHash.digest("hex"),archivedDigest=archivedHash.digest("hex");
      assert.equal(actualDigest,archivedDigest);
      streams.push({profile:profile.id,seed,words:index,rngCalls,nextRngValue:seeded(),completeWordTraceSha256:actualDigest});
      console.log(arm+"/"+profile.id+"/"+seed+": "+index+" complete public replays");
    }
  }
  checkSource(arm);
  report.arms[arm]={words:streams.reduce((n,s)=>n+s.words,0),streams,completeWordsAndTracesEqual:true};
  assert.equal(report.arms[arm].words,200000);
}
assert.equal(sha(readFileSync(process.execPath)),nodePin);assert.equal(sha(readFileSync(loader)),loaderPin);
report.completedAt=new Date().toISOString();
writeFileSync(directory+"/public-replay.json",JSON.stringify(report,null,2)+"\n",{flag:"wx"});
console.log(JSON.stringify({controlWords:report.arms.control.words,candidateWords:report.arms.candidate.words,completeWordsAndTracesEqual:true}));


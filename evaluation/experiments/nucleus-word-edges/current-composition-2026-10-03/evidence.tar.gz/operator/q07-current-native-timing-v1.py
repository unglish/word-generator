from pathlib import Path
import os,signal,subprocess,json,datetime,hashlib,statistics,re,traceback
OUT=Path("/private/tmp/q07-current-composition-v1");OLD=Path("/private/tmp/q07-acceptance-revalidation-v1/source")
PID=20185;PPID=20178
NODE="/Users/ryanbetts/.nvm/versions/node/v24.11.1/bin/node";NPM="/Users/ryanbetts/.nvm/versions/node/v24.11.1/bin/npm"
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest()
EXPECTED="/Users/ryanbetts/.codex/worktrees/d9c28566-8f5b-432e-a246-5e4070782624/word-generator/.local-evidence/read-aloud-study/categorical-calibration-v1/verify-calibration.py --input /private/tmp/q23-categorical-calibration-v1 --out /private/tmp/q23-categorical-independent-v1"
def owned_process():
 line=subprocess.check_output(["/bin/ps","-p",str(PID),"-o","pid=,ppid=,stat=,args="],text=True).strip()
 parts=line.split(None,3)
 assert len(parts)==4 and int(parts[0])==PID and int(parts[1])==PPID and EXPECTED in parts[3],line
 return {"pid":PID,"ppid":PPID,"state":parts[2],"command":parts[3]}
assert (OUT/"gates-complete.json").exists() and (OUT/"public-replay.json").exists() and (OUT/"independent-recount.json").exists() and (OUT/"historical-composition-comparison.json").exists()
assert os.environ.get("CI")!="true","Do not substitute CI4300floor/4variance for original native4500/3"
pins={}
for arm in ["control","candidate"]:
 pins[arm]={}
 for file in ["src/core/generate.perf.test.ts","vitest.perf.config.ts"]:
  data=(OUT/arm/file).read_bytes();assert data==(OLD/file).read_bytes(),file
  pins[arm][file]={"bytes":len(data),"sha256":sha(data)}
before={"observedAt":now(),"ownedProcessBefore":owned_process(),"unchangedOriginalPerformanceSource":pins,"pairs":6,"runs":12,"nodeVersion":subprocess.check_output([NODE,"--version"],text=True).strip(),"nodeSha256":sha(Path(NODE).read_bytes()),"nativeFloor":4500,"medianVarianceLimit":3,"sourceSampleSize":10000,"warmupCount":50,"timeoutsMilliseconds":20000,"otherObservedActivity":"diskimagesiod observed24.5percent CPU before isolation; system activity cannot be excluded. No performance-improvement generalization."}
(OUT/"native-timing-before.json").write_text(json.dumps(before,indent=2)+"\n")
def interrupted(signum,frame):raise InterruptedError("Timing driver signal "+str(signum))
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
held=False;records=[];failure=None
try:
 os.kill(PID,signal.SIGSTOP);held=True
 stopped=owned_process();assert "T" in stopped["state"]
 (OUT/"native-timing-hold.json").write_text(json.dumps({"observedAt":now(),"ownedProcessStopped":stopped,"scope":"Same owned original verification process temporarily paused for12unchanged native timing runs; no restart/source/RNG/sample/gate change."},indent=2)+"\n")
 env=dict(os.environ);env["PATH"]=str(Path(NODE).parent)+os.pathsep+env.get("PATH","")
 for pair in range(1,7):
  order=["control","candidate"] if pair%2 else ["candidate","control"]
  for arm in order:
   name=f"native-pair-{pair}-{arm}";args=[NPM,"run","test:perf"]
   r={"name":name,"pair":pair,"arm":arm,"args":args,"cwd":str(OUT/arm),"startedAt":now()}
   (OUT/"active-native-timing.json").write_text(json.dumps(r,indent=2)+"\n")
   with (OUT/(name+".log")).open("xb") as log:result=subprocess.run(args,cwd=OUT/arm,env=env,stdout=log,stderr=subprocess.STDOUT)
   text=(OUT/(name+".log")).read_text()
   m=re.search(r"Performance:\s*(\d+) words/sec \((\d+) words in (\d+)ms\)",text)
   assert m and int(m[2])==10000 and "Floor: 4500 words/sec" in text
   v=re.search(r"\(median ([0-9.]+)x\)",text);assert v and "Median variance threshold: < 3.0x" in text
   r.update({"completedAt":now(),"exitCode":result.returncode,"roundedWordsPerSecond":int(m[1]),"roundedElapsedMilliseconds":int(m[3]),"roundedMedianVariance":float(v[1])})
   records.append(r);(OUT/"native-timing-records.json").write_text(json.dumps(records,indent=2)+"\n")
   print(json.dumps(r),flush=True)
 for arm,entries in pins.items():
  for name,pin in entries.items():assert sha((OUT/arm/name).read_bytes())==pin["sha256"]
except BaseException as e:
 failure={"failedAt":now(),"error":repr(e),"traceback":traceback.format_exc(),"records":records}
 (OUT/"native-timing-failure.json").write_text(json.dumps(failure,indent=2)+"\n")
 raise
finally:
 if held:
  owned_process();os.kill(PID,signal.SIGCONT)
  resumed=owned_process();assert "T" not in resumed["state"]
  (OUT/"native-timing-resumed.json").write_text(json.dumps({"observedAt":now(),"ownedProcessResumed":resumed,"samePidAndCommand":True},indent=2)+"\n")
assert len(records)==12
ratios=[]
for pair in range(1,7):
 rows={r["arm"]:r for r in records if r["pair"]==pair}
 ratios.append(rows["candidate"]["roundedWordsPerSecond"]/rows["control"]["roundedWordsPerSecond"])
result={"completedAt":now(),"executionPassed":True,"pairs":6,"runs":12,"passingRuns":sum(r["exitCode"]==0 for r in records),"failingRuns":sum(r["exitCode"]!=0 for r in records),"candidateControlRoundedThroughputRatios":ratios,"medianCandidateControlRoundedThroughputRatio":statistics.median(ratios),"sameOwnedOriginalVerificationProcessResumed":True,"scope":"All12unchanged original native timing tests with10000sample/50warmup/4500floor/3variance/20000ms timeout. Six alternating pairs; ratios use rounded native logs. Same original ownedQ23verification paused and resumed,no restart. System activity/noise and JIT/GC remain limitations; no human gain or stable general performance improvement."}
(OUT/"native-timing-complete.json").write_text(json.dumps(result,indent=2)+"\n");print(json.dumps(result),flush=True)


from pathlib import Path
import subprocess,json,datetime,gzip,hashlib,shutil,traceback
ROOT=Path.cwd(); OUT=Path("/private/tmp/q07-current-composition-v1")
NODE="/Users/ryanbetts/.nvm/versions/node/v24.11.1/bin/node"; TSX="/Users/ryanbetts/Code/unglish/word-generator/node_modules/tsx/dist/loader.mjs"
sha=lambda b:hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
old=Path("/private/tmp/q07-acceptance-revalidation-v1")
archived=json.loads(gzip.decompress((old/"fresh-run/sources.json.gz").read_bytes()))
protocol=json.loads((old/"registered-protocol.json").read_text())
heads=json.loads((OUT/"checkout-before.json").read_text())["heads"]
pins={};frozen=[];reference=[]
for arm,head in heads.items():
 source=OUT/arm
 assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=source).decode().strip()==head
 assert not subprocess.check_output(["git","status","--porcelain"],cwd=source)
 measure=OUT/("measurement-"+arm)
 subprocess.run(["git","clone","--shared",str(source),str(measure)],check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=measure).decode().strip()==head
 for group in ["evaluator","references"]:
  for f in archived[group]:
   path=measure/f["path"]; body=f["content"].encode(); path.parent.mkdir(parents=True,exist_ok=True)
   if group=="references":assert path.read_bytes()==body,"Current reference bytes changed; no silent replacement"
   path.write_bytes(body)
   if arm=="candidate":(frozen if group=="evaluator" else reference).append({"file":f["path"],"sha256":sha(body),"bytes":len(body)})
 for path,original in [("evaluation/quality/probes/nucleus-edges.ts",old/"source/evaluation/quality/probes/nucleus-edges.ts"),("evaluation/quality/probes/resolved-allomorphs/analyze.mjs",Path("/private/tmp/q06-acceptance-revalidation-v1/source/evaluation/quality/probes/resolved-allomorphs/analyze.mjs")),("evaluation/quality/probes/resolved-allomorphs/README.md",Path("/private/tmp/q06-acceptance-revalidation-v1/source/evaluation/quality/probes/resolved-allomorphs/README.md"))]:
  p=measure/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(original.read_bytes())
 for directory in [source,measure]:
  deps=directory/"node_modules";deps.mkdir()
  for p in Path("/Users/ryanbetts/Code/unglish/word-generator/node_modules").iterdir():
   if p.name not in {".vite",".vite-temp",".cache"}:(deps/p.name).symlink_to(p,target_is_directory=p.is_dir())
 files=subprocess.check_output(["git","ls-files","src","data/cmu","package.json","package-lock.json"],cwd=source).decode().splitlines()
 pins[arm]=[]
 for name in files:
  b=(source/name).read_bytes();assert (measure/name).read_bytes()==b
  assert b==subprocess.check_output(["git","show",head+":"+name],cwd=source)
  pins[arm].append({"file":name,"bytes":len(b),"sha256":sha(b)})
(OUT/"registered-protocol.json").write_text(json.dumps(protocol)+"\n")
registration={"schemaVersion":1,"registeredAt":now(),"entry":"Q07","heads":heads,"protocol":protocol,"cohort":"development","wordsPerArm":200000,"wordsTotal":400000,"evaluatorDigest":"ad7bf7980d18a9e4ed8084c5b3ea0b6f43ae24722db44b99f38a5da15c404007","frozenEvaluatorPins":frozen,"unchangedReferencePins":reference,"currentHeadFilePins":pins,
 "nucleusProbeSha256":sha((old/"source/evaluation/quality/probes/nucleus-edges.ts").read_bytes()),
 "allomorphProbeSha256":sha(Path("/private/tmp/q06-acceptance-revalidation-v1/source/evaluation/quality/probes/resolved-allomorphs/analyze.mjs").read_bytes()),
 "requirements":["Full original four profiles/five development streams/10000continuous traced public-API draws perarm; no validation tuning.","Original13diagnostics/distributions/actualstrata and all nucleus layers/profile/seed/stratum/repairs/fullwitnesses.","Full resolved morphology probe on both arms,includingunknowns/cleanup/mismatch evidence.","Public-API replay of all400000records from untouched current checkouts; selected source/archive/RNG draw coordinates exact.","Independent Python recount of all400000raw records and every core/nucleus/morphology context/fullwitness.","Compare control against original baseline and candidate against both original and cumulative control; preserve all tradeoffs and failures.","Original historical gates remain unchanged; current upstream passing changed gates is a separate observation. Native timings await an uncontended execution opportunity.","Full evidence byte/hash retention before public review. No human gain or universal rime-legality inference."],
 "scope":"Prospectively registered cumulative comparison at exact current heads. Frozen measurement tools operate in separate clones; untouched current checkouts remain available for full public replay and their own current tests. Actual participant studies remain separate."}
(OUT/"registration.json").write_text(json.dumps(registration,indent=2)+"\n")
(ROOT/".local-evidence/q07-current-composition-registration-v1.json").write_text(json.dumps(registration,indent=2)+"\n")
assert shutil.disk_usage(OUT).free>=400_000_000+2*1024**3,"Full both-arm capture/copy bound plus2GiB unchanged"
commands=[]
for arm in ["control","candidate"]:
 commands += [(arm+"-full-capture","measurement-"+arm,[NODE,"--import",TSX,"evaluation/quality/cli.ts","capture","--id","q07-current-"+arm+"-v1","--cohort","development","--protocol",str(OUT/"registered-protocol.json"),"--out",str(OUT/(arm+"-run"))]),
 (arm+"-full-archive-verification","measurement-"+arm,[NODE,"--import",TSX,"evaluation/quality/cli.ts","verify","--run",str(OUT/(arm+"-run"))]),
 (arm+"-full-nucleus-probe","measurement-"+arm,[NODE,"--import",TSX,"evaluation/quality/probes/nucleus-edges.ts","--run",str(OUT/(arm+"-run")),"--out",str(OUT/("nucleus-"+arm+".json"))])]
commands += [("full-allomorph-probe","measurement-candidate",[NODE,"evaluation/quality/probes/resolved-allomorphs/analyze.mjs",str(OUT/"control-run"),str(OUT/"candidate-run"),str(OUT/"allomorph-probe.json")])]
baseline=ROOT/"evaluation/quality/baselines/2026-09-26-development-standalone"
for name,base,candidate in [("control-vs-original",baseline,OUT/"control-run"),("candidate-vs-original",baseline,OUT/"candidate-run"),("candidate-vs-control",OUT/"control-run",OUT/"candidate-run")]:
 commands.append((name,"measurement-candidate",[NODE,"--import",TSX,"evaluation/quality/cli.ts","compare","--baseline",str(base),"--candidate",str(candidate),"--out",str(OUT/name)]))
records=[]
try:
 for name,arm,args in commands:
  record={"name":name,"cwd":str(OUT/arm),"args":args,"startedAt":now()}
  (OUT/"active-command.json").write_text(json.dumps(record,indent=2)+"\n")
  with (OUT/(name+".log")).open("xb") as log:r=subprocess.run(args,cwd=OUT/arm,stdout=log,stderr=subprocess.STDOUT)
  record.update({"finishedAt":now(),"exitCode":r.returncode});records.append(record)
  (OUT/"commands.json").write_text(json.dumps(records,indent=2)+"\n");print(json.dumps(record),flush=True)
  assert r.returncode==0,name
 for arm,files in pins.items():
  for p in files:
   for workspace in [OUT/arm,OUT/("measurement-"+arm)]:
    b=(workspace/p["file"]).read_bytes();assert len(b)==p["bytes"] and sha(b)==p["sha256"]
 result={"completedAt":now(),"executionPassed":True,"commands":len(records),"registeredWordsTotal":400000,"currentSourcePinsUnchanged":True,"scope":"Full400000registered captures,native nucleus/morphology probes and all three comparisons executed. Public replay,independent recount,original gates/timing,retention remain required. No human-quality verdict."}
 (OUT/"native-complete.json").write_text(json.dumps(result,indent=2)+"\n");print(json.dumps(result),flush=True)
except BaseException as e:
 (OUT/"native-failure.json").write_text(json.dumps({"failedAt":now(),"error":repr(e),"traceback":traceback.format_exc(),"commands":records},indent=2)+"\n");raise


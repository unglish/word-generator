from pathlib import Path
import json,gzip,hashlib,datetime,copy,collections
OUT=Path("/private/tmp/q07-current-composition-v1");OLD=Path("/private/tmp/q07-acceptance-revalidation-v1/fresh-run");CONTROL=Path("/private/tmp/q06-acceptance-revalidation-v1/fresh-run")
sha=lambda b:hashlib.sha256(b).hexdigest()
assert (OUT/"native-complete.json").exists()
old_control=json.loads((CONTROL/"manifest.json").read_text())['manifest'];old_candidate=json.loads((OLD/"manifest.json").read_text())['manifest']
new_control=json.loads((OUT/"control-run/manifest.json").read_text())['manifest'];new_candidate=json.loads((OUT/"candidate-run/manifest.json").read_text())['manifest']
control_pins=[];bare_pins=[];profiles={}
for entry in old_control['artifacts']:
 if not entry['file'].startswith('words/'):continue
 a=(CONTROL/entry['file']).read_bytes();b=(OUT/"control-run"/entry['file']).read_bytes()
 pin=next(p for p in new_control['artifacts'] if p['file']==entry['file'])
 assert a==b and len(a)==entry['bytes']==pin['bytes'] and sha(a)==entry['sha256']==pin['sha256']
 control_pins.append(entry)
assert len(control_pins)==20
for profile in old_candidate['protocol']['profiles']:
 counts={'words':0,'legacyWordsEqualAfterRemovingOnlyNewResolution':0,'writtenChanges':0,'otherLegacyPayloadChanges':0,'fullSyllablesChanged':0,'pronunciationChanged':0,'newResolutionWords':0}
 witnesses={}
 for seed in profile['seeds']['development']:
  file=f"words/{profile['id']}-{seed}.jsonl.gz"
  expected=next(p for p in old_candidate['artifacts'] if p['file']==file)
  newpin=next(p for p in new_candidate['artifacts'] if p['file']==file)
  a=(OLD/file).read_bytes();b=(OUT/"candidate-run"/file).read_bytes()
  assert len(a)==expected['bytes'] and sha(a)==expected['sha256']
  assert len(b)==newpin['bytes'] and sha(b)==newpin['sha256']
  if not profile['options']['morphology']:
   assert a==b;bare_pins.append(expected)
  old_lines=gzip.decompress(a).splitlines();new_lines=gzip.decompress(b).splitlines()
  assert len(old_lines)==len(new_lines)==10000
  for index,(original,fresh) in enumerate(zip(old_lines,new_lines)):
   old_draw=json.loads(original);new_draw=json.loads(fresh)
   assert (old_draw['profile'],old_draw['seed'],old_draw['drawIndex'])==(new_draw['profile'],new_draw['seed'],new_draw['drawIndex'])==(profile['id'],seed,index)
   old_word,new_word=old_draw['word'],copy.deepcopy(new_draw['word'])
   morph=new_word['trace'].get('morphology') or {}
   if 'realization' in morph:counts['newResolutionWords']+=1;morph.pop('realization')
   counts['words']+=1;counts['legacyWordsEqualAfterRemovingOnlyNewResolution']+=old_word==new_word
   change=old_word['written']!=new_word['written'];counts['writtenChanges']+=change
   counts['fullSyllablesChanged']+=old_word['syllables']!=new_word['syllables']
   counts['pronunciationChanged']+=old_word.get('pronunciation')!=new_word.get('pronunciation')
   old_residual={k:v for k,v in old_word.items() if k!='written'};new_residual={k:v for k,v in new_word.items() if k!='written'}
   extra=old_residual!=new_residual;counts['otherLegacyPayloadChanges']+=extra
   for kind,flag in [('written-change',change),('other-legacy-change',extra)]:
    if flag and len(witnesses.get(kind,[]))<2:witnesses.setdefault(kind,[]).append({'original':old_draw,'current':new_draw})
 profiles[profile['id']]={'counts':counts,'fullWitnesses':witnesses}
 print(json.dumps({'profile':profile['id'],'counts':counts}),flush=True)
assert len(bare_pins)==10
report={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'currentHeads':json.loads((OUT/'registration.json').read_text())['heads'],'all200000CurrentControlWordsByteIdenticalToOriginalQ06Candidate':control_pins,'all100000BareCurrentCandidateWordsByteIdenticalToOriginalQ07Candidate':bare_pins,'all200000CandidateOrdinalComparisons':profiles,'scope':'All20controlrawshards and10barecandidate shards match full byte/hash pins from complete historical reproductions. All200000current-vs-historical candidate ordinal records compared after removing only new resolved morphology trace field; complete written/non-written changes and bounded full pairs retained. Equal ordinal coordinates are not a causal matched lexical design, and no unrecorded historic RNG-call equality or probabilistic independence is inferred.'}
(OUT/'historical-composition-comparison.json').write_text(json.dumps(report,indent=2)+'\n')


import gzip,hashlib,json,os,pathlib,subprocess,sys
ROOT=pathlib.Path('/Users/ryanbetts/.codex/worktrees/linguistic-rejection/word-generator')
DIRECTORY=pathlib.Path('/private/tmp/q15-transition-acceptance-v2')
SOURCE=pathlib.Path('/private/tmp/q15c2-acceptance-v1/raw source.dict')
FREEZE=ROOT/'evaluation/experiments/cmu-transition-builder/source-review-freeze-v1.json'
SHA=lambda b:hashlib.sha256(b).hexdigest()
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
DIRECTORY.mkdir()
freeze_bytes=FREEZE.read_bytes(); assert SHA(freeze_bytes)=='d1bb87e5c957ad9337dd3cb11d62b4d2c0b3b445a673cc4f0b448860835a57f2'
freeze=json.loads(freeze_bytes); inputs={r['path']:r['sha256'] for r in freeze['files']}
old=json.loads((ROOT/'evaluation/experiments/cmu-transition-builder/parent-files.json').read_bytes())
allowed={'TUNING.md','docs/phonotactic-scoring.md','scripts/generate-bigram-table.ts'}
raw=SOURCE.read_bytes(); assert SHA(raw)=='81917843c7f44ce2b094ac63873c2c7a4cf802040792c455ba3ca406891c3d22'
local_source=DIRECTORY/'raw source.dict'; local_source.write_bytes(raw)
alias=DIRECTORY/'builder alias.ts'; alias.symlink_to(ROOT/'scripts/generate-bigram-table.ts')
script=str(ROOT/'scripts/generate-bigram-table.ts')
node=['node','--import','tsx',script]; tsx=[str(ROOT/'node_modules/.bin/tsx'),str(alias)]
common=['--policy','cmu-ascii-first-v1','--units','integer-phone-transition-occurrences']
first=DIRECTORY/'node artifact.json'; second=DIRECTORY/'alias artifact.json'
commands=[]
def stable():
    assert FREEZE.read_bytes()==freeze_bytes
    for path,sha in inputs.items():assert SHA((ROOT/path).read_bytes())==sha,path
    for path,sha in old.items():
        if path not in allowed:assert SHA((ROOT/path).read_bytes())==sha,path
    assert SOURCE.read_bytes()==local_source.read_bytes()==raw

def run(name,cmd,cwd,success):
    result=subprocess.run(cmd,cwd=cwd,text=True,capture_output=True)
    record={'name':name,'command':cmd,'cwd':str(cwd),'expectedSuccess':success,'exitCode':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
    save(DIRECTORY/f'command-{name}.json',record);commands.append(record)
    stable();assert (result.returncode==0)==success,record
    return result

def build_args(source,out):return ['--source',str(source),*common,'--out',str(out)]
plan={'version':'cmu-transition-formal-cli-matrix-v1','runnerSha256':SHA(pathlib.Path(__file__).read_bytes()),'reviewFreezeSha256':SHA(freeze_bytes),'constructionOrder':['node-import-tsx-root-cwd','symlinked-tsx-unrelated-cwd-relative-paths'],'sourceSha256':SHA(raw),'expectedSuccessCases':['help','first-build','second-build','independent-full-bin-recount'],'failureCases':['no-arguments','unknown-argument','duplicate-argument','unsupported-units','missing-source','empty-source','truncated-source','invalid-utf8','changed-source-case','existing-output','existing-symlink','dangling-symlink','source-as-output','source-hardlink-output','source-directory-alias-output','protected-prior-length-package','protected-demo','protected-evidence-alias','protected-runtime-alias','missing-output-parent'],'twoBuildsMustBeByteIdentical':True,'allInputsAndFrozenImplementationMustRemainStable':True}
save(DIRECTORY/'execution-plan.json',plan)
stable()
run('help',tsx+['--help'],DIRECTORY,True)
run('no-arguments',node,ROOT,False)
run('first-build',node+build_args(local_source,first),ROOT,True)
run('second-build',tsx+build_args('raw source.dict','alias artifact.json'),DIRECTORY,True)
artifact_bytes=first.read_bytes(); assert second.read_bytes()==artifact_bytes
envelope=json.loads(artifact_bytes)
assert envelope['artifact']['implementation']['digest']==freeze['implementationDigest']
for name,target in [('existing-symlink',first),('dangling-symlink',DIRECTORY/'never-created.json')]:
    link=DIRECTORY/(name+'.json'); link.symlink_to(target)
    run(name,node+build_args(local_source,link),ROOT,False);assert link.is_symlink() and link.readlink()==target
assert not (DIRECTORY/'never-created.json').exists()
run('existing-output',node+build_args(local_source,first),ROOT,False)
run('source-as-output',node+build_args(local_source,local_source),ROOT,False)
hard=DIRECTORY/'source-hardlink.dict';os.link(local_source,hard)
run('source-hardlink-output',node+build_args(local_source,hard),ROOT,False)
dir_alias=DIRECTORY/'source-directory-alias';dir_alias.symlink_to(DIRECTORY,target_is_directory=True)
run('source-directory-alias-output',node+build_args(local_source,dir_alias/local_source.name),ROOT,False)
for name,content in [('empty-source',b''),('truncated-source',raw[:500]),('invalid-utf8',b'\xff'),('changed-source-case',raw.upper())]:
    bad=DIRECTORY/(name+'.dict');bad.write_bytes(content);out=DIRECTORY/(name+'.json')
    run(name,node+build_args(bad,out),ROOT,False);assert not out.exists()
run('missing-source',node+build_args(DIRECTORY/'missing.dict',DIRECTORY/'missing-source.json'),ROOT,False)
for name,extra in [('unknown-argument',['--overwrite','yes']),('duplicate-argument',['--source',str(local_source)])]:
    out=DIRECTORY/(name+'.json');run(name,node+build_args(local_source,out)+extra,ROOT,False);assert not out.exists()
run('unsupported-units',node+['--source',str(local_source),'--policy','cmu-ascii-first-v1','--units','percentages','--out',str(DIRECTORY/'units.json')],ROOT,False)
for name,target in [('protected-prior-length-package',ROOT/'evaluation/experiments/cmu-length-builder/transition-must-not-exist.json'),('protected-demo',ROOT/'demo/transition-must-not-exist.json')]:
    assert not target.exists();run(name,node+build_args(local_source,target),ROOT,False);assert not target.exists()
for name,directory in [('protected-evidence-alias',ROOT/'evaluation/experiments'),('protected-runtime-alias',ROOT/'src')]:
    link=DIRECTORY/name;link.symlink_to(directory,target_is_directory=True);target=link/'transition-must-not-exist.json'
    assert not target.exists();run(name,node+build_args(local_source,target),ROOT,False);assert not target.exists()
run('missing-output-parent',node+build_args(local_source,DIRECTORY/'missing/out.json'),ROOT,False)
run('independent-full-bin-recount',['python3',str(ROOT/'evaluation/corpus/verify-transitions.py'),'--root',str(ROOT),'--source',str(local_source),'--artifact',str(first),'--out',str(DIRECTORY/'verification.json')],ROOT,True)
assert first.read_bytes()==second.read_bytes()==artifact_bytes
stable();proof=json.loads((DIRECTORY/'verification.json').read_bytes())
report={'version':'cmu-transition-formal-acceptance-v1','executionPlanSha256':SHA((DIRECTORY/'execution-plan.json').read_bytes()),'reviewFreezeSha256':SHA(freeze_bytes),'runnerSha256':SHA(pathlib.Path(__file__).read_bytes()),'artifactSha256':SHA(artifact_bytes),'artifactDigest':envelope['digest'],'implementationDigest':envelope['artifact']['implementation']['digest'],'independentVerificationSha256':SHA((DIRECTORY/'verification.json').read_bytes()),'entries':proof['entries'],'phoneEvents':proof['phoneEvents'],'views':proof['views'],'twoFreshBuildsByteIdentical':True,'allIndependentPairBinsExact':proof['allNativeBaseBinsExact'],'allParentInputsPreserved':True,'unchangedParentFiles':261,'commands':[{'name':x['name'],'exitCode':x['exitCode'],'expectedSuccess':x['expectedSuccess']} for x in commands]}
save(DIRECTORY/'acceptance.json',report)
print(json.dumps(report,indent=2))

import assert from "node:assert/strict";
import {createReadStream,readFileSync,writeFileSync,existsSync} from "node:fs";
import {createInterface} from "node:readline";
import {createGunzip} from "node:zlib";
import {createHash} from "node:crypto";
import {pathToFileURL} from "node:url";
const directory="/private/tmp/q07-q08-merged-composition-v1";
const sha=bytes=>createHash("sha256").update(bytes).digest("hex");
while(!existsSync(directory+"/registration.json")){ await new Promise(resolve=>setTimeout(resolve,1000)); }
const registration=JSON.parse(readFileSync(directory+"/registration.json"));
while(!existsSync(directory+"/native-complete.json")){
  assert(!existsSync(directory+"/native-failure.json"),"Native composition driver failed");
  await new Promise(resolve=>setTimeout(resolve,1000));
}
assert(JSON.parse(readFileSync(directory+"/native-complete.json")).executionPassed);
const nodePin=sha(readFileSync(process.execPath));
const loader="/Users/ryanbetts/Code/unglish/word-generator/node_modules/tsx/dist/loader.mjs";
const loaderPin=sha(readFileSync(loader));
const checkSource=arm=>{
  for(const pin of registration.currentHeadFilePins[arm]){
    const bytes=readFileSync(directory+"/"+arm+"/"+pin.file);
    assert.equal(bytes.length,pin.bytes,pin.file);assert.equal(sha(bytes),pin.sha256,pin.file);
  }
};
const {emptyObservation,observe}=await import(pathToFileURL("/private/tmp/q08a-acceptance-revalidation-v1/candidate/evaluation/quality/probes/syllable-weight/shared.ts"));
assert.equal(nodePin,registration.nodePin.sha256);assert.equal(loaderPin,registration.tsxLoaderPin.sha256);
const report={startedAt:new Date().toISOString(),heads:registration.heads,nodeVersion:process.version,nodeSha256:nodePin,tsxLoaderSha256:loaderPin,arms:{},
  publicTraceOffWords:40000,weightObservationsBothArms:true,
  scope:"All400000words and complete traces replayed through untouched current source public generateWord with original profile options,seeds and continuous streams. RNG callback counts/next values are observed replay diagnostics,not paired to unrecorded capture RNG counts. Fixed seeds do not prove probabilistic independence; all per-draw callback boundaries recorded,original trace-off prefixes match words and callbacks,full root weight/stress observed both arms. No cross-arm legacy/RNG equality expected after Q07 weighting. No later-main beyond named heads,human gain or timing claim."};
for(const arm of ["control","candidate"]){
  checkSource(arm);
  const api=await import(pathToFileURL(directory+"/"+arm+"/src/index.ts").href);
  const manifest=JSON.parse(readFileSync(directory+"/"+arm+"-run/manifest.json")).manifest;
  assert.deepEqual(manifest.protocol,registration.protocol);
  const streams=[];
  for(const profile of registration.protocol.profiles){
    for(const seed of profile.seeds.development){
      const filename="words/"+profile.id+"-"+seed+".jsonl.gz";
      const pin=manifest.artifacts.find(p=>p.file===filename);
      assert(pin);
      const compressed=readFileSync(directory+"/"+arm+"-run/"+filename);
      assert.equal(compressed.length,pin.bytes);assert.equal(sha(compressed),pin.sha256);
      const seeded=api.createSeededRng(seed);let rngCalls=0,index=0;
      const rand=()=>{rngCalls++;return seeded();};
      const input=createReadStream(directory+"/"+arm+"-run/"+filename).pipe(createGunzip());
      const lines=createInterface({input,crlfDelay:Infinity});
      const actualHash=createHash("sha256"),archivedHash=createHash("sha256"),boundaries=createHash("sha256"),prefixBoundaries=createHash("sha256");
      const weight=emptyObservation();const prefixWords=[];let prefixCalls=0;
      for await(const line of lines){
        const draw=JSON.parse(line);
        assert.equal(draw.profile,profile.id);assert.equal(draw.seed,seed);assert.equal(draw.drawIndex,index);
        const actual=JSON.parse(JSON.stringify(api.generateWord({...profile.options,rand,trace:true})));
        assert.deepEqual(actual,draw.word,arm+"/"+profile.id+"/"+seed+"/"+index);
        actualHash.update(JSON.stringify(actual)+"\n");archivedHash.update(JSON.stringify(draw.word)+"\n");
        boundaries.update(`${index}:${rngCalls}\n`);
        observe(actual,index,"candidate",weight);
        if(index<1000){
          prefixBoundaries.update(`${index}:${rngCalls}\n`);prefixCalls=rngCalls;
          const withoutTrace={...actual};delete withoutTrace.trace;prefixWords.push(withoutTrace);
        }
        index++;
      }
      assert.equal(index,10000);assert.equal(index,registration.protocol.wordsPerReplicate);
      const actualDigest=actualHash.digest("hex"),archivedDigest=archivedHash.digest("hex");
      assert.equal(actualDigest,archivedDigest);
      const offRng=api.createSeededRng(seed);let offCalls=0;const offBoundaries=createHash("sha256");
      const offRand=()=>{offCalls++;return offRng();};
      for(let draw=0;draw<1000;draw++){
        const off=JSON.parse(JSON.stringify(api.generateWord({...profile.options,rand:offRand,trace:false})));
        assert.deepEqual(off,prefixWords[draw],`trace-off/${arm}/${profile.id}/${seed}/${draw}`);
        offBoundaries.update(`${draw}:${offCalls}\n`);
      }
      const prefixDigest=prefixBoundaries.digest("hex");
      assert.equal(offCalls,prefixCalls);assert.equal(offBoundaries.digest("hex"),prefixDigest);
      streams.push({profile:profile.id,seed,words:index,rngCalls,nextRngValue:seeded(),completeWordTraceSha256:actualDigest,
        rngBoundarySha256:boundaries.digest("hex"),traceOffPrefixWords:1000,traceOffPrefixRngCalls:offCalls,
        traceOffPrefixBoundarySha256:prefixDigest,traceOffPrefixNextRng:offRng(),weightObservations:weight});
      console.log(arm+"/"+profile.id+"/"+seed+": "+index+" complete public replays");
    }
  }
  checkSource(arm);
  report.arms[arm]={words:streams.reduce((n,s)=>n+s.words,0),streams,completeWordsAndTracesEqual:true};
  assert.equal(report.arms[arm].words,200000);
}
assert.equal(sha(readFileSync(process.execPath)),nodePin);assert.equal(sha(readFileSync(loader)),loaderPin);
report.completedAt=new Date().toISOString();
writeFileSync(directory+"/public-replay.json",JSON.stringify(report,null,2)+"\n",{flag:"wx"});
console.log(JSON.stringify({controlWords:report.arms.control.words,candidateWords:report.arms.candidate.words,completeWordsAndTracesEqual:true}));


"""Check every merged candidate against the full earlier verified Q07 archive."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json

ROOT = Path(__file__).resolve().parent.parent
RUN = Path("/private/tmp/q07-q08-merged-composition-v1")
OLD = ROOT / ".local-evidence/q07-current-composition-retained-v1/candidate-run"
NEW = RUN / "candidate-run"


def load(path):
    return json.loads(path.read_text())


def verify(data, record):
    assert len(data) == record["bytes"] and hashlib.sha256(data).hexdigest() == record["sha256"], record["file"]


assert load(RUN / "native-complete.json")["executionPassed"]
registration = load(RUN / "registration.json")
manifests = [load(path / "manifest.json")["manifest"] for path in [OLD, NEW]]
assert manifests[0]["generator"]["commit"] == "fa8c537ee523a082e5d9859a75a7dddb271dabd8"
assert manifests[1]["generator"]["commit"] == registration["heads"]["candidate"]
for manifest in manifests:
    assert manifest["protocol"] == registration["protocol"]
    assert manifest["evaluatorDigest"] == registration["evaluatorDigest"]
    assert not manifest["generator"]["dirty"]
streams, witnesses = [], []
for profile in registration["protocol"]["profiles"]:
    for seed in profile["seeds"]["development"]:
        name = f"words/{profile['id']}-{seed}.jsonl.gz"
        counts = {"pairs": 0, "legacyPayloadChanges": 0, "syllableChanges": 0, "pronunciationChanges": 0, "writtenChanges": 0}
        for path, manifest in zip([OLD, NEW], manifests):
            record = next(item for item in manifest["artifacts"] if item["file"] == name)
            verify((path / name).read_bytes(), record)
        with gzip.open(OLD / name, "rt") as old_stream, gzip.open(NEW / name, "rt") as new_stream:
            for index, (before_line, after_line) in enumerate(zip(old_stream, new_stream, strict=True)):
                before, after = json.loads(before_line), json.loads(after_line)
                for draw in [before, after]:
                    assert (draw["profile"], draw["seed"], draw["drawIndex"]) == (profile["id"], seed, index)
                legacy = dict(after["word"])
                legacy["trace"] = dict(legacy["trace"])
                assert "stressWeight" in legacy["trace"]
                del legacy["trace"]["stressWeight"]
                counts["pairs"] += 1
                counts["legacyPayloadChanges"] += legacy != before["word"]
                for field, counter in [("syllables", "syllableChanges"), ("pronunciation", "pronunciationChanges"), ("written", "writtenChanges")]:
                    counts[counter] += legacy[field] != before["word"][field]
                if legacy != before["word"] and len(witnesses) < 3:
                    witnesses.append({"before": before, "after": after, "legacyAfter": legacy})
        assert counts["pairs"] == 10000
        streams.append({"profile": profile["id"], "seed": seed, **counts})
        print(json.dumps(streams[-1]), flush=True)
for arm, pins in registration["currentHeadFilePins"].items():
    for record in pins:
        verify((RUN / arm / record["file"]).read_bytes(), record)
totals = {key: sum(stream[key] for stream in streams) for key in streams[0] if key not in ["profile", "seed"]}
assert totals["pairs"] == 200000
report = {"observedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "oldCandidate": manifests[0]["generator"]["commit"], "newCandidate": manifests[1]["generator"]["commit"],
          "totals": totals, "streams": streams, "firstThreeChangedFullWitnesses": witnesses,
          "legacyParity": totals["legacyPayloadChanges"] == 0,
          "scope": "Every200000ordinalpair at the original full development schedule after removing only new trace.stressWeight. Old/current actual raw artifacts authenticated; complete changes counted and bounded full witnesses preserved. Archival RNG callbacks are unrecorded; this comparison is not an unobserved RNG or human-quality verdict."}
with (RUN / "legacy-comparison.json").open("x") as stream:
    stream.write(json.dumps(report, indent=2) + "\n")
print(json.dumps(totals), flush=True)

"""Retain both full current archives, source, operators and recorded outcomes."""
from pathlib import Path
import ctypes
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent.parent
RUN = Path("/private/tmp/q07-q08-merged-composition-v1")
OLD = Path("/private/tmp/q08a-acceptance-revalidation-v1/candidate")
OUT = ROOT / ".local-evidence/q07-q08-merged-composition-retained-v1"


def load(path):
    return json.loads(path.read_text())


def pin(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def write_json(path, value):
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")


inputs = {}


def add(name, source):
    assert name not in inputs, name
    assert source.is_file(), source
    inputs[name] = source


def tree(label, directory):
    for path in sorted(directory.rglob("*")):
        if path.is_file():
            add(label + "/" + path.relative_to(directory).as_posix(), path)


while not (RUN / "native-timing-complete.json").exists():
    for failure in ["native-failure.json", "gates-failure.json", "native-timing-failure.json"]:
        assert not (RUN / failure).exists(), failure
    time.sleep(1)
registration = load(RUN / "registration.json")
replay = load(RUN / "public-replay.json")
independent = load(RUN / "independent-recount.json")
legacy = load(RUN / "legacy-comparison.json")
gates = load(RUN / "gates-complete.json")
timing = load(RUN / "native-timing-complete.json")
assert sum(arm['words'] for arm in replay['arms'].values()) == 400000
assert independent['control']['words'] == independent['candidate']['words'] == 200000
assert independent['heads'] == replay['heads'] == registration['heads']
assert all(arm['completeWordsAndTracesEqual'] and len(arm['streams']) == 20 for arm in replay['arms'].values())
assert all(independent[arm]['completeWeightObservationsAndWitnessesMatch'] for arm in ['control','candidate'])
assert legacy['legacyParity'] and legacy['totals']['pairs'] == 200000
assert gates['commands'] == 15 and gates['passingCommands'] == 13 and gates['failingCommands'] == 2
assert timing['runs'] == timing['passingRuns'] == 12 and timing['pairs'] == 6
control_lint = (RUN / 'control-current-lint.log').read_text().replace(str(RUN / 'control'), 'CHECKOUT')
candidate_lint = (RUN / 'candidate-current-lint.log').read_text().replace(str(RUN / 'candidate'), 'CHECKOUT')
assert control_lint == candidate_lint and '10 problems (10 errors, 0 warnings)' in control_lint
write_json(RUN / 'lint-equivalence.json', {'exactLogsEqualAfterCheckoutPathNormalization':True,'errorsPerArm':10,'scope':'Only checkout paths normalized; all original failures preserved.'})
tree("control-run", RUN / "control-run")
tree("candidate-run", RUN / "candidate-run")
for comparison in ['candidate-vs-control','candidate-vs-original','control-vs-original']:
    tree(comparison, RUN / comparison)
tree('legacy-reference-run', ROOT / '.local-evidence/q07-current-composition-retained-v1/candidate-run')
baseline = ROOT / 'evaluation/quality/baselines/2026-09-26-development-standalone'
for path in sorted(baseline.iterdir()):
    if path.is_file():
        add('original-baseline-compact/' + path.name, path)
for path in sorted(RUN.iterdir()):
    if path.is_file():
        add("execution/" + path.name, path)
for name in ["q07-q08-merged-composition-capture-v1.log", "q07-q08-merged-public-replay-v1.log", "q07-q08-merged-independent-recount-v1.log", "q07-q08-merged-legacy-comparison-v1.log", "q07-q08-merged-gates-v1.log", "q07-q08-merged-native-timing-v1.log"]:
    add("execution/" + name, Path("/private/tmp") / name)
for arm, pins in registration["currentHeadFilePins"].items():
    source = RUN / arm
    assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=source, text=True).strip() == registration["heads"][arm]
    for record in pins:
        name = record["file"]
        expected = {key:record[key] for key in ["bytes","sha256"]}
        assert pin(source / name) == expected, (arm, name)
        add("source/" + arm + "/" + name, source / name)
    for name in ["tsconfig.json", "vitest.config.ts", "vitest.quality.config.ts", "vitest.perf.config.ts"]:
        assert (source / name).read_bytes() == subprocess.check_output(["git", "show", "HEAD:" + name], cwd=source)
        add("source/" + arm + "/" + name, source / name)
    for record in load(RUN / "gate-policy-before-v2.json")["gatePins"][arm]:
        path = RUN / ("historical-gates-v2-" + arm) / record["file"]
        assert pin(path) == {key: record[key] for key in ["bytes", "sha256"]}
        assert path.read_bytes() == (OLD / record["file"]).read_bytes()
        add("historical-gates/" + arm + "/" + record["file"], path)
for path in sorted((RUN / "measurement-candidate/evaluation/quality").iterdir()):
    if path.is_file():
        add("frozen-evaluator/" + path.name, path)
tree("frozen-weight-observer", OLD / "evaluation/quality/probes/syllable-weight")
add('frozen-nucleus-observer/nucleus-edges.ts', RUN / 'measurement-candidate/evaluation/quality/probes/nucleus-edges.ts')
tree('frozen-morphology-observer', RUN / 'measurement-candidate/evaluation/quality/probes/resolved-allomorphs')
for name in ['q07-q08-merged-composition-capture-v1.py','q07-q08-merged-public-replay-v1.mjs','q07-q08-merged-independent-recount-v1.py','q07-q08-merged-legacy-comparison-v1.py','q07-q08-merged-gates-v1.py','q07-q08-merged-native-timing-v1.py','q07-q08-merged-retain-v1.py','q08a_current_independent_helpers.py','q08a_independent_core.py']:
    add('operator/' + name, ROOT / '.local-evidence' / name)
# The prior runtime index is an authenticated enumeration of the actual Node/TSX closure.
# Read current physical files and require their complete bytes/hashes to match it.
runtime_index = load(ROOT / ".local-evidence/q07-current-composition-retained-v1/index.json")
runtime_files = [record for record in runtime_index["files"] if record["file"].startswith("runtime/")]
assert len(runtime_files) == 75
for record in runtime_files:
    path = Path(record["source"])
    assert pin(path) == {key: record[key] for key in ["bytes", "sha256"]}, path
    add(record["file"], path)
assert pin(inputs["runtime/node"]) == registration["nodePin"]
assert pin(Path("/Users/ryanbetts/Code/unglish/word-generator/node_modules/tsx/dist/loader.mjs")) == registration["tsxLoaderPin"]
logical_bytes = sum(path.stat().st_size for path in inputs.values())
free_bytes = shutil.disk_usage(OUT.parent).free
assert free_bytes >= logical_bytes + 2 * 1024 ** 3, (free_bytes, logical_bytes)
assert not OUT.exists()
OUT.mkdir()
libc = ctypes.CDLL(None, use_errno=True)
libc.clonefile.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int]
libc.clonefile.restype = ctypes.c_int
records = []
for name, source in sorted(inputs.items()):
    expected = pin(source)
    target = OUT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    if libc.clonefile(os.fsencode(source.resolve()), os.fsencode(target), 0):
        raise OSError(ctypes.get_errno(), "Evidence clone failed", str(source))
    assert target.stat().st_ino != source.stat().st_ino
    assert target.read_bytes() == source.read_bytes() and pin(target) == expected
    records.append({"file": name, "source": str(source), **expected, "independentInode": True})
for record in records:
    assert pin(OUT / record["file"]) == {key: record[key] for key in ["bytes", "sha256"]}
index = {"schemaVersion": 1, "observedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
         "heads": registration["heads"], "files": records,
         "storageGuard": {"freeBytesBefore": free_bytes, "logicalCopyBytes": logical_bytes, "reserveBytes": 2 * 1024 ** 3},
         "scope": "Full both-arm400000-word merged composition archive plus complete200000-word earlier Q07 legacy reference; complete measured src/CMU/package/config pins, frozen evaluator and original observer, original gates, operators, replay/recount and timing outcomes; selected actual Node/TSX closure. Every independently owned COW inode has full-byte/hash verification. Shared extents are not an independent-device backup. Full Node/Python/Vitest/ESLint/TypeScript installations and Git history remain external. Original-baseline compact reports retained; its raw files remain external. No human or overall linguistic/performance gain verdict."}
write_json(OUT / "index.json", index)
quantity_totals = {}
for arm in ['control','candidate']:
    streams = independent[arm]['weightStreams']
    quantity_totals[arm] = {key:sum(stream['observations'][key] for stream in streams)
                           for key in ['words','unavailable','observedSyllables','secondaryCandidates','secondaryApplied','finalStressCheckedWords','finalStressUnavailableWords']}
    quantity_totals[arm]['nuclearSegments'] = independent[arm]['nuclearSegments']
report = {'observedAt':index['observedAt'],'heads':registration['heads'],'registeredWordsPerArm':200000,
          'publicTracedWords':400000,'independentRawRecords':400000,'traceOffPrefixWords':40000,
          'legacyReferencePairs':200000,'legacyReferenceParity':legacy['legacyParity'],
          'quantityAndStress':quantity_totals,'gateCommands':15,'passingGateCommands':13,'failingGateCommands':2,
          'sameInheritedLintErrors':10,'nativeTiming':timing,
          'retained':{'directory':str(OUT.relative_to(ROOT)),'files':len(records),'bytes':logical_bytes,'indexSha256':pin(OUT/'index.json')['sha256']},
          'scope':'Full exact-maincd96f54versusc15565a merged Q07/Q08a composition public/native/independent evidence, all400000core/nucleus/morphology/rootquantity counts and witnesses, original trace-off prefixes, original/current gates/timings and full retention. All200000candidate legacy payloads match earlierfa8Q07 after removing onlystressWeight; archival RNG history remains unrecorded. Earlier Q07 full200000raw reference additionally retained; original-baseline compact evidence retained but its rawwords/runtime prerequisites remainexternal. Quantity remains unspecified; affixed finalrootstress unavailable. Supporting publication remains separate. No human quality/Englishquantity/seed-independence/stableperformance or later-main verdict.'}
write_json(ROOT / '.local-evidence/q07-q08-merged-composition-acceptance-v1.json', report)
print(json.dumps(report),flush=True)

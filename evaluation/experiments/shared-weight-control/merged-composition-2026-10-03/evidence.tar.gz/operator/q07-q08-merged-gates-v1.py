from pathlib import Path
import json,subprocess,datetime,hashlib,traceback,time
OUT=Path("/private/tmp/q07-q08-merged-composition-v1");ROOT=Path.cwd();NODE="/Users/ryanbetts/.nvm/versions/node/v24.11.1/bin/node"
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest()
OLD=Path("/private/tmp/q07-acceptance-revalidation-v1/source")
while not (OUT/"public-replay.json").exists():
 assert not (OUT/"native-failure.json").exists()
 time.sleep(1)
gate_files=["src/core/ngram-quality.test.ts","src/core/phoneme-quality.test.ts","src/core/phoneme-quality.ts","src/config/phoneme-thresholds.json","src/config/ngram-thresholds.json","src/core/quality.test.ts","vitest.config.ts","vitest.quality.config.ts"]
pins={}
for arm in ["control","candidate"]:
 source=OUT/arm;gate=OUT/("historical-gates-v2-"+arm)
 subprocess.run(["git","clone","--shared",str(source),str(gate)],check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (gate/"node_modules").mkdir()
 for p in (source/"node_modules").iterdir(): (gate/"node_modules"/p.name).symlink_to(p.resolve(),target_is_directory=p.is_dir())
 pins[arm]=[]
 for file in gate_files:
  body=(OLD/file).read_bytes();(gate/file).write_bytes(body)
  pins[arm].append({"file":file,"sha256":sha(body),"bytes":len(body)})
 for path in ["data/cmu/cmu-lexicon-phonemes.json","data/cmu/cmu-lexicon-bigrams.json","data/cmu/cmu-lexicon-trigrams.json","data/cmu/phoneme-normalization.json"]:
  assert (OLD/path).read_bytes()==(gate/path).read_bytes(),"Historical gate reference changed"
(OUT/"gate-policy-before-v2.json").write_text(json.dumps({"observedAt":now(),"historicalSourceHead":"7c37b6c17672f82bbe97570a00b0c4e19ef7c847","gatePins":pins,"scope":"Separate historical-gate clones retain unchanged original test operators,metric helpers,thresholds,sample sizes,seeds and configs. Actual current control/candidate checkouts stay untouched and run their own full suites/lint/types. Historical quality helpers/thresholds are gate policy,not a change to measured runtime or upstream. Native performance source/config unchanged; timings run separately."},indent=2)+"\n")
commands=[]
for arm in ["control","candidate"]:
 commands += [(arm+"-current-types",arm,[NODE,"node_modules/typescript/bin/tsc","--noEmit"]),
 (arm+"-current-unit",arm,[NODE,"node_modules/vitest/vitest.mjs","run"]),
 (arm+"-current-quality",arm,[NODE,"node_modules/vitest/vitest.mjs","run","--config","vitest.quality.config.ts"]),
 (arm+"-current-lint",arm,[NODE,"node_modules/eslint/bin/eslint.js","src/**/*.ts","evaluation/review/**/*.ts","evaluation/quality/**/*.ts","demo/review/**/*.ts"])]
 for name,args in [("original-ngram",[NODE,"node_modules/vitest/vitest.mjs","run","src/core/ngram-quality.test.ts"]),("original-phoneme",[NODE,"node_modules/vitest/vitest.mjs","run","src/core/phoneme-quality.test.ts"]),("original-quality",[NODE,"node_modules/vitest/vitest.mjs","run","--config","vitest.quality.config.ts"])]:
  commands.append((arm+"-"+name,"historical-gates-v2-"+arm,args))
commands.append(("candidate-current-targeted","candidate",[NODE,"node_modules/vitest/vitest.mjs","run","src/core/nucleus-position.test.ts","src/core/morphology/realization.test.ts","src/core/syllable-weight.test.ts"]))
records=[]
try:
 for name,arm,args in commands:
  r={"name":name,"cwd":str(OUT/arm),"args":args,"startedAt":now()}
  (OUT/"active-gate-command.json").write_text(json.dumps(r,indent=2)+"\n")
  with (OUT/(name+".log")).open("xb") as log:p=subprocess.run(args,cwd=OUT/arm,stdout=log,stderr=subprocess.STDOUT)
  r.update({"completedAt":now(),"exitCode":p.returncode});records.append(r)
  (OUT/"gate-commands.json").write_text(json.dumps(records,indent=2)+"\n");print(json.dumps(r),flush=True)
 # Every pass/failure is retained; completing execution is distinct from passing.
 for arm,entries in pins.items():
  for e in entries:assert sha((OUT/("historical-gates-v2-"+arm)/e["file"]).read_bytes())==e["sha256"]
 registration=json.loads((OUT/"registration.json").read_text())
 for arm,entries in registration["currentHeadFilePins"].items():
  for e in entries:assert sha((OUT/arm/e["file"]).read_bytes())==e["sha256"]
 result={"completedAt":now(),"executionPassed":True,"commands":len(records),"passingCommands":sum(r["exitCode"]==0 for r in records),"failingCommands":sum(r["exitCode"]!=0 for r in records),"allMeasuredSourceAndOriginalGatePinsUnchanged":True,"scope":"All current and original-history gate checks executed with complete failures retained; no native timing or passing-every-gate/human-gain verdict."}
 (OUT/"gates-complete.json").write_text(json.dumps(result,indent=2)+"\n");print(json.dumps(result),flush=True)
except BaseException as e:
 (OUT/"gates-failure.json").write_text(json.dumps({"failedAt":now(),"error":repr(e),"traceback":traceback.format_exc(),"records":records},indent=2)+"\n");raise


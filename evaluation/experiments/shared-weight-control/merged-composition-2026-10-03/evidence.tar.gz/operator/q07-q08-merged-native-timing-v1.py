"""Run six alternating pairs of the unchanged original native timing tests."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import statistics
import subprocess
import traceback
import time

OUT = Path("/private/tmp/q07-q08-merged-composition-v1")
OLD = Path("/private/tmp/q08a-acceptance-revalidation-v1/candidate")
NODE = "/Users/ryanbetts/.nvm/versions/node/v24.11.1/bin/node"
NPM = str(Path(NODE).with_name("npm"))


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")


for prerequisite in ["gates-complete.json", "public-replay.json", "independent-recount.json", "legacy-comparison.json"]:
    while not (OUT / prerequisite).is_file():
        for failure in ["native-failure.json", "gates-failure.json"]:
            assert not (OUT / failure).exists(), failure
        time.sleep(1)
assert os.environ.get("CI") != "true", "Preserve native 4500 floor and 3 variance limit"
pins = {}
for arm in ["control", "candidate"]:
    pins[arm] = {}
    for name in ["src/core/generate.perf.test.ts", "vitest.perf.config.ts"]:
        data = (OUT / arm / name).read_bytes()
        assert data == (OLD / name).read_bytes(), (arm, name)
        pins[arm][name] = {"bytes": len(data), "sha256": digest(data)}
write_json("native-timing-before.json", {
    "observedAt": now(), "unchangedOriginalPerformanceSource": pins,
    "pairs": 6, "runs": 12, "nodeVersion": subprocess.check_output([NODE, "--version"], text=True).strip(),
    "nodeSha256": digest(Path(NODE).read_bytes()), "nativeFloor": 4500,
    "medianVarianceLimit": 3, "sourceSampleSize": 10000, "warmupCount": 50,
    "timeoutsMilliseconds": 20000,
    "activityScope": "All owned merged Q07/Q08a replay/recount/gate/legacy-comparison jobs completed before timing; Q23 science is terminal. No process stopped or restarted. Ambient desktop/simulator activity remains uncontrolled; ratios are descriptive.",
})
environment = dict(os.environ)
environment["PATH"] = str(Path(NODE).parent) + os.pathsep + environment.get("PATH", "")
records = []
try:
    for pair in range(1, 7):
        order = ["control", "candidate"] if pair % 2 else ["candidate", "control"]
        for arm in order:
            name = f"native-pair-{pair}-{arm}"
            args = [NPM, "run", "test:perf"]
            record = {"name": name, "pair": pair, "arm": arm, "args": args, "cwd": str(OUT / arm), "startedAt": now()}
            write_json("active-native-timing.json", record)
            with (OUT / (name + ".log")).open("xb") as log:
                result = subprocess.run(args, cwd=OUT / arm, env=environment, stdout=log, stderr=subprocess.STDOUT)
            output = (OUT / (name + ".log")).read_text()
            throughput = re.search(r"Performance:\s*(\d+) words/sec \((\d+) words in (\d+)ms\)", output)
            variance = re.search(r"\(median ([0-9.]+)x\)", output)
            assert throughput and int(throughput[2]) == 10000 and "Floor: 4500 words/sec" in output
            assert variance and "Median variance threshold: < 3.0x" in output
            record.update({"completedAt": now(), "exitCode": result.returncode,
                           "roundedWordsPerSecond": int(throughput[1]), "roundedElapsedMilliseconds": int(throughput[3]),
                           "roundedMedianVariance": float(variance[1])})
            records.append(record)
            write_json("native-timing-records.json", records)
            print(json.dumps(record), flush=True)
    for arm, entries in pins.items():
        for name, pin in entries.items():
            assert digest((OUT / arm / name).read_bytes()) == pin["sha256"], (arm, name)
    assert digest(Path(NODE).read_bytes()) == json.loads((OUT / "native-timing-before.json").read_text())["nodeSha256"]
except BaseException as error:
    write_json("native-timing-failure.json", {"failedAt": now(), "error": repr(error), "traceback": traceback.format_exc(), "records": records})
    raise
assert len(records) == 12
ratios = []
for pair in range(1, 7):
    paired = {record["arm"]: record for record in records if record["pair"] == pair}
    ratios.append(paired["candidate"]["roundedWordsPerSecond"] / paired["control"]["roundedWordsPerSecond"])
completion = {"completedAt": now(), "executionPassed": True, "pairs": 6, "runs": 12,
              "passingRuns": sum(record["exitCode"] == 0 for record in records),
              "failingRuns": sum(record["exitCode"] != 0 for record in records),
              "candidateControlRoundedThroughputRatios": ratios,
              "medianCandidateControlRoundedThroughputRatio": statistics.median(ratios),
              "scope": "All twelve unchanged original native tests: 10000 words, 50 warmup, 4500 floor, variance below 3, 20000 ms timeout. Six alternating pairs; rounded log ratios are descriptive. Ambient activity, JIT and GC remain limitations. No human or stable performance gain verdict."}
write_json("native-timing-complete.json", completion)
print(json.dumps(completion), flush=True)

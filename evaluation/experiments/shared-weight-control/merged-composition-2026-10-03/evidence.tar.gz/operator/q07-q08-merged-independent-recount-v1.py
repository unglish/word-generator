import collections
import datetime
import gzip
import hashlib
import json
import time
from q08a_current_independent_helpers import empty, weight_observation
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RUN = Path('/private/tmp/q07-q08-merged-composition-v1')
while not (RUN / "public-replay.json").exists():
    assert not (RUN / "native-failure.json").exists(), "Native composition driver failed"
    time.sleep(1)
registration = json.loads((RUN / "registration.json").read_text())
public_replay = json.loads((RUN / "public-replay.json").read_text())



def load(path):
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == '.gz' else data)


def observations(word):
    syllables = word['syllables']
    trace = word['trace']
    morphology = trace.get('morphology', {})
    count = len(syllables)
    affixed = bool(trace['summary']['morphologyApplied'] and morphology
                   and morphology['template'] != 'bare'
                   and (morphology.get('prefix') or morphology.get('suffix')))
    eligible = {'words': True, 'polysyllables': count > 1, 'disyllables': count == 2,
                'monosyllables': count == 1, 'affixedWords': affixed}
    primaries = [s for s in syllables if s.get('stress') == 'ˈ']
    last = syllables[-1]
    flags = {
        'polysyllable_missing_primary': count > 1 and not primaries,
        'polysyllable_multiple_primary': count > 1 and len(primaries) > 1,
        'primary_schwa': any(p['sound'] == 'ə' for s in primaries for p in s['nucleus']),
        'primary_reduced_vowel': any(p.get('reduced') is True for s in primaries for p in s['nucleus']),
        'morphology_hiatus_bridge': affixed and any(e['event'] in
            ['morphPrefixHiatusFallback', 'morphSuffixHiatusFallback'] for e in trace['structural']),
        'zero_weight_grapheme_choice': any(len(g['weights']) > 1 and
            sum(weight for _, weight in g['weights']) == 0 for g in trace['graphemeSelections']),
        'orthography_trace_missing': 'orthography' not in trace,
        'orthography_surface_mismatch': 'orthography' in trace and
            trace['orthography']['surface'] != word['written']['clean'],
        'adjacent_duplicate_coda': any(a['sound'] == b['sound'] for s in syllables
            for a, b in zip(s['coda'], s['coda'][1:])),
        'disyllable_stress_clash': count == 2 and
            {'ˈ', 'ˌ'}.issubset({s.get('stress') for s in syllables}),
        'monosyllable_schwa': count == 1 and len(last['nucleus']) == 1 and last['nucleus'][0]['sound'] == 'ə',
        'final_open_checked_vowel': not last['coda'] and len(last['nucleus']) == 1 and
            last['nucleus'][0]['sound'] in {'ɪ', 'ɛ', 'æ', 'ʌ', 'ʊ'},
        'monosyllable_foot_vowel': count == 1 and any(p['sound'] == 'ʊ' for p in last['nucleus']),
    }
    return eligible, flags, morphology['template'] if affixed else 'bare'

def nucleus_counts(word):
    counts={'words':1,'layers':{},'edgeRepairWords':0,'stressRepickWords':0,
            'unavailableRepairs':0,'edgeRepairTransitions':{},'openCheckedAfterRepair':{'hits':0,'eligible':0}}
    stages=word['trace'].get('stages',[])
    generated=next((s['after'] for s in stages if s['name']=='generateSyllables'),None)
    prepared=next((s['before'] for s in stages if s['name']=='generateWrittenForm'),None)
    output=[{slot:[p['sound'] for p in s[slot]] for slot in ['onset','nucleus','coda']} for s in word['syllables']]
    for name,syllables in [('generatedBase',generated),('preparedBase',prepared),('output',output)]:
        values={'observed':int(bool(syllables)),'unavailable':int(not syllables),
                'measures':{k:{'hits':0,'eligible':0} for k in ['final','closedFinal','openFinalEdge','closedMonosyllable']}}
        if syllables:
            final=syllables[-1]; closed=bool(final['coda']); contains='ʊ' in final['nucleus']
            last_phone=final['nucleus'][-1] if final['nucleus'] else None
            opportunities={'final':(True,contains),'closedFinal':(closed,contains),
                           'openFinalEdge':(not closed,last_phone=='ʊ'),
                           'closedMonosyllable':(closed and len(syllables)==1,contains)}
            for k,(eligible,hit) in opportunities.items():
                values['measures'][k]={'hits':int(eligible and hit),'eligible':int(eligible)}
        counts['layers'][name]=values
    repairs=word['trace'].get('repairs')
    if repairs is None: counts['unavailableRepairs']=1
    else:
        edges=[r for r in repairs if r['rule']=='repairNucleusWordPositions']
        counts['edgeRepairWords']=int(bool(edges))
        counts['stressRepickWords']=int(any(r['rule']=='repairStressedNuclei' for r in repairs))
        for r in edges:
            key=r['before']+'->'+r['after']
            counts['edgeRepairTransitions'][key]=counts['edgeRepairTransitions'].get(key,0)+1
        if edges and prepared:
            last=prepared[-1]
            counts['openCheckedAfterRepair']={'eligible':1,'hits':int(not last['coda'] and bool(last['nucleus']) and last['nucleus'][-1] in {'ɪ','ɛ','æ','ʌ','ʊ'})}
    kinds=[]
    if prepared and 'ʊ' in prepared[-1]['nucleus']:
        kinds.append('closedFinalBaseFoot' if prepared[-1]['coda'] else 'openFinalBaseFoot')
        if len(prepared)==1 and prepared[-1]['coda']: kinds.append('closedMonosyllableFoot')
    if repairs and any(r['rule']=='repairNucleusWordPositions' for r in repairs):
        kinds.append('edgeRepair')
        if prepared and not prepared[-1]['coda'] and prepared[-1]['nucleus'] and prepared[-1]['nucleus'][-1] in {'ɪ','ɛ','æ','ʌ','ʊ'}:
            kinds.append('openCheckedAfterEdgeRepair')
    if repairs and any(r['rule']=='repairStressedNuclei' and r['after']=='ʊ' for r in repairs): kinds.append('stressRepickFoot')
    if output and not output[-1]['coda'] and output[-1]['nucleus'] and output[-1]['nucleus'][-1]=='ʊ': kinds.append('openFinalOutputFoot')
    return counts,kinds

def sum_counts(target,counts):
    for k,v in counts.items():
        if isinstance(v,dict): sum_counts(target.setdefault(k,{}),v)
        else: target[k]=target.get(k,0)+v


def form(source, fallback=None):
    return {'written':source.get('written',fallback),'phonemes':source['phonemes'],
            'syllableCount':source['syllableCount'],'syllables':source.get('syllables')}

def allomorph_observation(word, config):
    group={key:{} for key in ['counts','selections','boundaries','cleanupChanges']}
    def add(section,key,n=1):
        group[section][key]=group[section].get(key,0)+n
    add('counts','words')
    morph=word['trace'].get('morphology') or {}
    evidence=[]
    if not morph.get('prefix') and not morph.get('suffix'):
        return group,evidence,'none'
    kind='both' if morph.get('prefix') and morph.get('suffix') else 'prefix' if morph.get('prefix') else 'suffix'
    add('counts','affixedWords')
    realization=morph.get('realization')
    if realization is None:
        add('counts','unknownResolutionWords')
    else:
        add('counts','explicitResolutionWords')
        assembled,emitted=realization['assembledParts'],realization['emittedParts']
        add('counts','emittedOutputMismatchWords',int(''.join(p['text'] for p in emitted)!=word['written']['clean']))
        add('counts','partRoleMismatchWords',int([p['role'] for p in assembled]!=[p['role'] for p in emitted]))
        for role in ['prefix','suffix']:
            if not morph.get(role): continue
            add('counts','affixSelections')
            selected=realization.get(role)
            if selected is None:
                add('counts','missingAffixSelection'); continue
            variant_index=selected['allomorphIndex']
            key=f"{role}/{morph[role]}/{variant_index if variant_index is not None else 'base'}/{selected['resolved']['written']}"
            add('selections',key)
            add('boundaries',key+'/'+(selected.get('boundaryPhoneme') or {}).get('sound','unknown'))
            evidence.append('selection/'+key)
            add('counts','plannedLabelMismatch',int(selected['planned']['written']!=morph[role]))
            affixes=[a for a in config['morphology'][role+'es' if role=='prefix' else 'suffixes'] if a['written']==morph[role]]
            if len(affixes)!=1:
                add('counts','unknownConfigSelection')
            else:
                affix=affixes[0]
                variants=affix.get('allomorphs',[])
                variant=affix if variant_index is None else variants[variant_index] if 0<=variant_index<len(variants) else None
                add('counts','configSelectionsChecked')
                mismatch=variant is None or form(selected['planned'])!=form(affix) or form(selected['resolved'])!=form(variant,affix['written'])
                add('counts','configSelectionMismatch',int(mismatch))
            parts=[p for p in assembled if p['role']==role]
            mismatch=len(parts)!=1 or parts[0]['text']!=selected['resolved']['written']
            add('counts','selectedAffixAssemblyMismatch',int(mismatch))
            if mismatch: evidence.append('assembly-mismatch/'+role)
        changed=False
        for i,before in enumerate(assembled):
            after=emitted[i] if i<len(emitted) else None
            if after is None or before!=after:
                changed=True; add('cleanupChanges',before['role']); evidence.append('cleanup/'+before['role'])
        add('counts','wordsWithCleanupChanges',int(changed))
    if morph.get('prefix')=='in':
        add('counts','plannedInWords')
        stages=word['trace']['stages']; stage=stages[-1] if stages else None
        root=[p for s in stage['after'] for slot in ['onset','nucleus','coda'] for p in s[slot]] if stage and stage['name']=='generatePronunciation' else []
        phones=[p for p in config['phonemes'] if root and p['sound']==root[0]]
        if len(phones)!=1:
            add('counts','unknownDerivedInContextWords')
        else:
            add('counts','derivedInContextWords')
            if phones[0]['placeOfArticulation']=='bilabial':
                add('counts','sourceDerivedImEligibleWords')
                clean=word['written']['clean']
                spelling='im' if clean.startswith('im') else 'in' if clean.startswith('in') else 'other'
                add('counts','sourceDerivedImFinalSpelling:'+spelling)
                add('counts','sourceDerivedImCodaConfirmed',int([p['sound'] for p in word['syllables'][0]['coda']]==['m']))
                evidence.append('source-derived-im/'+spelling)
    return group,evidence,kind

def merge_observation(target,observation):
    for section,values in observation.items():
        for key,n in values.items():
            target[section][key]=target[section].get(key,0)+n



def recount(directory, candidate):
    summary = load(directory / 'summary.json')
    manifest = load(directory / 'manifest.json')['manifest']
    sources = load(directory / 'sources.json.gz')
    normalization = json.loads(next(f['content'] for f in sources['references']
                                   if f['path'].endswith('/phoneme-normalization.json')))['generatedAliases']
    archived_distributions = load(directory / 'distributions.json.gz')
    counters = {}
    weights = []
    native_weights = public_replay["arms"]["candidate" if candidate else "control"]["streams"]
    samples, witnesses = [], {}
    native_probe=load(RUN/('nucleus-candidate.json' if candidate else 'nucleus-control.json'))
    native_morphology=load(RUN/'allomorph-probe.json')['candidate' if candidate else 'baseline']
    config=manifest['generator']['effectiveConfig']
    in_affix=next(a for a in config['morphology']['prefixes'] if a['written']=='in')
    assert len(in_affix['allomorphs'])==1
    assert in_affix['allomorphs'][0]['phonologicalCondition']=={'position':'following','place':['bilabial']}
    assert form(in_affix['allomorphs'][0])=={'written':'im','phonemes':['ɪ','m'],'syllableCount':1,'syllables':[{'onset':[],'nucleus':['ɪ'],'coda':['m']}]}
    morphology_groups=collections.defaultdict(lambda:{k:{} for k in ['counts','selections','boundaries','cleanupChanges']})
    morphology_witnesses={}
    nucleus_groups=collections.defaultdict(dict); nucleus_witnesses={}
    for profile in summary['profiles']:
        ids = [definition['id'] for definition in summary['definitions']]
        denominators = {definition['id']: definition['denominator'] for definition in summary['definitions']}
        groups = collections.defaultdict(lambda: {metric: [0, 0] for metric in ids})
        words_by_group = collections.Counter()
        phones, trigrams = collections.Counter(), collections.Counter()
        spellings = set()
        syllable_counts, phone_lengths, morphology_counts = (collections.Counter() for _ in range(3))
        letters = 0
        for replicate in profile['replicates']:
            seed = replicate['seed']
            weight = empty()
            nuclear_segments = 0
            filename = f"words/{profile['id']}-{seed}.jsonl.gz"
            pin = next(p for p in manifest['artifacts'] if p['file'] == filename)
            raw = (directory / filename).read_bytes()
            assert len(raw) == pin['bytes'] and hashlib.sha256(raw).hexdigest() == pin['sha256']
            with gzip.open(directory / filename, 'rt') as stream:
                for index, line in enumerate(stream):
                    draw = json.loads(line)
                    assert (draw['profile'], draw['seed'], draw['drawIndex']) == (profile['id'], seed, index)
                    word = draw['word']
                    nuclear_segments += weight_observation(word, index, True, weight)
                    eligible, flags, morphology = observations(word)
                    assert set(flags) == set(ids)
                    stratum = f"{morphology}/syllables:{len(word['syllables'])}"
                    group_keys = ['profile', ('replicate', seed), ('stratum', stratum)]
                    for key in group_keys:
                        words_by_group[key] += 1
                        for metric in ids:
                            if eligible[denominators[metric]]:
                                groups[key][metric][1] += 1
                                groups[key][metric][0] += bool(flags[metric])
                    clean = word['written']['clean']
                    spellings.add(clean)
                    letters += len(clean.encode('utf-16-le')) // 2
                    syllable_counts[str(len(word['syllables']))] += 1
                    morphology_counts[morphology] += 1
                    length = 0
                    for syllable in word['syllables']:
                        for segment in ['onset', 'nucleus', 'coda']:
                            for phone in syllable[segment]:
                                sound = phone['sound'].replace('ʰ', '')
                                phones[normalization.get(sound, sound)] += 1
                                length += 1
                    phone_lengths[str(length)] += 1
                    spelling = clean.lower()
                    trigrams.update(spelling[i:i+3] for i in range(len(spelling)-2)
                                    if all('a' <= c <= 'z' for c in spelling[i:i+3]))
                    if index < manifest['protocol']['reviewDrawsPerReplicate']:
                        samples.append(draw)
                    for metric, flag in flags.items():
                        key = f"{profile['id']}/{metric}"
                        if flag and len(witnesses.get(key, [])) < 2:
                            witnesses.setdefault(key, []).append(draw)
                    morph_observation,morph_kinds,morph_type=allomorph_observation(word,config)
                    for key in ['total',('profile',profile['id']),('seed',f"{profile['id']}/{seed}"),('stratum',f"{profile['id']}/{morph_type}")]:
                        merge_observation(morphology_groups[key],morph_observation)
                    for kind in morph_kinds:
                        if len(morphology_witnesses.get(kind,[]))<3:
                            morphology_witnesses.setdefault(kind,[]).append(draw)
                    observed,kinds=nucleus_counts(word)
                    for key in [('profile',profile['id']),('seed',profile['id'],seed),('stratum',profile['id'],stratum)]:
                        sum_counts(nucleus_groups[key],observed)
                    for kind in kinds: nucleus_witnesses.setdefault(profile['id']+'/'+kind,draw)
            native_weight = next(s for s in native_weights if s['profile'] == profile['id'] and s['seed'] == seed)
            assert weight == native_weight['weightObservations'], (profile['id'], seed)
            weights.append({'profile': profile['id'], 'seed': seed, 'nuclearSegments': nuclear_segments, 'observations': weight})
            assert words_by_group[('replicate', seed)] == replicate['words'] == 10000
            print(f"{directory.name}/{profile['id']}/{seed}: 10000 independently recounted", flush=True)
        assert words_by_group['profile'] == profile['words'] == 50000
        assert len(spellings) == profile['uniqueSpellings'] and letters / profile['words'] == profile['meanLetters']
        assert dict(syllable_counts) == profile['syllableCounts']
        assert dict(phone_lengths) == profile['phonemeLengths']
        assert dict(morphology_counts) == profile['morphologyCounts']
        assert dict(phones) == archived_distributions[profile['id']]['phonemes']
        assert dict(trigrams) == archived_distributions[profile['id']]['trigrams']
        expected = [('profile', profile)]
        expected += [(('replicate', r['seed']), r) for r in profile['replicates']]
        expected += [(('stratum', s['id']), s) for s in profile['strata']]
        assert {key[1] for key in words_by_group if isinstance(key, tuple) and key[0] == 'stratum'} == {s['id'] for s in profile['strata']}
        for key, recorded in expected:
            assert words_by_group[key] == recorded['words']
            for metric, (hits, eligible) in groups[key].items():
                assert recorded['metrics'][metric] == {'hits': hits, 'eligible': eligible,
                    'rate': hits / eligible if eligible else None}, (directory, profile['id'], key, metric)
        counters[profile['id']] = {'words': profile['words'], 'metrics': profile['metrics'],
                                  'strata': len(profile['strata']), 'phoneOpportunities': sum(phones.values()),
                                  'trigramOpportunities': sum(trigrams.values())}
    assert samples == load(directory / 'review-samples.json.gz')
    assert witnesses == load(directory / 'witnesses.json.gz')
    for profile in native_probe['profiles']:
        assert nucleus_groups[('profile',profile['id'])]==profile['totals']
        for rep in profile['replicates']:
            assert nucleus_groups[('seed',profile['id'],rep['seed'])]==rep['counts']
        actual={k[2]:v for k,v in nucleus_groups.items() if k[0]=='stratum' and k[1]==profile['id']}
        assert actual==profile['strata']
    assert nucleus_witnesses==native_probe['witnesses']
    assert morphology_groups['total']==native_morphology['total']
    for kind,plural in [('profile','profiles'),('seed','replicates'),('stratum','strata')]:
        actual={key[1]:value for key,value in morphology_groups.items() if isinstance(key,tuple) and key[0]==kind}
        assert actual==native_morphology[plural],plural
    assert morphology_witnesses==native_morphology['witnesses']
    return {'completeWeightObservationsAndWitnessesMatch':True,'weightStreams':weights,'nuclearSegments':sum(s['nuclearSegments'] for s in weights),'manifestDigest':load(directory/'manifest.json')['digest'],'words':200000,
            'profiles':counters,'completeReviewSamplesMatch':len(samples),
            'completeFirstTwoWitnessesMatch':sum(map(len,witnesses.values())),
            'allNucleusCountsMatch':True,'allMorphologyCountsMatch':True,'fullMorphologyWitnessesMatch':sum(map(len,morphology_witnesses.values())),'totalMorphologyCounts':morphology_groups['total']['counts'],'allFullNucleusWitnessesMatch':len(nucleus_witnesses),
            'nucleusProfiles':{p['id']:p['totals'] for p in native_probe['profiles']}}

assert (RUN/'native-complete.json').exists()
result={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'candidate':recount(RUN/'candidate-run',True),
        'control':recount(RUN/'control-run',False),
        'scope':'Independent Python full400000raw word recount, all13core metrics/profile/seed/actual morphology-length strata, full phone/trigram counts,histograms,samples,first-two traces and every native nucleus layer/measure/profile/seed/stratum/repair count and first full witness. Generated base,prepared base,output remain distinct; default edge-repair zero exposure remains unknown safety. Full native morphology totals/profile/seed/stratum/selection/boundary/cleanup maps and first-three full witnesses also match; resolved form configuration checked. Exact registered current control/candidate heads. Fixed seed streams; no probabilistic independence,current-main,timing,human gain or universal rime legality.'}
for arm, pins in registration['currentHeadFilePins'].items():
    for record in pins:
        data = (RUN / arm / record['file']).read_bytes()
        assert len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256']
result['heads'] = registration['heads']
result['scope'] += ' Full root weight/primary/secondary/bare-final observations and bounded witnesses independently match every native public stream in both arms;affixed final-root correspondence remains unavailable. Every current source pin unchanged.'
(RUN/'independent-recount.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'candidateWords':result['candidate']['words'],'controlWords':result['control']['words'],'allNucleusCountsMatch':True}))

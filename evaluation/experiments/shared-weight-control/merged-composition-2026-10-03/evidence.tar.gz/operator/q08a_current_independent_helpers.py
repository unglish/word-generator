from collections import Counter,defaultdict
from q08a_independent_core import load,observations

def empty():
    return {'words': 0, 'unavailable': 0, 'observedSyllables': 0,
            'quantity': {}, 'analytical': {}, 'operational': {}, 'primaryStrategies': {},
            'secondaryCandidates': 0, 'secondaryApplied': 0,
            'finalStressCheckedWords': 0, 'finalStressUnavailableWords': 0, 'witnesses': []}

def increment(result, section, key):
    result[section][key] = result[section].get(key, 0) + 1

def weight_observation(word, index, candidate, result):
    result['words'] += 1
    trace = word['trace']
    weight = trace.get('stressWeight')
    if not candidate:
        assert weight is None
        result['unavailable'] += 1
        if not result['witnesses']:
            result['witnesses'].append({'draw': index, 'word': word})
        return 0
    assert weight and weight['version'] == 1 and weight['stage'] == 'applyStress'
    assert weight['domain'] == 'root-before-nucleus-repair'
    assert weight['policy'] == {'type': 'legacy-segment-count'}
    stages = [stage for stage in trace['stages'] if stage['name'] == 'applyStress']
    assert len(stages) == 1
    root = stages[0]['before']
    assert len(weight['syllables']) == len(root)
    heavy = False
    segments = 0
    for i, (analyzed, source) in enumerate(zip(weight['syllables'], root)):
        assert analyzed['syllableIndex'] == i and analyzed['coda'] == source['coda']
        assert [phone['sound'] for phone in analyzed['nucleus']] == source['nucleus']
        assert analyzed['nucleusMoras'] is None
        assert analyzed['analytical'] == {'weight': 'unknown', 'basis': 'legacy-policy'}
        operational = 'heavy' if source['coda'] or len(source['nucleus']) > 1 else 'light'
        assert analyzed['operational'] == {'weight': operational, 'basis': 'legacy-rule'}
        heavy |= operational == 'heavy'
        result['observedSyllables'] += 1
        increment(result, 'analytical', 'unknown:legacy-policy')
        increment(result, 'operational', operational + ':legacy-rule')
        for j, phone in enumerate(analyzed['nucleus']):
            assert phone['segmentIndex'] == j and 'declared' not in phone
            assert phone['quantity'] == {'status': 'unknown', 'reason': 'unspecified'}
            increment(result, 'quantity', 'unknown:unspecified')
            segments += 1
    primary = weight['primary']['selectedIndex']
    assert (primary is None) if len(root) <= 1 else (isinstance(primary, int) and 0 <= primary < len(root))
    assert weight['primary']['strategy'] == 'ot'
    increment(result, 'primaryStrategies', 'ot')
    candidates = weight['secondary']['candidates']
    expected = [] if primary is None else [i for i in range(min(3, len(root))) if i != primary]
    assert [item['syllableIndex'] for item in candidates] == expected
    for item in candidates:
        expected_weight = 70 if weight['syllables'][item['syllableIndex']]['operational']['weight'] == 'heavy' else 30
        assert item['weight'] == expected_weight
    result['secondaryCandidates'] += len(candidates)
    selected = weight['secondary']['selectedIndex']
    assert (not candidates) if selected is None else selected in expected
    if weight['secondary']['applied']:
        assert selected is not None
        result['secondaryApplied'] += 1
    morph = trace.get('morphology') or {}
    if morph.get('prefix') or morph.get('suffix'):
        result['finalStressUnavailableWords'] += 1
    else:
        result['finalStressCheckedWords'] += 1
        assert len(word['syllables']) == len(root)
        primaries = [i for i, s in enumerate(word['syllables']) if s.get('stress') == 'ˈ']
        assert (primaries[0] if primaries else None) == primary
        if weight['secondary']['applied']:
            assert word['syllables'][selected]['stress'] == 'ˌ'
    categories = [any(s['operational']['weight'] == 'heavy' for s in w['word']['trace']['stressWeight']['syllables'])
                  for w in result['witnesses']]
    if heavy not in categories:
        result['witnesses'].append({'draw': index, 'word': word})
    return segments

class CoreCounts:
    def __init__(self, summary, distributions, normalization):
        self.summary = summary
        self.distributions = distributions
        self.normalization = normalization
        self.ids = [definition['id'] for definition in summary['definitions']]
        self.denominators = {definition['id']: definition['denominator'] for definition in summary['definitions']}
        self.samples, self.witnesses = [], {}
        self.profiles = {}

    def start(self):
        self.groups = defaultdict(lambda: {metric: [0, 0] for metric in self.ids})
        self.words = Counter()
        self.phones, self.trigrams = Counter(), Counter()
        self.spellings = set()
        self.syllables, self.lengths, self.morphology = Counter(), Counter(), Counter()
        self.letters = 0

    def add(self, draw):
        profile, seed, index, word = (draw[k] for k in ['profile', 'seed', 'drawIndex', 'word'])
        eligible, flags, morph = observations(word)
        assert set(flags) == set(self.ids)
        stratum = f"{morph}/syllables:{len(word['syllables'])}"
        for key in ['profile', ('seed', seed), ('stratum', stratum)]:
            self.words[key] += 1
            for metric in self.ids:
                if eligible[self.denominators[metric]]:
                    self.groups[key][metric][1] += 1
                    self.groups[key][metric][0] += bool(flags[metric])
        clean = word['written']['clean']
        self.spellings.add(clean)
        self.letters += len(clean.encode('utf-16-le')) // 2
        self.syllables[str(len(word['syllables']))] += 1
        self.morphology[morph] += 1
        length = 0
        for syllable in word['syllables']:
            for slot in ['onset', 'nucleus', 'coda']:
                for phone in syllable[slot]:
                    sound = phone['sound'].replace('ʰ', '')
                    self.phones[self.normalization.get(sound, sound)] += 1
                    length += 1
        self.lengths[str(length)] += 1
        spelling = clean.lower()
        self.trigrams.update(spelling[i:i+3] for i in range(len(spelling)-2)
                             if all('a' <= c <= 'z' for c in spelling[i:i+3]))
        if index < 40:
            self.samples.append(draw)
        for metric, flag in flags.items():
            key = profile + '/' + metric
            if flag and len(self.witnesses.get(key, [])) < 2:
                self.witnesses.setdefault(key, []).append(draw)

    def finish(self, profile):
        assert self.words['profile'] == profile['words'] == 50000
        assert len(self.spellings) == profile['uniqueSpellings']
        assert self.letters / profile['words'] == profile['meanLetters']
        for actual, field in [(self.syllables, 'syllableCounts'), (self.lengths, 'phonemeLengths'), (self.morphology, 'morphologyCounts')]:
            assert dict(actual) == profile[field]
        assert dict(self.phones) == self.distributions[profile['id']]['phonemes']
        assert dict(self.trigrams) == self.distributions[profile['id']]['trigrams']
        expected = [('profile', profile)]
        expected += [(('seed', item['seed']), item) for item in profile['replicates']]
        expected += [(('stratum', item['id']), item) for item in profile['strata']]
        assert {key[1] for key in self.words if isinstance(key, tuple) and key[0] == 'stratum'} == {x['id'] for x in profile['strata']}
        for key, recorded in expected:
            assert self.words[key] == recorded['words']
            for metric, (hits, eligible) in self.groups[key].items():
                assert recorded['metrics'][metric] == {'hits': hits, 'eligible': eligible, 'rate': hits / eligible if eligible else None}
        self.profiles[profile['id']] = {'words': profile['words'], 'metrics': profile['metrics'], 'strata': len(profile['strata'])}

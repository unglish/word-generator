import gzip,json

def load(path):
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == '.gz' else data)

def observations(word):
    syllables = word['syllables']
    trace = word['trace']
    morphology = trace.get('morphology', {})
    count = len(syllables)
    affixed = bool(trace['summary']['morphologyApplied'] and morphology
                   and morphology['template'] != 'bare'
                   and (morphology.get('prefix') or morphology.get('suffix')))
    eligible = {'words': True, 'polysyllables': count > 1, 'disyllables': count == 2,
                'monosyllables': count == 1, 'affixedWords': affixed}
    primaries = [s for s in syllables if s.get('stress') == 'ˈ']
    last = syllables[-1]
    flags = {
        'polysyllable_missing_primary': count > 1 and not primaries,
        'polysyllable_multiple_primary': count > 1 and len(primaries) > 1,
        'primary_schwa': any(p['sound'] == 'ə' for s in primaries for p in s['nucleus']),
        'primary_reduced_vowel': any(p.get('reduced') is True for s in primaries for p in s['nucleus']),
        'morphology_hiatus_bridge': affixed and any(e['event'] in
            ['morphPrefixHiatusFallback', 'morphSuffixHiatusFallback'] for e in trace['structural']),
        'zero_weight_grapheme_choice': any(len(g['weights']) > 1 and
            sum(weight for _, weight in g['weights']) == 0 for g in trace['graphemeSelections']),
        'orthography_trace_missing': 'orthography' not in trace,
        'orthography_surface_mismatch': 'orthography' in trace and
            trace['orthography']['surface'] != word['written']['clean'],
        'adjacent_duplicate_coda': any(a['sound'] == b['sound'] for s in syllables
            for a, b in zip(s['coda'], s['coda'][1:])),
        'disyllable_stress_clash': count == 2 and
            {'ˈ', 'ˌ'}.issubset({s.get('stress') for s in syllables}),
        'monosyllable_schwa': count == 1 and len(last['nucleus']) == 1 and last['nucleus'][0]['sound'] == 'ə',
        'final_open_checked_vowel': not last['coda'] and len(last['nucleus']) == 1 and
            last['nucleus'][0]['sound'] in {'ɪ', 'ɛ', 'æ', 'ʌ', 'ʊ'},
        'monosyllable_foot_vowel': count == 1 and any(p['sound'] == 'ʊ' for p in last['nucleus']),
    }
    return eligible, flags, morphology['template'] if affixed else 'bare'

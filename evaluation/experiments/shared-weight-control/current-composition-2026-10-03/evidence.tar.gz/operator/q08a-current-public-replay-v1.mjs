import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile, writeFile, access } from "node:fs/promises";
import { join } from "node:path";
import { gunzipSync } from "node:zlib";
import { pathToFileURL } from "node:url";
import { setTimeout } from "node:timers/promises";

const root = "/private/tmp/q08a-current-composition-v1";
const hash = bytes => createHash("sha256").update(bytes).digest("hex");
const json = async path => JSON.parse(await readFile(path, "utf8"));
async function exists(path) {
  try { await access(path); return true; } catch { return false; }
}
while (!(await exists(join(root, "capture-complete.json")))) {
  if (await exists(join(root, "capture-command.json"))) {
    assert.equal((await json(join(root, "capture-command.json"))).exitCode, 0);
  }
  await setTimeout(1000);
}
const registration = await json(join(root, "registration.json"));
const { canonical } = await import(pathToFileURL(join(root, "measurement-candidate/evaluation/quality/serialization.ts")));
const { emptyObservation, observe } = await import(pathToFileURL("/private/tmp/q08a-acceptance-revalidation-v1/candidate/evaluation/quality/probes/syllable-weight/shared.ts"));
const serialize = value => JSON.stringify(canonical(value));
async function checkPins() {
  for (const [arm, pins] of Object.entries(registration.sourcePins)) {
    for (const [name, pin] of Object.entries(pins)) {
      const data = await readFile(join(root, arm, name));
      assert.equal(data.length, pin.bytes);
      assert.equal(hash(data), pin.sha256, `${arm}/${name}`);
    }
  }
  assert.equal(hash(await readFile(process.execPath)), registration.node.sha256);
  assert.equal(hash(await readFile("/Users/ryanbetts/Code/unglish/word-generator/node_modules/tsx/dist/loader.mjs")), registration.tsxLoader.sha256);
}
await checkPins();
const apis = {};
for (const arm of ["control", "candidate"]) apis[arm] = await import(pathToFileURL(join(root, arm, "src/index.ts")));
const directories = { control: registration.controlArchive, candidate: join(root, "candidate-run") };
const manifests = {};
for (const arm of Object.keys(directories)) {
  manifests[arm] = (await json(join(directories[arm], "manifest.json"))).manifest;
  assert.equal(manifests[arm].generator.commit, registration.heads[arm]);
  assert.equal(manifests[arm].generator.dirty, false);
  assert.deepEqual(manifests[arm].protocol, registration.protocol);
}
const streams = [];
const startedAt = new Date().toISOString();
for (const profile of registration.protocol.profiles) {
  for (const seed of profile.seeds.development) {
    const words = {};
    const stream = { profile: profile.id, seed, words: 10000, arms: {} };
    for (const arm of ["control", "candidate"]) {
      const file = `words/${profile.id}-${seed}.jsonl.gz`;
      const pin = manifests[arm].artifacts.find(item => item.file === file);
      const compressed = await readFile(join(directories[arm], file));
      assert.equal(compressed.length, pin.bytes);
      assert.equal(hash(compressed), pin.sha256);
      const rows = gunzipSync(compressed).toString("utf8").trimEnd().split("\n");
      assert.equal(rows.length, 10000);
      const rng = apis[arm].createSeededRng(seed);
      let calls = 0;
      const rand = () => { calls++; return rng(); };
      const boundaries = createHash("sha256");
      const complete = createHash("sha256");
      const legacy = createHash("sha256");
      const observed = emptyObservation();
      words[arm] = [];
      for (let index = 0; index < rows.length; index++) {
        const draw = JSON.parse(rows[index]);
        assert.deepEqual([draw.profile, draw.seed, draw.drawIndex], [profile.id, seed, index]);
        const generated = apis[arm].generateWord({ ...profile.options, rand, trace: true });
        const encoded = serialize(generated);
        assert.equal(encoded, serialize(draw.word), `${arm}/${profile.id}/${seed}/${index}`);
        complete.update(encoded + "\n");
        boundaries.update(`${index}:${calls}\n`);
        observe(generated, index, arm === "candidate" ? "candidate" : "original", observed);
        const withoutWeight = { ...generated, trace: { ...generated.trace } };
        delete withoutWeight.trace.stressWeight;
        legacy.update(serialize(withoutWeight) + "\n");
        if (index < 1000) {
          const withoutTrace = { ...generated };
          delete withoutTrace.trace;
          words[arm].push(serialize(withoutTrace));
        }
      }
      const offRng = apis[arm].createSeededRng(seed);
      let offCalls = 0;
      const offRand = () => { offCalls++; return offRng(); };
      const offBoundaries = createHash("sha256");
      for (let index = 0; index < 1000; index++) {
        const generated = apis[arm].generateWord({ ...profile.options, rand: offRand, trace: false });
        assert.equal(serialize(generated), words[arm][index], `trace-off/${arm}/${profile.id}/${seed}/${index}`);
        offBoundaries.update(`${index}:${offCalls}\n`);
      }
      stream.arms[arm] = { rngCalls: calls, nextRng: rng(), rngBoundarySha256: boundaries.digest("hex"),
        traceOffPrefixWords: 1000, traceOffPrefixRngCalls: offCalls, traceOffPrefixNextRng: offRng(),
        traceOffPrefixBoundarySha256: offBoundaries.digest("hex"), completeWordTraceSha256: complete.digest("hex"),
        legacyWordTraceSha256: legacy.digest("hex"), observations: observed };
    }
    assert.deepEqual(words.control, words.candidate);
    for (const key of ["rngCalls", "nextRng", "rngBoundarySha256", "traceOffPrefixRngCalls", "traceOffPrefixNextRng", "traceOffPrefixBoundarySha256", "legacyWordTraceSha256"]) {
      assert.equal(stream.arms.control[key], stream.arms.candidate[key], `${profile.id}/${seed}/${key}`);
    }
    streams.push(stream);
    console.log(`${profile.id}/${seed}: all20000full public words/traces and legacy payloads/RNG boundaries match;both1000trace-off prefixes match`);
  }
}
await checkPins();
await writeFile(join(root, "public-replay.json"), JSON.stringify({ startedAt, completedAt: new Date().toISOString(),
  heads: registration.heads, publicTracedWords: 400000, publicTraceOffWords: 40000,
  allCompleteArchiveWordsTracesMatch: true, allLegacyPayloadsAndPerDrawRngBoundariesMatch: true,
  streams, scope: "Full two-current-head public replay,legacy parity with only stressWeight excluded,all per-draw RNG boundaries/full next values and original1000trace-off prefixes. All source and actual Node/loader pins unchanged. Full archival capture does not record its own RNG calls. Independent core/weight recount,gates,timing,retention/publication remain separate; no human/default Englishquantity gain or seed independence." }, null, 2) + "\n", { flag: "wx" });

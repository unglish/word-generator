"""Measure rebased Q08a at exact current heads without altering older studies."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import shutil
import subprocess

ROOT = Path.cwd()
PUBLISHED = Path('/private/tmp/q08a-acceptance-revalidation-v1')
OUT = Path('/private/tmp/q08a-current-composition-v1')
NODE = '/Users/ryanbetts/.nvm/versions/node/v24.11.1/bin/node'
LOADER = '/Users/ryanbetts/Code/unglish/word-generator/node_modules/tsx/dist/loader.mjs'
CONTROL_RUN = Path('/private/tmp/q07-current-composition-v1/control-run')
HEADS = {'control': '233b455732920ac529b2dda2a623df0a6ca17446',
         'candidate': 'c15565aca3e613a5f321e3128e22098cf6c9aff5'}


def load(path):
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == '.gz' else data)


def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write(path, data):
    with path.open('x') as stream:
        stream.write(json.dumps(data, indent=2) + '\n')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


assert not OUT.exists()
OUT.mkdir()
assert shutil.disk_usage(OUT).free >= 400_000_000 + 2 * 1024 ** 3
source_pins = {}
for arm, head in HEADS.items():
    source = OUT / arm
    subprocess.run(['git', 'clone', '--shared', str(PUBLISHED), str(source)], check=True, capture_output=True)
    subprocess.run(['git', 'checkout', '--detach', head], cwd=source, check=True, capture_output=True)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == head
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source)
    names = subprocess.check_output(['git', 'ls-files', 'src', 'data/cmu', 'package.json', 'package-lock.json'], cwd=source, text=True).splitlines()
    source_pins[arm] = {name: pin(source / name) for name in names}
    dependencies = source / 'node_modules'
    dependencies.mkdir()
    for file in Path('/Users/ryanbetts/Code/unglish/word-generator/node_modules').iterdir():
        if file.name not in {'.vite', '.vite-temp', '.cache'}:
            (dependencies / file.name).symlink_to(file, target_is_directory=file.is_dir())
control_manifest = load(CONTROL_RUN / 'manifest.json')['manifest']
assert control_manifest['generator']['commit'] == HEADS['control'] and not control_manifest['generator']['dirty']
for artifact in control_manifest['artifacts']:
    assert pin(CONTROL_RUN / artifact['file']) == {key: artifact[key] for key in ['bytes', 'sha256']}
measure = OUT / 'measurement-candidate'
subprocess.run(['git', 'clone', '--shared', str(OUT / 'candidate'), str(measure)], check=True, capture_output=True)
subprocess.run(['git', 'checkout', '--detach', HEADS['candidate']], cwd=measure, check=True, capture_output=True)
sources = load(CONTROL_RUN / 'sources.json.gz')
for group in ['evaluator', 'references', 'packageFiles']:
    for record in sources[group]:
        file = measure / record['path']
        file.parent.mkdir(parents=True, exist_ok=True)
        data = record['content'].encode()
        if group == 'evaluator':
            file.write_bytes(data)
        else:
            assert file.read_bytes() == data
(measure / 'node_modules').mkdir()
for file in (OUT / 'candidate/node_modules').iterdir():
    (measure / 'node_modules' / file.name).symlink_to(file.resolve(), target_is_directory=file.is_dir())
write(OUT / 'registered-protocol.json', control_manifest['protocol'])
write(OUT / 'registration.json', {
    'registeredAt': now(), 'heads': HEADS, 'sourcePins': source_pins,
    'protocol': control_manifest['protocol'], 'wordsPerArm': 200000,
    'cohort': 'development', 'controlArchive': str(CONTROL_RUN),
    'controlManifestPin': pin(CONTROL_RUN / 'manifest.json'),
    'evaluatorDigest': control_manifest['evaluatorDigest'], 'referenceDigest': control_manifest['referenceDigest'],
    'node': pin(Path(NODE)), 'tsxLoader': pin(Path(LOADER)),
    'requirements': ['Full200000current candidate capture with exact original development schedule/frozen evaluator and fully authenticated existing200000current control.',
                     'All400000untouched public API complete-word/trace replays;full200000current legacy payload pairs with only trace.stressWeight excluded.',
                     'Record current per-draw RNG boundaries/next values for all20streams,require current both-arm exact equality;trace-off1000prefix perstream preserves original Q08a parity scope.',
                     'Independent Python recount every400000record/coremetric/distribution/actualstratum/sample/witness and root quantity/stress observation.',
                     'Preserve full original gates/thresholds and current gate observations separately;native timings/full retention/public evidence remain separate before claiming completion.'],
    'scope': 'Additional prospectively registered cumulative comparison; no alteration/relabeling of complete original Q08a evidence. Default quantity remains unspecified. No human gain,seed independence or current complete acceptance verdict.'})
args = [NODE, '--import', LOADER, 'evaluation/quality/cli.ts', 'capture', '--id', 'q08a-current-candidate-v1',
        '--cohort', 'development', '--protocol', str(OUT / 'registered-protocol.json'), '--out', str(OUT / 'candidate-run')]
with (OUT / 'capture.log').open('x') as log:
    result = subprocess.run(args, cwd=measure, stdout=log, stderr=subprocess.STDOUT)
write(OUT / 'capture-command.json', {'args': args, 'cwd': str(measure), 'exitCode': result.returncode})
assert result.returncode == 0
for arm, pins in source_pins.items():
    assert {name: pin(OUT / arm / name) for name in pins} == pins
    if arm == 'candidate':
        assert {name: pin(measure / name) for name in pins} == pins
write(OUT / 'capture-complete.json', {'completedAt': now(), 'executionPassed': True, 'words': 200000,
    'heads': HEADS, 'sourcePinsUnchanged': True, 'scope': 'Full current candidate capture only;full public replay/independent recount/gates/retention/publication remain pending.'})
print(json.dumps({'words': 200000, 'heads': HEADS, 'captureComplete': True}))

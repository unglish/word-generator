"""Retain both full current archives, source, operators and recorded outcomes."""
from pathlib import Path
import ctypes
import datetime
import hashlib
import json
import os
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent.parent
RUN = Path("/private/tmp/q08a-current-composition-v1")
OLD = Path("/private/tmp/q08a-acceptance-revalidation-v1/candidate")
OUT = ROOT / ".local-evidence/q08a-current-composition-retained-v1"


def load(path):
    return json.loads(path.read_text())


def pin(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def write_json(path, value):
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")


inputs = {}


def add(name, source):
    assert name not in inputs, name
    assert source.is_file(), source
    inputs[name] = source


def tree(label, directory):
    for path in sorted(directory.rglob("*")):
        if path.is_file():
            add(label + "/" + path.relative_to(directory).as_posix(), path)


registration = load(RUN / "registration.json")
replay = load(RUN / "public-replay.json")
independent = load(RUN / "independent-recount.json")
prefix = load(RUN / "trace-prefix-rng.json")
gates = load(RUN / "gates-complete.json")
timing = load(RUN / "native-timing-complete.json")
assert replay["publicTracedWords"] == independent["rawRecordsRecounted"] == 400000
assert replay["heads"] == independent["heads"] == prefix["heads"] == registration["heads"]
assert replay["allCompleteArchiveWordsTracesMatch"] and replay["allLegacyPayloadsAndPerDrawRngBoundariesMatch"]
assert independent["allCoreSummaryFieldsEqualExceptRunId"] and independent["completeDistributionsEqual"]
assert prefix["everyTraceOnOffPrefixRngBoundaryAndNextValueMatches"]
assert gates["commands"] == 15 and gates["passingCommands"] == 13 and gates["failingCommands"] == 2
assert timing["runs"] == timing["passingRuns"] == 12 and timing["pairs"] == 6
assert load(RUN / "lint-equivalence.json")["exactLogsEqualAfterCheckoutPathNormalization"]
assert load(RUN / "comparison-command.json")["exitCode"] == 0
tree("control-run", Path(registration["controlArchive"]))
tree("candidate-run", RUN / "candidate-run")
tree("candidate-vs-control", RUN / "candidate-vs-control")
for path in sorted(RUN.iterdir()):
    if path.is_file():
        add("execution/" + path.name, path)
for name in ["q08a-current-public-replay-v1.log", "q08a-current-trace-prefix-rng-v1.log", "q08a-current-independent-recount-v1.log", "q08a-current-gates-v1.log", "q08a-current-native-timing-v1.log"]:
    add("execution/" + name, Path("/private/tmp") / name)
for arm, pins in registration["sourcePins"].items():
    source = RUN / arm
    assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=source, text=True).strip() == registration["heads"][arm]
    for name, expected in pins.items():
        assert pin(source / name) == expected, (arm, name)
        add("source/" + arm + "/" + name, source / name)
    for name in ["tsconfig.json", "vitest.config.ts", "vitest.quality.config.ts", "vitest.perf.config.ts"]:
        assert (source / name).read_bytes() == subprocess.check_output(["git", "show", "HEAD:" + name], cwd=source)
        add("source/" + arm + "/" + name, source / name)
    for record in load(RUN / "gate-policy-before-v2.json")["gatePins"][arm]:
        path = RUN / ("historical-gates-v2-" + arm) / record["file"]
        assert pin(path) == {key: record[key] for key in ["bytes", "sha256"]}
        assert path.read_bytes() == (OLD / record["file"]).read_bytes()
        add("historical-gates/" + arm + "/" + record["file"], path)
for path in sorted((RUN / "measurement-candidate/evaluation/quality").iterdir()):
    if path.is_file():
        add("frozen-evaluator/" + path.name, path)
tree("frozen-observer", OLD / "evaluation/quality/probes/syllable-weight")
for name in ["q08a-current-composition-capture-v1.py", "q08a-current-public-replay-v1.mjs", "q08a-current-trace-prefix-rng-v1.mjs", "q08a-current-independent-recount-v1.py", "q08a_current_independent_helpers.py", "q08a_independent_core.py", "q08a-current-gates-v1.py", "q08a-current-native-timing-v1.py", "q08a-current-retain-v1.py"]:
    add("operator/" + name, ROOT / ".local-evidence" / name)
# The prior runtime index is an authenticated enumeration of the actual Node/TSX closure.
# Read current physical files and require their complete bytes/hashes to match it.
runtime_index = load(ROOT / ".local-evidence/q07-current-composition-retained-v1/index.json")
runtime_files = [record for record in runtime_index["files"] if record["file"].startswith("runtime/")]
assert len(runtime_files) == 75
for record in runtime_files:
    path = Path(record["source"])
    assert pin(path) == {key: record[key] for key in ["bytes", "sha256"]}, path
    add(record["file"], path)
assert pin(inputs["runtime/node"]) == registration["node"]
assert pin(Path("/Users/ryanbetts/Code/unglish/word-generator/node_modules/tsx/dist/loader.mjs")) == registration["tsxLoader"]
logical_bytes = sum(path.stat().st_size for path in inputs.values())
free_bytes = shutil.disk_usage(OUT.parent).free
assert free_bytes >= logical_bytes + 2 * 1024 ** 3, (free_bytes, logical_bytes)
assert not OUT.exists()
OUT.mkdir()
libc = ctypes.CDLL(None, use_errno=True)
libc.clonefile.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int]
libc.clonefile.restype = ctypes.c_int
records = []
for name, source in sorted(inputs.items()):
    expected = pin(source)
    target = OUT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    if libc.clonefile(os.fsencode(source.resolve()), os.fsencode(target), 0):
        raise OSError(ctypes.get_errno(), "Evidence clone failed", str(source))
    assert target.stat().st_ino != source.stat().st_ino
    assert target.read_bytes() == source.read_bytes() and pin(target) == expected
    records.append({"file": name, "source": str(source), **expected, "independentInode": True})
for record in records:
    assert pin(OUT / record["file"]) == {key: record[key] for key in ["bytes", "sha256"]}
index = {"schemaVersion": 1, "observedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
         "heads": registration["heads"], "files": records,
         "storageGuard": {"freeBytesBefore": free_bytes, "logicalCopyBytes": logical_bytes, "reserveBytes": 2 * 1024 ** 3},
         "scope": "Full both-arm 400000-word current raw archive; complete measured src/CMU/package/config pins, frozen evaluator and original observer, original gates, operators, replay/recount and timing outcomes; selected actual Node/TSX closure. Every independently owned COW inode has full-byte/hash verification. Shared extents are not an independent-device backup. Full Node/Python/Vitest/ESLint/TypeScript installations and Git history remain external. No human or linguistic/performance gain verdict."}
write_json(OUT / "index.json", index)
totals = {key: sum(stream["candidate"][key] for stream in independent["streams"])
          for key in ["words", "unavailable", "observedSyllables", "secondaryCandidates", "secondaryApplied", "finalStressCheckedWords", "finalStressUnavailableWords"]}
report = {"observedAt": index["observedAt"], "heads": registration["heads"], "registeredWordsPerArm": 200000,
          "publicTracedWords": 400000, "legacyPayloadPairs": 200000, "independentRawRecords": 400000,
          "traceOffPrefixWords": 40000, "supplementalTraceOnPrefixWords": 40000,
          "allCurrentCoreSummaryAndDistributionsEqual": True, "quantityAndStress": totals,
          "unspecifiedNuclearSegments": independent["nuclearSegments"], "gateCommands": 15,
          "passingGateCommands": 13, "failingGateCommands": 2, "sameInheritedLintErrors": 10,
          "nativeTiming": timing, "retained": {"directory": str(OUT.relative_to(ROOT)), "files": len(records),
          "bytes": logical_bytes, "indexSha256": pin(OUT / "index.json")["sha256"]},
          "scope": "Complete exact-current-head scientific compatibility, original/current gate observations, original timings and full evidence retention. Only additive trace.stressWeight removed for legacy parity; all core counts/distributions unchanged. Root quantity remains unknown; bare final stress can be corroborated, affixed earlier-root stress correspondence remains unavailable. No publication yet, human quality/English quantity gain, seed independence or stable performance improvement."}
write_json(ROOT / ".local-evidence/q08a-current-composition-acceptance-v1.json", report)
print(json.dumps(report), flush=True)

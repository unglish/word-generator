import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile, writeFile, access } from "node:fs/promises";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import { setTimeout } from "node:timers/promises";

const root = "/private/tmp/q08a-current-composition-v1";
const sha = bytes => createHash("sha256").update(bytes).digest("hex");
while (true) {
  try { await access(join(root, "public-replay.json")); break; } catch { await setTimeout(1000); }
}
const registration = JSON.parse(await readFile(join(root, "registration.json"), "utf8"));
const replay = JSON.parse(await readFile(join(root, "public-replay.json"), "utf8"));
async function pinsUnchanged() {
  for (const [arm, pins] of Object.entries(registration.sourcePins)) {
    for (const [name, pin] of Object.entries(pins)) {
      const data = await readFile(join(root, arm, name));
      assert.equal(data.length, pin.bytes);
      assert.equal(sha(data), pin.sha256);
    }
  }
  assert.equal(sha(await readFile(process.execPath)), registration.node.sha256);
}
await pinsUnchanged();
const records = [];
for (const arm of ["control", "candidate"]) {
  const api = await import(pathToFileURL(join(root, arm, "src/index.ts")));
  for (const stream of replay.streams) {
    const profile = registration.protocol.profiles.find(item => item.id === stream.profile);
    const rng = api.createSeededRng(stream.seed);
    let calls = 0;
    const rand = () => { calls++; return rng(); };
    const boundaries = createHash("sha256");
    for (let index = 0; index < 1000; index++) {
      api.generateWord({ ...profile.options, rand, trace: true });
      boundaries.update(`${index}:${calls}\n`);
    }
    const observed = { arm, profile: stream.profile, seed: stream.seed, words: 1000,
      rngCalls: calls, nextRng: rng(), boundarySha256: boundaries.digest("hex") };
    const off = stream.arms[arm];
    assert.equal(observed.rngCalls, off.traceOffPrefixRngCalls);
    assert.equal(observed.nextRng, off.traceOffPrefixNextRng);
    assert.equal(observed.boundarySha256, off.traceOffPrefixBoundarySha256);
    records.push(observed);
  }
}
await pinsUnchanged();
await writeFile(join(root, "trace-prefix-rng.json"), JSON.stringify({ heads: registration.heads,
  tracedPrefixWords: 40000, everyTraceOnOffPrefixRngBoundaryAndNextValueMatches: true,
  publicReplaySha256: sha(await readFile(join(root, "public-replay.json"))), records,
  scope: "Additional current trace-on/off RNG check at the original1000draw-per-stream parity scope;full400000public words/legacy/pair-RNG replay remains in its separate report. Closes the prefix callback comparison not recorded during that continuous10000draw loop. Source/Node unchanged. No additional scientific sample,quality gain or seed independence." }, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify({ records: records.length, tracedPrefixWords: 40000, everyTraceOnOffRngBoundaryAndNextValueMatches: true }));

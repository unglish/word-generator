"""Recount every current record and observed quantity field independently."""
from pathlib import Path
import copy
import datetime
import gzip
import hashlib
import json
import time

from q08a_current_independent_helpers import CoreCounts, empty, weight_observation
from q08a_independent_core import load

RUN = Path('/private/tmp/q08a-current-composition-v1')
while not (RUN / 'public-replay.json').exists():
    time.sleep(1)
registration = load(RUN / 'registration.json')
replay = load(RUN / 'public-replay.json')
assert replay['allCompleteArchiveWordsTracesMatch'] and replay['publicTracedWords'] == 400000
assert replay['heads'] == registration['heads']
directories = [Path(registration['controlArchive']), RUN / 'candidate-run']
manifests = [load(directory / 'manifest.json')['manifest'] for directory in directories]
cores = []
for directory in directories:
    sources = load(directory / 'sources.json.gz')
    normalization = json.loads(next(f['content'] for f in sources['references'] if f['path'].endswith('/phoneme-normalization.json')))['generatedAliases']
    cores.append(CoreCounts(load(directory / 'summary.json'), load(directory / 'distributions.json.gz'), normalization))
streams = []
for profile_index, profile in enumerate(registration['protocol']['profiles']):
    for core in cores:
        core.start()
    for seed in profile['seeds']['development']:
        filename = f"words/{profile['id']}-{seed}.jsonl.gz"
        lines = []
        for directory, manifest in zip(directories, manifests):
            raw = (directory / filename).read_bytes()
            pin = next(record for record in manifest['artifacts'] if record['file'] == filename)
            assert len(raw) == pin['bytes'] and hashlib.sha256(raw).hexdigest() == pin['sha256']
            lines.append(gzip.decompress(raw).splitlines())
        assert len(lines[0]) == len(lines[1]) == 10000
        results = [empty(), empty()]
        segments = 0
        for index, pair in enumerate(zip(*lines)):
            draws = [json.loads(line) for line in pair]
            for draw in draws:
                assert (draw['profile'], draw['seed'], draw['drawIndex']) == (profile['id'], seed, index)
            legacy = copy.deepcopy(draws[1]['word'])
            del legacy['trace']['stressWeight']
            assert legacy == draws[0]['word'], (profile['id'], seed, index)
            for arm, (draw, core, result) in enumerate(zip(draws, cores, results)):
                core.add(draw)
                segments += weight_observation(draw['word'], index, arm == 1, result)
        native = next(record for record in replay['streams'] if record['profile'] == profile['id'] and record['seed'] == seed)
        assert results[0] == native['arms']['control']['observations']
        assert results[1] == native['arms']['candidate']['observations']
        streams.append({'profile': profile['id'], 'seed': seed, 'words': 10000,
                        'control': results[0], 'candidate': results[1], 'nuclearSegments': segments})
        print(f"{profile['id']}/{seed}:20000complete current records/legacy parity/core/quantity/witnesses independently checked", flush=True)
    for core in cores:
        core.finish(core.summary['profiles'][profile_index])
for directory, core in zip(directories, cores):
    assert core.samples == load(directory / 'review-samples.json.gz')
    assert core.witnesses == load(directory / 'witnesses.json.gz')
summary_control = dict(cores[0].summary)
summary_candidate = dict(cores[1].summary)
summary_control.pop('id'); summary_candidate.pop('id')
assert summary_control == summary_candidate
assert cores[0].distributions == cores[1].distributions
for arm, pins in registration['sourcePins'].items():
    for name, expected in pins.items():
        raw = (RUN / arm / name).read_bytes()
        assert {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()} == expected
report = {'observedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'heads': registration['heads'],
          'rawRecordsRecounted': 400000, 'completeLegacyPayloadPairs': 200000,
          'allCoreSummaryFieldsEqualExceptRunId': True, 'completeDistributionsEqual': True,
          'allCoreCountsAndFullSamplesWitnessesMatch': True, 'allWeightObservationAndFullWitnessesMatch': True,
          'nuclearSegments': sum(record['nuclearSegments'] for record in streams),
          'streams': streams, 'profiles': [core.profiles for core in cores],
          'scope': 'Independent full current two-head400000record recount: all13metrics/profile/seed/actualstrata,complete phone/trigram counts,histograms,samples/first-two diagnostic traces and root weight/primary/secondary/bare-final observations/full witnesses. Only additive trace.stressWeight removed for legacy parity. Affixed earlier-root stress remains unavailable. No human/Englishquantity gain,seed independence,gates/timing/fullretention/publication verdict.'}
with (RUN / 'independent-recount.json').open('x') as file:
    file.write(json.dumps(report, indent=2) + '\n')
print(json.dumps({'rawRecords': 400000, 'completeCoreSummaryAndDistributionsEqual': True, 'nuclearSegments': report['nuclearSegments']}))

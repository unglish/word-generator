"""Keep fixture authentication bytes local; retain the complete V3 evidence."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/q21-publication-stage-v3')
OUT = Path('/private/tmp/q21-publication-stage-v4')


def pin(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


if __name__ == '__main__':
    shutil.copytree(SOURCE, OUT)
    index = json.loads((OUT / 'validation-index.json').read_bytes())
    excluded, tokens, records = [], set(), []
    for record in index['records']:
        if record['origin'].endswith('/credentials.json'):
            path = OUT / record['path']
            raw = path.read_bytes()
            assert pin(raw) == record['saved'] == record['original']
            credentials = json.loads(raw)
            tokens.add(credentials['owner_token'])
            tokens.update(participant['token'] for participant in credentials['participants'])
            excluded.append(record)
            path.unlink()  # Only the new compact copy; original and CAS remain.
        else:
            if record['path'] == 'verify.py':
                target = 'evidence/publication-v3/verify.py.gz'
                raw = (OUT / 'verify.py').read_bytes()
                encoded = gzip.compress(raw, mtime=0)
                (OUT / target).parent.mkdir(parents=True, exist_ok=True)
                (OUT / target).write_bytes(encoded)
                record = {**record, 'path': target, 'compression': 'gzip', 'saved': pin(encoded)}
            records.append(record)
    assert len(excluded) == 4 and len(tokens) == 27
    for name in ('verify.py', 'corruptions.py', 'repack.py', 'run_publication.py'):
        raw = (HERE / name).read_bytes()
        compressed = name != 'verify.py'
        saved = name + ('.gz' if compressed else '')
        encoded = gzip.compress(raw, mtime=0) if compressed else raw
        path = OUT / saved
        if path.exists() and name != 'verify.py':
            historical = OUT / 'evidence/publication-v3' / saved
            path.rename(historical)
            for record in records:
                if record['path'] == saved:
                    record['path'] = historical.relative_to(OUT).as_posix()
        path.write_bytes(encoded)
        records.append({'path': saved, 'origin': str(HERE / name), 'compression': 'gzip' if compressed else 'none',
                        'saved': pin(encoded), 'original': pin(raw)})
    results = OUT / 'RESULTS.md'
    text = results.read_text()
    text += '\n\nThe four original local collection credential files remain in the complete verified local archive. Public evidence retains their original hashes and scans every decoded artifact against hashes of all 27 fixture authentication values. No authentication value is published. The complete V3 packet remains local; the V4 packet changes evidence exposure only, with no scientific or gate rerun.\n'
    results.write_text(text)
    index.update(version='q21-completed-evidence-v4', records=records, results=pin(results.read_bytes()),
                 privateAuthentication={'excludedRecords': excluded, 'tokenHashes': sorted(hashlib.sha256(token.encode()).hexdigest() for token in tokens)},
                 originalPacketIndex=pin((SOURCE / 'validation-index.json').read_bytes()))
    (OUT / 'validation-index.json').write_text(json.dumps(index, indent=2) + '\n')
    print(json.dumps({'passed': True, 'artifacts': len(records), 'privateCredentialFiles': len(excluded), 'authenticationValues': len(tokens)}))

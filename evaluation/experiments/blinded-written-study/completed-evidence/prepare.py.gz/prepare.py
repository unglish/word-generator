"""Package complete written-study evidence after original checks, without reruns."""
import ctypes
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import traceback

BASE = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/ryanbetts/.codex/worktrees/linguistic-q21-written-study/word-generator')
ARCHIVE = BASE / 'full-calibration-retained-local-v1'
LOCAL = BASE / 'original-gates-retained-local-v3'
STAGE = Path('/private/tmp/q21-publication-stage-v3')
GATES = Path('/private/tmp/q21-original-gates-v3')
GATE_DRIVER = Path('/private/tmp/q21-original-gates-driver-v3')
MEASURED = '5796cb441e9eb806266406becfcea2f822103e95'


def pin_bytes(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def pin(path):
    digest, size = hashlib.sha256(), 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
            size += len(block)
    return {'bytes': size, 'sha256': digest.hexdigest()}


def load(path):
    return json.loads(path.read_bytes())


def source_identity(initial):
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == MEASURED
    assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=ROOT, text=True).strip()
    for name, identity in initial['sources']['candidate']['tracked'].items():
        assert pin(ROOT / name) == identity, name


if __name__ == '__main__':
    STAGE.mkdir(mode=0o700)
    try:
        assert load(GATE_DRIVER / 'complete.json')['passed']
        assert not load(GATE_DRIVER / 'science-resumed.json')['errors']
        gate_verification = load(GATES / 'independent-verification.json')
        assert gate_verification['passed'] and gate_verification['commands'] == 28
        initial = load(GATES / 'initial.json')['initial']
        assert initial['sources']['candidate']['commit'] == MEASURED
        source_identity(initial)
        original = load(ARCHIVE / 'index.json')
        assert original['passed'] and original['datasets'] == 14400 and original['independentContrasts'] == 43156800
        assert pin(ARCHIVE / 'index.json') == load(Path('/private/tmp/q21-full-retention-driver-v1/complete.json'))['index']
        raw_records = [record for record in original['records'] if record['original'].startswith('/private/tmp/q21-calibration-v1/')
                       and record['original'].endswith(('-input.json.gz', '-inference.json.gz'))]
        assert len(raw_records) == 28800
        raw_origins = {record['original'] for record in raw_records}
        records = []

        def add(source, relative, origin=None):
            raw = source.read_bytes()
            suffix = Path(origin or source).suffix
            compressed = relative != 'verify.py' and suffix != '.gz' and (len(raw) > 65536 or suffix in ('.log', '.py', '.ts', '.mjs', '.patch'))
            encoded = gzip.compress(raw, mtime=0) if compressed else raw
            saved = relative + ('.gz' if compressed else '')
            target = STAGE / saved
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(encoded)
            records.append({'path': saved, 'origin': origin or str(source), 'compression': 'gzip' if compressed else 'none',
                            'saved': pin_bytes(encoded), 'original': pin_bytes(raw)})

        # Reverify every retained original; full raw/numerical/runtime objects
        # remain local. Compact Git evidence keeps every journal/report/operator.
        for ordinal, record in enumerate(original['records']):
            expected = {key: record[key] for key in ('bytes', 'sha256')}
            retained, source = ARCHIVE / record['retained'], Path(record['original'])
            assert pin(retained) == pin(source) == expected
            if record['original'] in raw_origins or record['logical'].startswith(('numpy/', 'loader/', 'runtime/')):
                continue
            add(retained, 'evidence/retained/' + record['logical'], origin=record['original'])
            if (ordinal + 1) % 1000 == 0:
                print(str(ordinal + 1) + '/' + str(len(original['records'])) + ' original evidence entries checked', flush=True)
        add(ARCHIVE / 'index.json', 'complete-retained-local-index.json')

        roots = [GATES, GATE_DRIVER]
        roots += [Path('/private/tmp') / name for name in ('q21-original-gates-driver-v1', 'q21-original-gates-v1',
                   'q21-original-gates-driver-v2', 'q21-process-hold-check-v3', 'q21-storage-sharing-v1')]
        for directory in roots:
            assert directory.is_dir(), str(directory)
            for source in sorted(directory.rglob('*')):
                if source.is_file():
                    add(source, 'evidence/execution/' + directory.name + '/' + source.relative_to(directory).as_posix())
        local_roots = [BASE / name for name in ('publication-preparation-failure-v1', 'publication-preparation-v2',
                       'publication-preparation-tools-v2', 'full-retention-tools-v1')]
        local_roots += [BASE.parent / name for name in ('study-publication-gates-v1', 'study-publication-gates-v2',
                        'study-publication-gates-v3', 'study-gate-recorder-check-failure-v1')]
        for directory in local_roots:
            for source in sorted(directory.rglob('*')):
                if source.is_file() and '__pycache__' not in source.parts:
                    add(source, 'evidence/operators/' + directory.name + '/' + source.relative_to(directory).as_posix())
        for source in (BASE / 'reclaim-duplicate-storage-v1.py', Path('/private/tmp/q21-dependency-recorder-checks-v2.log'),
                       Path('/private/tmp/q21-dependency-recorder-checks-v3.log'), Path('/private/tmp/q21-complete-installed-graph-v2.json'),
                       Path('/private/tmp/q21-complete-installed-graph-v2.log')):
            add(source, 'evidence/supplemental/' + source.name)

        LOCAL.mkdir(mode=0o700)
        objects = LOCAL / 'objects'
        objects.mkdir(mode=0o700)
        libc = ctypes.CDLL(None, use_errno=True)
        clone = libc.clonefile
        clone.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int]
        clone.restype = ctypes.c_int
        support = []

        def retain(logical, source, expected):
            assert pin(source) == expected
            target = objects / expected['sha256']
            if not target.exists():
                result = clone(os.fsencode(source.resolve()), os.fsencode(target), 0)
                if result:
                    raise OSError(ctypes.get_errno(), 'Complete gate provenance clone failed', str(source))
                assert not target.is_symlink() and target.stat().st_ino != source.stat().st_ino
                target.chmod(0o600)
            assert pin(target) == pin(source) == expected
            support.append({'logical': logical, 'original': str(source), 'retained': str(target), **expected})

        registration_path = BASE.parent / 'study-publication-gates-v3/q21-registration-v3.json'
        registration = load(registration_path)
        for arm, source in initial['sources'].items():
            for name, identity in source['tracked'].items():
                retain('source/' + arm + '/' + name, Path(registration['roots'][arm]) / name, identity)
            for package in source['dependencies']['packages'].values():
                for name, identity in package['files'].items():
                    retain('dependencies/' + arm + '/' + package['name'] + '/' + package['version'] + '/' + name,
                           Path(identity['path']), {key: identity[key] for key in ('bytes', 'sha256')})
        retain('runtime/node', Path(initial['node']['path']), {key: initial['node'][key] for key in ('bytes', 'sha256')})
        retain('runtime/npm', Path('/Users/ryanbetts/.nvm/versions/node/v24.11.1/bin/npm'), initial['npm'])
        support_index = {'passed': True, 'sourceCommit': MEASURED, 'records': support,
                         'scope': 'All original gate source, installed dependency and Node/npm bytes retained in independent-inode filesystem clones; every original and retained hash checked.'}
        (LOCAL / 'index.json').write_text(json.dumps(support_index, indent=2) + '\n')
        add(LOCAL / 'index.json', 'original-gates-retained-local-index.json')

        summary = load(Path('/private/tmp/q21-calibration-summary-v1/summary.json'))
        assert summary['datasets'] == 14400 and summary['replicates'] == 14400 * 999 and summary['contexts'] == 43156800
        preparation = (BASE / 'publication-preparation-v2/README.md').read_text()
        old = preparation.index('The exact original checks are queued:')
        end = preparation.index('\n\nNo actual readers', old)
        update = ('All 28 original baseline/candidate checks completed, including six adjacent pairs of unchanged native performance runs. '
                  + str(gate_verification['passingCommands']) + ' commands passed and ' + str(gate_verification['failedCommands'])
                  + ' failed. Every failure, compiler/report/source identity and original rounded timing result is retained in the package. '
                  'The entire 30,263-file original evidence archive and all additional original gate source/runtime dependencies are verified and retained. '
                  'Original sizes, seeds, thresholds, timeouts and heap settings remain unchanged. Full failures are reviewed separately from successful execution; calibration does not replace repository checks.')
        preparation = preparation[:old] + update + preparation[end:]
        preparation += '\n\n## Rechecking the complete package\n\nRun `python3 verify.py --root .` from this directory. `--full-local` additionally rehashes all original and retained raw/runtime/source objects on the evidence owner\'s machine. Each logical file and original path is preserved in the local indexes. Filesystem clones share extents and have independent inodes; this is local evidence retention, not an independent-device backup.\n'
        (STAGE / 'RESULTS.md').write_text(preparation)
        for name in ('verify.py', 'prepare.py', 'run_publication.py', 'corruptions.py'):
            add(BASE / 'publication-tools-v3' / name, name)
        source_identity(initial)
        assert len({record['path'] for record in records}) == len(records)
        index = {'version': 'q21-completed-evidence-v3', 'sourceCommit': MEASURED,
                 'controlCommit': '58baeaa388ee2d83e670764a94f649506b098464', 'records': records,
                 'sourcePins': initial['sources']['candidate']['tracked'], 'results': pin(STAGE / 'RESULTS.md'),
                 'datasets': 14400, 'bootstrapReplicatesPerDataset': 999, 'contrasts': 43156800,
                 'originalGateOutcomes': {'commands': 28, 'passing': gate_verification['passingCommands'], 'failed': gate_verification['failedCommands']},
                 'scope': 'Complete written comparison infrastructure, synthetic calibration and original repository outcomes. No actual readers, universal interval coverage, informative-loss correction or generated-quality improvement.'}
        (STAGE / 'validation-index.json').write_text(json.dumps(index, indent=2) + '\n')
        print(json.dumps({'passed': True, 'artifacts': len(records), 'retainedOriginalFiles': len(original['records']),
                          'additionalGateProvenanceFiles': len(support), 'compactBytes': sum(row['saved']['bytes'] for row in records)}))
    except Exception as error:
        (STAGE / 'failure.json').write_text(json.dumps({'error': repr(error), 'traceback': traceback.format_exc()}, indent=2) + '\n')
        raise

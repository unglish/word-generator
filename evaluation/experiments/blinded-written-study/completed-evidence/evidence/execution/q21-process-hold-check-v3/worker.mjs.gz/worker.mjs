import { appendFileSync } from 'node:fs';
import { setTimeout as delay } from 'node:timers/promises';
let state = 42;
for (let block = 0; block < 10; block++) {
  const values = [];
  for (let index = 0; index < 1000; index++) {
    state ^= state << 13; state ^= state >>> 17; state ^= state << 5;
    values.push(state >>> 0);
  }
  appendFileSync(process.argv[2], JSON.stringify({block,values,state:state>>>0})+'\n');
  await delay(20);
}

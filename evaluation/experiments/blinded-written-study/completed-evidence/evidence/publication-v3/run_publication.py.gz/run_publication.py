"""Package Q21 after complete original checks and confirmed science resume."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time
import traceback

HERE = Path(__file__).resolve().parent
MAIN = HERE.parents[2]
OUT = Path('/private/tmp/q21-publication-driver-v3')
STAGE = Path('/private/tmp/q21-publication-stage-v3')
PYTHON = '/Users/ryanbetts/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'


def pin(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def inputs():
    return {file.name: pin(file) for file in sorted(HERE.iterdir())}


def wait_success(root):
    while not (root / 'complete.json').exists():
        assert not (root / 'failure.json').exists(), str(root / 'failure.json')
        time.sleep(15)
    assert json.loads((root / 'complete.json').read_bytes())['passed']
    return {'path': str(root / 'complete.json'), **pin(root / 'complete.json')}


def run(name, command):
    with (OUT / (name + '.log')).open('x') as log:
        process = subprocess.run(command, cwd=MAIN, stdout=log, stderr=subprocess.STDOUT)
    record = {'stage': name, 'command': command, 'exitCode': process.returncode,
              'log': pin(OUT / (name + '.log'))}
    with (OUT / 'progress.jsonl').open('a') as stream:
        stream.write(json.dumps(record) + '\n')
    assert process.returncode == 0, str(command) + ' exit ' + str(process.returncode)
    assert inputs() == BEFORE
    print(json.dumps(record), flush=True)
    return record


if __name__ == '__main__':
    OUT.mkdir(mode=0o700)
    try:
        BEFORE = inputs()
        (OUT / 'before.json').write_text(json.dumps(BEFORE, indent=2) + '\n')
        gates = Path('/private/tmp/q21-original-gates-driver-v3')
        prerequisites = [wait_success(gates)]
        while not (gates / 'science-resumed.json').exists():
            time.sleep(.1)
        assert not json.loads((gates / 'science-resumed.json').read_bytes())['errors']
        assert inputs() == BEFORE
        results = [run('prepare', [PYTHON, '-B', str(HERE / 'prepare.py')]),
                   run('independent-full', [PYTHON, '-B', str(HERE / 'verify.py'), '--root', str(STAGE), '--full-local']),
                   run('negative-checks', [PYTHON, '-B', str(HERE / 'corruptions.py')])]
        shutil.copyfile('/private/tmp/q21-publication-corruptions-v3/complete.json', STAGE / 'independent-corruptions.json')
        shutil.copyfile(OUT / 'independent-full.log', STAGE / 'independent-verification.json')
        assert inputs() == BEFORE
        (OUT / 'complete.json').write_text(json.dumps({'passed': True, 'prerequisites': prerequisites,
            'commands': results, 'operators': BEFORE, 'validationIndex': pin(STAGE / 'validation-index.json'),
            'independent': pin(STAGE / 'independent-verification.json'), 'corruptions': pin(STAGE / 'independent-corruptions.json'),
            'scope': 'Complete original calibration, raw evidence and repository outcomes independently verified; five altered packages rejected. Publication still requires exact staging/review; no actual reader preference.'}, indent=2) + '\n')
    except Exception as error:
        (OUT / 'failure.json').write_text(json.dumps({'error': repr(error), 'traceback': traceback.format_exc()}, indent=2) + '\n')
        raise

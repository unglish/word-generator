"""Share filesystem extents for completed raw files without changing their bytes.

Replace each temporary duplicate with an independent filesystem clone of its
already verified retained object. Keep every path, mode, timestamp and hash;
exclude source/runtime/operator files and every active scientific output.
"""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import traceback

BASE = Path(__file__).resolve().parent
ARCHIVE = BASE / 'full-calibration-retained-local-v1'
OUT = Path('/private/tmp/q21-storage-sharing-v1')
COMPLETE = Path('/private/tmp/q21-full-retention-driver-v1/complete.json')
RAW = Path('/private/tmp/q21-calibration-v1')


def pin(path):
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            size += len(block)
            digest.update(block)
    return {'bytes': size, 'sha256': digest.hexdigest()}


if __name__ == '__main__':
    OUT.mkdir(mode=0o700)
    try:
        completion = json.loads(COMPLETE.read_bytes())
        assert completion['passed'] and completion['datasets'] == 14400
        assert pin(ARCHIVE / 'index.json') == completion['index']
        index = json.loads((ARCHIVE / 'index.json').read_bytes())
        records = [record for record in index['records'] if Path(record['original']).is_relative_to(RAW)
                   and record['original'].endswith(('-input.json.gz', '-inference.json.gz'))]
        assert len(records) == 28800
        assert not Path('/private/tmp/q21-original-gates-driver-v2/timing-reservation.json').exists()
        before_free = shutil.disk_usage(RAW).free
        (OUT / 'before.json').write_text(json.dumps({'files': len(records), 'index': pin(ARCHIVE / 'index.json'),
            'operator': pin(Path(__file__)), 'freeBytes': before_free,
            'scope': 'Completed Q21 raw files only. No source, scientific operator, registration, count, seed, result or gate changes.'}, indent=2) + '\n')
        libc = ctypes.CDLL(None, use_errno=True)
        clone = libc.clonefile
        clone.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int]
        clone.restype = ctypes.c_int
        journal = OUT / 'changes.jsonl'
        for ordinal, record in enumerate(records):
            original = Path(record['original'])
            retained = ARCHIVE / record['retained']
            expected = {key: record[key] for key in ('bytes', 'sha256')}
            assert not original.is_symlink() and not retained.is_symlink()
            assert pin(original) == pin(retained) == expected
            previous = original.stat()
            replacement = original.with_name(original.name + '.storage-clone-v1')
            assert not replacement.exists()
            result = clone(os.fsencode(retained), os.fsencode(replacement), 0)
            if result:
                raise OSError(ctypes.get_errno(), 'Filesystem clone failed; original remains intact', str(original))
            assert pin(replacement) == expected
            assert replacement.stat().st_ino != retained.stat().st_ino
            replacement.chmod(previous.st_mode & 0o7777)
            os.utime(replacement, ns=(previous.st_atime_ns, previous.st_mtime_ns))
            os.replace(replacement, original)
            assert pin(original) == pin(retained) == expected
            assert original.stat().st_mtime_ns == previous.st_mtime_ns
            with journal.open('a') as stream:
                stream.write(json.dumps({'original': str(original), 'retained': str(retained), **expected,
                    'previousInode': previous.st_ino, 'newInode': original.stat().st_ino,
                    'retainedInode': retained.stat().st_ino, 'originalModifiedNs': previous.st_mtime_ns}) + '\n')
            if (ordinal + 1) % 1000 == 0:
                print(str(ordinal + 1) + '/' + str(len(records)) + ' complete raw files independently cloned and verified', flush=True)
        assert pin(ARCHIVE / 'index.json') == completion['index']
        (OUT / 'complete.json').write_text(json.dumps({'passed': True, 'files': len(records),
            'logicalDuplicateBytes': sum(record['bytes'] for record in records),
            'freeBytesBefore': before_free, 'freeBytesAfter': shutil.disk_usage(RAW).free,
            'journal': pin(journal), 'index': pin(ARCHIVE / 'index.json'), 'operator': pin(Path(__file__)),
            'scope': 'All28800completed raw files preserved at original and retained paths with identical bytes and independent inodes. Filesystem extents shared, no hard links. Free-space change includes concurrent unrelated scientific writes; no exact freed-byte attribution.'}, indent=2) + '\n')
    except Exception as error:
        (OUT / 'failure.json').write_text(json.dumps({'error': repr(error), 'traceback': traceback.format_exc()}, indent=2) + '\n')
        raise

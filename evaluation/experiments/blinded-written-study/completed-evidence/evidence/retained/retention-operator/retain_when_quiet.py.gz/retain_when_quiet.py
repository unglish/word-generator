"""Retain complete Q21 raw calibration and engineering evidence after Q20 timing."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time
import traceback

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'full-calibration-retained-local-v1'
DRIVER = Path('/private/tmp/q21-full-retention-driver-v1')
ROOT = Path('/Users/ryanbetts/.codex/worktrees/linguistic-q21-written-study/word-generator')
HEAD = '5796cb441e9eb806266406becfcea2f822103e95'
TMP_NAMES = ('q21-calibration-driver-v1', 'q21-calibration-independent-driver-v1', 'q21-calibration-independent-v2',
    'q21-calibration-preflight-independent-v1', 'q21-calibration-preflight-independent-v1.log',
    'q21-calibration-preflight-independent-v2', 'q21-calibration-preflight-independent-v2.log',
    'q21-calibration-preflight-v1', 'q21-calibration-preflight-v1.log', 'q21-calibration-summary-checks-v1',
    'q21-calibration-summary-driver-v1', 'q21-calibration-summary-v1', 'q21-calibration-v1', 'q21-cli-smoke-v1',
    'q21-collection-browser-v1', 'q21-collection-check-driver-v1', 'q21-collection-cli-v1', 'q21-collection-cli-v2',
    'q21-inference-check-driver-v1', 'q21-inference-check-driver-v2', 'q21-inference-oracle-v2')
LOCAL_NAMES = ('calibration', 'calibration-summary', 'collection-cli-amendment.json', 'collection-cli-verification-v2.py',
    'collection-cli-verification.py', 'collection-decision-note.md', 'collection-development', 'collection-draft.json',
    'implementation', 'inference-development', 'inference-rejected-v1', 'inference-verification', 'source-audit.json')
NODE = Path('/Users/ryanbetts/.nvm/versions/node/v24.11.1/bin/node')
PYTHON = Path('/Users/ryanbetts/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3').resolve()


def pin(path):
    digest, size = hashlib.sha256(), 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
            size += len(block)
    return {'bytes': size, 'sha256': digest.hexdigest()}


def prerequisites():
    full = json.loads(Path('/private/tmp/q21-calibration-v1/complete.json').read_bytes())
    independent = json.loads(Path('/private/tmp/q21-calibration-independent-v2/complete.json').read_bytes())
    decisions = json.loads(Path('/private/tmp/q21-calibration-summary-v1/complete.json').read_bytes())
    assert full['passed'] and full['completed'] == 14400
    assert independent['passed'] and independent['datasets'] == 14400 and independent['independentlyReconstructedContrasts'] == 43156800
    assert decisions['executionPassed'] and decisions['datasets'] == 14400
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
    assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=ROOT, text=True).strip()
    return {'operator': pin(Path(__file__)), 'full': pin(Path('/private/tmp/q21-calibration-v1/complete.json')),
            'independent': pin(Path('/private/tmp/q21-calibration-independent-v2/complete.json')),
            'decisions': pin(Path('/private/tmp/q21-calibration-summary-v1/complete.json'))}


if __name__ == '__main__':
    DRIVER.mkdir(mode=0o700)
    try:
        before = prerequisites()
        (DRIVER / 'before.json').write_text(json.dumps(before, indent=2) + '\n')
        marker = Path('/private/tmp/q20-gates-driver-v2/complete.json')
        while not marker.exists():
            assert not marker.with_name('failure.json').exists(), 'Q20 timing execution failed'
            time.sleep(15)
        assert json.loads(marker.read_bytes())['passed'] and prerequisites() == before
        raw_identity = json.loads(Path('/private/tmp/q21-calibration-v1/before.json').read_bytes())['before']
        independent_identity = json.loads(Path('/private/tmp/q21-calibration-independent-v2/before.json').read_bytes())
        inventory = []
        def add(logical, file, expected=None):
            assert file.is_file() and not file.is_symlink(), str(file)
            inventory.append((logical, file, expected))
        def add_tree(logical, directory):
            assert directory.is_dir(), str(directory)
            for file in sorted(directory.rglob('*')):
                if file.is_file():
                    add(logical + '/' + str(file.relative_to(directory)), file)
        for name in TMP_NAMES:
            path = Path('/private/tmp') / name
            if path.is_dir():
                add_tree('execution/' + name, path)
            else:
                add('execution/' + name, path)
        for name in LOCAL_NAMES:
            path = BASE / name
            if path.is_dir():
                add_tree('operators-and-history/' + name, path)
            else:
                add('operators-and-history/' + name, path)
        tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
        assert set(raw_identity['files']) == {name for name in tracked if name}
        for name, identity in raw_identity['files'].items():
            add('source/' + name, ROOT / name, identity)
        for package in raw_identity['dependencies']['packages'].values():
            for name, value in package['files'].items():
                add('loader/' + package['name'] + '/' + package['version'] + '/' + name, Path(value['path']), {'bytes': value['bytes'], 'sha256': value['sha256']})
        for name, identity in independent_identity['numpyFiles'].items():
            add('numpy/' + name, Path(name), identity)
        add('runtime/node', NODE, {'bytes': raw_identity['node']['bytes'], 'sha256': raw_identity['node']['sha256']})
        add('runtime/python', PYTHON, independent_identity['executable'])
        add('retention-operator/retain_when_quiet.py', Path(__file__))
        assert len({logical for logical, _, _ in inventory}) == len(inventory)
        estimate = sum(file.stat().st_size for _, file, _ in inventory)
        free = shutil.disk_usage(OUT.parent).free
        (DRIVER / 'space-gate.json').write_text(json.dumps({'freeBytes': free, 'maximumArchiveBytes': estimate, 'requiredFreeBytes': estimate + 2 * 1024 ** 3}) + '\n')
        assert free >= estimate + 2 * 1024 ** 3, 'Insufficient space for complete evidence; no subsets permitted'
        OUT.mkdir(mode=0o700)
        (OUT / 'objects').mkdir(mode=0o700)
        records = []
        for ordinal, (logical, file, expected) in enumerate(inventory):
            raw = file.read_bytes()
            identity = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
            if expected is not None:
                assert identity == expected, str(file)
            target = OUT / 'objects' / identity['sha256']
            if target.exists():
                assert pin(target) == identity
            else:
                with target.open('xb') as stream:
                    stream.write(raw)
                target.chmod(0o600)
            records.append({'logical': logical, 'original': str(file), 'retained': str(target.relative_to(OUT)), **identity})
            if (ordinal + 1) % 1000 == 0:
                print(str(ordinal + 1) + '/' + str(len(inventory)) + ' complete original evidence files retained', flush=True)
        for record in records:
            expected = {'bytes': record['bytes'], 'sha256': record['sha256']}
            assert pin(OUT / record['retained']) == expected and pin(Path(record['original'])) == expected
        assert prerequisites() == before
        unique = {record['retained']: record['bytes'] for record in records}
        index = {'passed': True, 'sourceCommit': HEAD, 'datasets': 14400, 'independentContrasts': 43156800,
                 'files': len(records), 'uniqueObjects': len(unique), 'retainedBytes': sum(unique.values()), 'records': records,
                 'scope': 'Complete exact Q21 calibration raw inputs/results, independent reconstruction, every registered decision, all preflights/earlier failures, CLI/browser/collector/inference evidence, operators, full tracked source and installed loader/NumPy/Node/Python files. Synthetic law calibration is not human quality or informative-loss correction.'}
        (OUT / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
        (DRIVER / 'complete.json').write_text(json.dumps({'passed': True, 'sourceCommit': HEAD, 'datasets': 14400,
            'independentContrasts': 43156800, 'before': before, 'after': prerequisites(), 'index': pin(OUT / 'index.json'),
            'files': len(records), 'retainedBytes': sum(unique.values())}, indent=2) + '\n')
    except Exception as error:
        (DRIVER / 'failure.json').write_text(json.dumps({'error': repr(error), 'traceback': traceback.format_exc()}, indent=2) + '\n')
        raise

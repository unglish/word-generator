"""Analytical denominator/decision checks, distinct from formal calibration."""
import copy
import json
import math
from pathlib import Path
import unittest

import summarize as model


def observation(point=0, interval=None, reasons=None, finite_truth=0):
    return {'stratum': None, 'point': point, 'interval': interval,
            'withheldReasons': reasons if reasons is not None else (['coverage'] if interval is None else []),
            'truth': {'stratum': None, 'unconditional': 0, 'frozenSpellingPool': finite_truth},
            'coveredUnconditional': bool(interval and interval[0] <= 0 <= interval[1]),
            'coveredFinitePool': bool(interval and interval[0] <= finite_truth <= interval[1]),
            'rejectsZero': bool(interval and (interval[0] > 0 or interval[1] < 0))}


class SummaryChecks(unittest.TestCase):
    scenario = {'delta': 0, 'role': 'calibration'}

    def test_known_wilson_interval(self):
        lower, upper = model.wilson(50, 100)
        self.assertAlmostEqual(lower, .4038315303659957, places=14)
        self.assertAlmostEqual(upper, .5961684696340043, places=14)

    def test_wilson_boundaries_and_no_denominator(self):
        self.assertIsNone(model.wilson(0, 0))
        self.assertAlmostEqual(model.wilson(0, 100)[0], 0, places=14)
        self.assertAlmostEqual(model.wilson(100, 100)[1], 1, places=14)
        self.assertAlmostEqual(model.wilson(0, 100)[1], .0369934982069857, places=14)

    def test_withheld_intervals_remain_in_all_dataset_denominators(self):
        result = model.context_summary([observation(interval=[-.1, .1]), observation()], self.scenario)
        coverage = result['coverage']['unconditional']
        self.assertEqual(coverage['allDatasets']['estimate'], .5)
        self.assertEqual(coverage['availableIntervals']['estimate'], 1)
        self.assertEqual(result['intervalAvailability']['estimate'], .5)
        self.assertEqual(result['withheldDatasets'], 1)

    def test_bias_retains_available_point_from_withheld_interval(self):
        result = model.context_summary([observation(.2, [-.1, .3], finite_truth=.1), observation(.4, finite_truth=.1)], self.scenario)
        bias = result['coverage']['unconditional']['biasAmongAvailablePoints']
        self.assertEqual(bias['count'], 2)
        self.assertAlmostEqual(bias['mean'], .3)
        self.assertAlmostEqual(bias['monteCarloStandardError'], .1)
        self.assertAlmostEqual(result['coverage']['frozenSpellingPool']['biasAmongAvailablePoints']['mean'], .2)

    def test_missing_point_does_not_become_zero(self):
        result = model.context_summary([observation(None)], self.scenario)
        self.assertEqual(result['pointAvailability']['estimate'], 0)
        self.assertIsNone(result['coverage']['unconditional']['biasAmongAvailablePoints']['mean'])
        self.assertIsNone(result['coverage']['unconditional']['availableIntervals']['estimate'])

    def test_complete_coverage_passes_all_registered_null_criteria(self):
        result = model.context_summary([observation(interval=[-.1, .1])] * 1200, self.scenario)
        self.assertEqual(model.decision(result, self.scenario), {'includedInGate': True, 'passed': True, 'failures': []})

    def test_three_failures_are_all_retained(self):
        values = [observation(.2, [.1, .3])] * 100 + [observation(interval=[-.1, .1])] * 900 + [observation()] * 200
        decision = model.decision(model.context_summary(values, self.scenario), self.scenario)
        self.assertFalse(decision['passed'])
        self.assertEqual(len(decision['failures']), 3)

    def test_availability_boundary_uses_registered_point_threshold(self):
        values = [observation(interval=[-.1, .1])] * 1140 + [observation()] * 60
        result = model.context_summary(values, self.scenario)
        self.assertEqual(result['intervalAvailability']['estimate'], .95)
        self.assertTrue(model.decision(result, self.scenario)['passed'])
        values[0] = observation()
        failures = model.decision(model.context_summary(values, self.scenario), self.scenario)['failures']
        self.assertIn('interval availability below .95', failures)

    def test_diagnostic_cannot_pass_or_fail_calibration(self):
        scenario = {'delta': 0, 'role': 'bias-diagnostic'}
        verdict = model.decision(model.context_summary([observation()] * 1200, scenario), scenario)
        self.assertFalse(verdict['includedInGate'])
        self.assertIsNone(verdict['passed'])

    def test_nonzero_truth_uses_coverage_and_direction_without_null_gate(self):
        scenario = {'delta': .08, 'role': 'calibration'}
        item = observation(.08, [.04, .12], finite_truth=.08)
        item['truth']['unconditional'] = .08
        item['coveredUnconditional'] = True
        result = model.context_summary([item] * 1200, scenario)
        self.assertTrue(model.decision(result, scenario)['passed'])
        self.assertEqual(result['directionalDetection']['positive']['estimate'], 1)
        self.assertEqual(result['rejectsZero']['interpretation'], 'two-sided detection')

    def test_tampered_flags_and_nonfinite_values_rejected(self):
        valid = observation(interval=[-.1, .1])
        model.validate_result(valid, self.scenario, None)
        for field, value in [('coveredUnconditional', False), ('point', math.nan), ('interval', [1, -1])]:
            invalid = copy.deepcopy(valid)
            invalid[field] = value
            with self.assertRaises(AssertionError):
                model.validate_result(invalid, self.scenario, None)

    def test_retained_preflight_all_contexts_validate_without_calibration_claim(self):
        path = Path('/private/tmp/q21-calibration-preflight-v1/results.jsonl')
        registration = json.loads(model.REGISTRATION.read_bytes())
        cases = {case['id']: case for case in registration['cases']}
        records = [json.loads(line) for line in path.read_text().splitlines()]
        self.assertEqual(len(records), 12)
        for record in records:
            for result, stratum in zip(record['results'], [None, 'short', 'long']):
                model.validate_result(result, cases[record['scenario']], stratum)
                summary = model.context_summary([result], cases[record['scenario']])
                self.assertEqual(summary['datasets'], 1)


if __name__ == '__main__':
    unittest.main()

"""Queue the full decision report; never apply formal criteria to a partial run."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

BASE = Path(__file__).parent
OUT = Path('/private/tmp/q21-calibration-summary-driver-v1')
UPSTREAM = Path('/private/tmp/q21-calibration-independent-driver-v1')
PYTHON = '/Users/ryanbetts/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'


def pins():
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(BASE.iterdir()) if path.is_file()}


OUT.mkdir()
before = pins()
(OUT / 'before.json').write_text(json.dumps({'tools': before, 'upstream': str(UPSTREAM),
    'scope': 'Apply unchanged registered criteria to all 14400 datasets only after complete independent reconstruction. Execution and calibration verdicts are distinct.'}, indent=2) + '\n')
try:
    print('Full Q21 calibration decision report queued after complete independent verification.', flush=True)
    while not (UPSTREAM / 'complete.json').exists():
        assert not (UPSTREAM / 'failure.json').exists(), 'Independent reconstruction failed; summary not started'
        assert not Path('/private/tmp/q21-calibration-driver-v1/failure.json').exists(), 'Simulation failed; summary not started'
        time.sleep(15)
    upstream = json.loads((UPSTREAM / 'complete.json').read_bytes())
    assert upstream['passed'] is True and upstream['datasets'] == 14400
    independent = Path('/private/tmp/q21-calibration-independent-v2/complete.json')
    assert upstream['reportSha256'] == hashlib.sha256(independent.read_bytes()).hexdigest()
    assert pins() == before
    command = [PYTHON, '-B', str(BASE / 'summarize.py')]
    with (OUT / 'summary.log').open('x') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    assert result.returncode == 0, 'Summary execution failed; failed or partial artifacts retained'
    complete = Path('/private/tmp/q21-calibration-summary-v1/complete.json')
    report = json.loads(complete.read_bytes())
    assert report['executionPassed'] is True and report['datasets'] == 14400
    assert pins() == before
    (OUT / 'complete.json').write_text(json.dumps({'executionPassed': True,
        'calibrationPassed': report['calibrationPassed'], 'tools': before, 'datasets': 14400,
        'command': command, 'exitCode': result.returncode,
        'reportSha256': hashlib.sha256(complete.read_bytes()).hexdigest(),
        'scope': 'Full registered decisions retained even when calibration fails. No human-efficacy or automatic promotion claim.'}, indent=2) + '\n')
except Exception as error:
    (OUT / 'failure.json').write_text(json.dumps({'error': str(error), 'type': type(error).__name__}, indent=2) + '\n')
    raise

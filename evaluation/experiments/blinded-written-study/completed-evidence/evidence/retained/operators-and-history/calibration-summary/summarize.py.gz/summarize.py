"""Apply the unchanged Q21 calibration criteria after complete reconstruction."""
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import platform
import statistics
import sys

BASE = Path(__file__).parent
REGISTRATION = BASE.parent / 'calibration/registration-v2.json'
REGISTRATION_PIN = {'bytes': 11101, 'sha256': 'a339d7d831082874eafd0c56747d3ddd23f72efeec6cc1084fd5af4e213323f5'}
SOURCE = Path('/private/tmp/q21-calibration-v1')
INDEPENDENT = Path('/private/tmp/q21-calibration-independent-v2')
OUT = Path('/private/tmp/q21-calibration-summary-v1')


def pin(path):
    digest, size = hashlib.sha256(), 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
            size += len(block)
    return {'bytes': size, 'sha256': digest.hexdigest()}


def wilson(successes, denominator):
    if denominator == 0:
        return None
    assert 0 <= successes <= denominator
    z = statistics.NormalDist().inv_cdf(.975)
    proportion = successes / denominator
    divisor = 1 + z * z / denominator
    center = (proportion + z * z / (2 * denominator)) / divisor
    radius = z * math.sqrt(proportion * (1 - proportion) / denominator + z * z / (4 * denominator ** 2)) / divisor
    return [max(0.0, center - radius), min(1.0, center + radius)]


def proportion(successes, denominator):
    estimate = successes / denominator if denominator else None
    return {'numerator': successes, 'denominator': denominator,
            'estimate': estimate,
            'monteCarloStandardError': math.sqrt(estimate * (1 - estimate) / denominator) if denominator else None,
            'wilson95': wilson(successes, denominator)}


def moments(values):
    if not values:
        return {'count': 0, 'mean': None, 'standardDeviation': None, 'monteCarloStandardError': None}
    deviation = statistics.stdev(values) if len(values) > 1 else None
    return {'count': len(values), 'mean': statistics.mean(values), 'standardDeviation': deviation,
            'monteCarloStandardError': deviation / math.sqrt(len(values)) if deviation is not None else None}


def direction(delta):
    if delta > 0:
        return 'positive'
    if delta < 0:
        return 'negative'
    return None


def context_summary(results, scenario):
    n = len(results)
    available = [result for result in results if result['interval'] is not None]
    points = [result for result in results if result['point'] is not None]
    withheld = Counter(reason for result in results for reason in result['withheldReasons'])
    widths = [result['interval'][1] - result['interval'][0] for result in available]
    coverage = {}
    for name, flag in [('unconditional', 'coveredUnconditional'), ('frozenSpellingPool', 'coveredFinitePool')]:
        count = sum(result[flag] for result in results)
        coverage[name] = {'allDatasets': proportion(count, n), 'availableIntervals': proportion(count, len(available)),
                          'biasAmongAvailablePoints': moments([result['point'] - result['truth'][name] for result in points])}
    rejections = sum(result['rejectsZero'] for result in results)
    positive = sum(result['interval'][0] > 0 for result in available)
    negative = sum(result['interval'][1] < 0 for result in available)
    return {'datasets': n, 'intervalAvailability': proportion(len(available), n),
            'pointAvailability': proportion(len(points), n), 'withheldDatasets': n - len(available),
            'withheldReasons': dict(sorted(withheld.items())), 'coverage': coverage,
            'rejectsZero': {'allDatasets': proportion(rejections, n), 'availableIntervals': proportion(rejections, len(available)),
                            'interpretation': 'null false-positive rate' if scenario['delta'] == 0 else 'two-sided detection'},
            'directionalDetection': {'positive': proportion(positive, n), 'negative': proportion(negative, n),
                'registeredDirection': direction(scenario['delta'])},
            'intervalWidthAmongAvailable': {**moments(widths), 'minimum': min(widths) if widths else None,
                'median': statistics.median(widths) if widths else None, 'maximum': max(widths) if widths else None}}


def decision(summary, scenario):
    if scenario['role'] == 'bias-diagnostic':
        return {'includedInGate': False, 'passed': None, 'failures': [],
                'reason': 'Preregistered informative-nonresponse diagnostic; no correction or efficacy claim.'}
    failures = []
    if summary['intervalAvailability']['estimate'] < .95:
        failures.append('interval availability below .95')
    if summary['coverage']['unconditional']['allDatasets']['wilson95'][0] < .90:
        failures.append('unconditional all-dataset coverage Wilson lower bound below .90')
    if scenario['delta'] == 0 and summary['rejectsZero']['allDatasets']['wilson95'][1] > .075:
        failures.append('null false-positive all-dataset Wilson upper bound above .075')
    return {'includedInGate': True, 'passed': not failures, 'failures': failures}


def validate_result(result, scenario, stratum):
    assert result['stratum'] == result['truth']['stratum'] == stratum
    assert result['truth']['unconditional'] == scenario['delta']
    assert math.isfinite(result['truth']['frozenSpellingPool'])
    assert isinstance(result['withheldReasons'], list)
    point, interval = result['point'], result['interval']
    assert point is None or math.isfinite(point)
    if interval is None:
        assert result['withheldReasons']
    else:
        assert len(interval) == 2 and all(math.isfinite(value) for value in interval)
        assert interval[0] <= interval[1] and not result['withheldReasons']
    for name, flag in [('unconditional', 'coveredUnconditional'), ('frozenSpellingPool', 'coveredFinitePool')]:
        assert type(result[flag]) is bool
        assert result[flag] == bool(interval and interval[0] <= result['truth'][name] <= interval[1])
    assert type(result['rejectsZero']) is bool
    assert result['rejectsZero'] == bool(interval and (interval[0] > 0 or interval[1] < 0))


def snapshot():
    return {'registration': pin(REGISTRATION), 'runner': pin(Path(__file__)),
            'sourceCompletion': pin(SOURCE / 'complete.json'), 'sourceBefore': pin(SOURCE / 'before.json'),
            'results': pin(SOURCE / 'results.jsonl'), 'independentCompletion': pin(INDEPENDENT / 'complete.json'),
            'independentBefore': pin(INDEPENDENT / 'before.json'),
            'python': sys.version, 'executable': pin(Path(sys.executable).resolve()), 'platform': platform.platform()}


def save(name, value):
    with (OUT / name).open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    OUT.mkdir()
    completed = 0
    try:
        before = snapshot()
        save('before.json', before)
        assert before['registration'] == REGISTRATION_PIN
        reg = json.loads(REGISTRATION.read_bytes())
        parent = json.loads((SOURCE / 'complete.json').read_bytes())
        oracle = json.loads((INDEPENDENT / 'complete.json').read_bytes())
        assert parent['passed'] is True and parent['preflight'] is False and parent['completed'] == 14400
        assert parent['bootstrapReplicates'] == 999 and parent['after']['commit'] == reg['sourceCommit']
        assert parent['results'] == before['results'] and parent['beforeSha256'] == before['sourceBefore']['sha256']
        assert oracle['passed'] is True and oracle['preflight'] is False and oracle['datasets'] == 14400
        assert oracle['independentlyReconstructedContrasts'] == 43156800 and oracle['before'] == oracle['after']
        assert oracle['before']['registration'] == before['registration']
        assert oracle['before']['parentCompletion'] == before['sourceCompletion']
        assert oracle['before']['parentBefore'] == before['sourceBefore'] and oracle['before']['results'] == before['results']
        assert len(reg['cases']) == 12 and reg['datasetsPerCase'] == 1200 and reg['totalFormalDatasets'] == 14400
        cases = {scenario['id']: scenario for scenario in reg['cases']}
        assert len(cases) == 12
        assert oracle['counts'] == {name: 1200 for name in cases}
        assert sum(scenario['role'] == 'calibration' for scenario in cases.values()) == 11
        groups = {name: {stratum: [] for stratum in [None, 'short', 'long']} for name in cases}
        seen, artifact_pins = set(), {}
        with (SOURCE / 'results.jsonl').open() as stream:
            for line in stream:
                record = json.loads(line)
                scenario = cases[record['scenario']]
                index = record['datasetIndex']
                assert type(index) is int and 0 <= index < 1200
                key = (scenario['id'], index)
                assert key not in seen and record['role'] == scenario['role']
                seen.add(key)
                assert len(record['results']) == 3
                for kind in ['input', 'inference']:
                    path = SOURCE / scenario['id'] / f'{index:04d}-{kind}.json.gz'
                    artifact_pins[str(path.relative_to(SOURCE))] = pin(path)
                    assert artifact_pins[str(path.relative_to(SOURCE))] == record['artifacts'][kind]
                for result, stratum in zip(record['results'], [None, 'short', 'long']):
                    validate_result(result, scenario, stratum)
                    groups[scenario['id']][stratum].append(result)
                completed += 1
                if completed % 1200 == 0:
                    print(f'{completed}/14400: complete raw artifact bytes reauthenticated for calibration summary', flush=True)
        assert seen == {(name, index) for name in cases for index in range(1200)}
        reports = []
        for scenario in reg['cases']:
            contexts = [{'stratum': stratum, 'primary': stratum is None,
                         'summary': context_summary(groups[scenario['id']][stratum], scenario)} for stratum in [None, 'short', 'long']]
            verdict = decision(contexts[0]['summary'], scenario)
            reports.append({'scenario': scenario, 'contexts': contexts, 'decision': verdict})
        gate_passed = all(report['decision']['passed'] for report in reports if report['decision']['includedInGate'])
        save('artifacts.json', artifact_pins)
        save('summary.json', {'version': 'q21-calibration-summary-v1', 'purpose': 'development-fixture',
            'sourceCommit': reg['sourceCommit'], 'registration': REGISTRATION_PIN, 'datasets': completed,
            'replicates': 14385600, 'contexts': 43156800, 'cases': reports,
            'calibrationPassed': gate_passed, 'decisionRule': reg['calibrationDecision'],
            'denominators': 'Withheld intervals count against all-dataset availability and coverage; available-interval rates are separately labeled. Bias uses every available point including points whose interval was withheld.',
            'scope': 'Registered synthetic finite-design calibration only. Exploratory strata unadjusted. No actual readers, human preference, representative-population or universal coverage claim. Failures require a separate version and full fresh run; this run is retained.'})
        after = snapshot()
        assert after == before
        save('complete.json', {'executionPassed': True, 'calibrationPassed': gate_passed, 'datasets': completed,
            'before': before, 'after': after, 'summary': pin(OUT / 'summary.json'), 'artifacts': pin(OUT / 'artifacts.json')})
        print(json.dumps({'executionPassed': True, 'calibrationPassed': gate_passed, 'datasets': completed}), flush=True)
    except Exception as error:
        save('failure.json', {'error': str(error), 'type': type(error).__name__, 'completed': completed})
        raise


if __name__ == '__main__':
    main()

"""Verify every formal dataset/replicate after the immutable complete simulation."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

BASE = Path(__file__).parent
OUT = Path('/private/tmp/q21-calibration-independent-driver-v1')
UPSTREAM = Path('/private/tmp/q21-calibration-driver-v1/complete.json')
PYTHON = '/Users/ryanbetts/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'


def pins():
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(BASE.iterdir()) if path.is_file()}


OUT.mkdir()
before = pins()
(OUT / 'before.json').write_text(json.dumps({'tools': before, 'upstream': str(UPSTREAM),
    'scope': 'Every formal raw outcome, original spelling/draw multiplicity, RNG bin and all 43156800 crossed-context replicate contrasts; original unavailable/withheld results stay retained.'}, indent=2) + '\n')
try:
    print('Complete Q21 independent calibration reconstruction queued after all 14400 formal datasets.', flush=True)
    while not UPSTREAM.exists():
        assert not (UPSTREAM.parent / 'failure.json').exists(), 'Formal simulation failed; independent run not started'
        time.sleep(15)
    completion = json.loads(UPSTREAM.read_bytes())
    assert completion['passed'] is True and completion['datasets'] == 14400
    assert pins() == before
    command = [PYTHON, '-B', str(BASE / 'verify-calibration.py')]
    with (OUT / 'independent.log').open('x') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    assert result.returncode == 0, 'Independent reconstruction failed; original outputs/logs retained'
    verified = Path('/private/tmp/q21-calibration-independent-v2/complete.json')
    report = json.loads(verified.read_bytes())
    assert report['passed'] is True and report['preflight'] is False and report['datasets'] == 14400
    assert report['independentlyReconstructedContrasts'] == 43156800
    assert pins() == before
    (OUT / 'complete.json').write_text(json.dumps({'passed': True, 'datasets': 14400, 'tools': before,
        'command': command, 'exitCode': result.returncode,
        'reportSha256': hashlib.sha256(verified.read_bytes()).hexdigest(),
        'scope': 'All formal raw inputs, RNG/draws and replicate arithmetic independently reconstructed. Registered coverage/false-positive decisions and actual reader studies remain; no automatic inference-promotion claim.'}, indent=2) + '\n')
except Exception as error:
    (OUT / 'failure.json').write_text(json.dumps({'error': str(error), 'type': type(error).__name__}, indent=2) + '\n')
    raise

"""Reconstruct every simulated outcome and crossed replicate from raw exports."""
import gzip
import hashlib
import json
import math
from pathlib import Path
import platform
import sys
from collections import Counter

import numpy as np

PREFLIGHT = sys.argv[1:] == ['--preflight']
assert PREFLIGHT or len(sys.argv) == 1
BASE = Path(__file__).parent
INPUT = Path('/private/tmp/q21-calibration-preflight-v1' if PREFLIGHT else '/private/tmp/q21-calibration-v1')
OUT = Path('/private/tmp/q21-calibration-preflight-independent-v2' if PREFLIGHT else '/private/tmp/q21-calibration-independent-v2')
OUT.mkdir()
REGISTRATION = BASE / 'registration-v2.json'
REG = json.loads(REGISTRATION.read_bytes())
COUNTS = {}
COMPLETED = 0


def pin(path):
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
            size += len(block)
    return dict(bytes=size, sha256=digest.hexdigest())


def snapshot():
    numpy_root = Path(np.__file__).parent
    files = {}
    for folder in [numpy_root, numpy_root.parent / 'numpy.libs']:
        if folder.exists():
            for path in sorted(folder.rglob('*')):
                if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
                    files[str(path)] = pin(path)
    return dict(python=sys.version, executable=pin(Path(sys.executable).resolve()), platform=platform.platform(),
                numpy=np.__version__, numpyFiles=files, registration=pin(REGISTRATION), runner=pin(Path(__file__)),
                parentCompletion=pin(INPUT / 'complete.json'), parentBefore=pin(INPUT / 'before.json'),
                results=pin(INPUT / 'results.jsonl'))


def save(name, value):
    with (OUT / name).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def load(path):
    return json.loads(gzip.decompress(path.read_bytes()))


def bins(seed, count):
    # All arithmetic is modulo 2^32. Vectorization changes no state transition.
    mask = np.uint64(0xffffffff)
    states = (np.uint64(seed) + np.arange(1, count + 1, dtype=np.uint64) * np.uint64(0x6d2b79f5)) & mask
    first = ((states ^ (states >> 15)) * (np.uint64(1) | states)) & mask
    second = ((first ^ (first >> 7)) * (np.uint64(61) | first)) & mask
    mixed = ((first + second) & mask) ^ first
    return (mixed ^ (mixed >> 14)) & mask


def near(actual, expected, label):
    assert math.isclose(actual, expected, rel_tol=5e-12, abs_tol=5e-13), (label, actual, expected)


try:
    parent = json.loads((INPUT / 'complete.json').read_bytes())
    assert parent['passed'] is True and parent['preflight'] is PREFLIGHT
    assert parent['completed'] == (12 if PREFLIGHT else 14400)
    assert parent['after']['commit'] == REG['sourceCommit']
    before = snapshot()
    save('before.json', before)
    seen = set()
    for line in (INPUT / 'results.jsonl').read_text().splitlines():
        record = json.loads(line)
        case_index, scenario = next((index, value) for index, value in enumerate(REG['cases']) if value['id'] == record['scenario'])
        coordinate = case_index * REG['datasetsPerCase'] + record['datasetIndex']
        key = scenario['id'], record['datasetIndex']
        assert key not in seen
        seen.add(key)
        assert record['datasetIndex'] == 0 if PREFLIGHT else 0 <= record['datasetIndex'] < 1200
        prefix = str(record['datasetIndex']).zfill(4)
        directory = INPUT / scenario['id']
        raw_path, report_path = directory / (prefix + '-input.json.gz'), directory / (prefix + '-inference.json.gz')
        assert pin(raw_path) == record['artifacts']['input']
        assert pin(report_path) == record['artifacts']['inference']
        raw, report = load(raw_path), load(report_path)
        data = raw['data']
        comparison, plan = data['comparison'], data['plan']
        protocol = comparison['registration']['inference']
        assert raw['purpose'] == comparison['registration']['purpose'] == report['purpose'] == 'development-fixture'
        people = sorted(comparison['registration']['participant_slots'])
        spellings = sorted({item['spelling'] for item in comparison['items']})
        assert len(people) == scenario['readers']
        assert report['factors'] == dict(participants=people, spellings=spellings)
        assert raw['seeds'] == {phase: REG['seeds'][phase + 'Base'] + coordinate for phase in ['latent', 'observation', 'bootstrap']}
        assert protocol['seed'] == raw['seeds']['bootstrap'] and protocol['replicates'] == 999
        assert protocol['confidence'] == .95 and protocol['cohort'] == scenario['cohort']
        assert protocol['minimum_rated_participants'] == protocol['minimum_spellings_per_condition'] == 8
        assert protocol['minimum_draw_coverage'] == .8
        items = {item['id']: item for item in comparison['items']}
        sessions = {session['id']: session for session in plan['sessions']}
        assert len(items) == 4 * scenario['itemsPerConditionPerStratum']
        expected_spellings = len(items) - 2 * scenario['itemsPerConditionPerStratum'] * scenario['sharedFraction']
        assert len(spellings) == expected_spellings
        for condition in ['baseline', 'candidate']:
            expected_population = Counter()
            for stratum_index, stratum in enumerate(['short', 'long']):
                for item_index in range(scenario['itemsPerConditionPerStratum']):
                    index = stratum_index * scenario['itemsPerConditionPerStratum'] + item_index
                    letters = ''.join(chr(97 + (index // (26 ** power)) % 26) for power in [2, 1, 0])
                    prefix = 's' if item_index < scenario['itemsPerConditionPerStratum'] * scenario['sharedFraction'] else 'b' if condition == 'baseline' else 'c'
                    spelling = prefix + ('a' if stratum == 'short' else 'longspelling') + letters
                    expected_population[spelling] = [1, 2, 4, 8][item_index % 4] if scenario['weightedDraws'] else 1
            samples = comparison['conditions'][condition]['samples']
            assert Counter(sample['spelling'] for sample in samples) == expected_population
            original = {sample['id']: sample for sample in samples}
            declared = [item for item in comparison['items'] if item['condition'] == condition]
            assert {item['spelling']: len(item['draws']) for item in declared} == dict(expected_population)
            draw_ids = []
            for item in declared:
                assert item['stratum'] == ('short' if len(item['spelling']) <= 7 else 'long')
                for draw in item['draws']:
                    source = original[draw['sample_id']]
                    assert source['spelling'] == item['spelling'] and source['draw_index'] == draw['draw_index']
                    assert draw['condition'] == condition and draw['stratum'] == item['stratum']
                    draw_ids.append(draw['sample_id'])
            assert Counter(draw_ids) == Counter(original.keys())
        for person in people:
            assigned = [items[item] for session in plan['sessions'] if session['participant_slot'] == person for item in session['item_ids']]
            assert len(assigned) == 4 * scenario['pairsPerStratum']
            assert len({item['spelling'] for item in assigned}) == len(assigned)
            for condition in ['baseline', 'candidate']:
                for stratum in ['short', 'long']:
                    assert sum(item['condition'] == condition and item['stratum'] == stratum for item in assigned) == scenario['pairsPerStratum']
        latent_count = 2 * len(people) + len(spellings)
        latent_uniforms = bins(raw['seeds']['latent'], latent_count + 1).astype(np.float64) / 4294967296
        signs = np.where(latent_uniforms[:-1] < .5, -1, 1).tolist()
        assert raw['latent']['readerSigns'] == dict(zip(people, signs[:len(people)]))
        assert raw['latent']['readerSlopeSigns'] == dict(zip(people, signs[len(people):2 * len(people)]))
        assert raw['latent']['spellingSigns'] == dict(zip(spellings, signs[2 * len(people):]))
        assert raw['rng']['latentDraws'] == latent_count
        assert raw['rng']['latentNextProbe'] == float(latent_uniforms[-1])
        ordered = [(session, position, item_id) for session in plan['sessions'] for position, item_id in enumerate(session['item_ids'])]
        observed_count = len(people) + 3 * len(ordered)
        observation_uniforms = bins(raw['seeds']['observation'], observed_count + 1).astype(np.float64) / 4294967296
        assert raw['rng']['observationDraws'] == observed_count
        assert raw['rng']['observationNextProbe'] == float(observation_uniforms[-1])
        dropped = dict(zip(people, (observation_uniforms[:len(people)] < scenario['readerDropout']).tolist()))
        assert raw['latent']['dropped'] == dropped
        assert len(raw['observations']) == len(ordered)
        expected_responses = []
        for index, ((session, position, item_id), observed) in enumerate(zip(ordered, raw['observations'])):
            item = items[item_id]
            person = session['participant_slot']
            candidate = int(item['condition'] == 'candidate')
            probability = scenario['baselineProbability'] + scenario['delta'] * candidate + scenario['readerAmplitude'] * raw['latent']['readerSigns'][person] + scenario['spellingAmplitude'] * raw['latent']['spellingSigns'][item['spelling']] + scenario['readerSlopeAmplitude'] * raw['latent']['readerSlopeSigns'][person] * candidate
            assert 0 < probability < 1
            near(observed['probability'], probability, 'DGP probability')
            draws = observation_uniforms[len(people) + 3 * index:len(people) + 3 * index + 3]
            assert [observed['favorableDraw'], observed['missingDraw'], observed['familiarityDraw']] == draws.tolist()
            favorable = bool(draws[0] < probability)
            retention = (1 - scenario['mcar']) * (scenario['candidateFavorableRetention'] if candidate and favorable else 1)
            present = not dropped[person] and draws[1] < retention
            familiar = bool(draws[2] < scenario['familiarity'])
            assert (observed['favorable'], observed['present'], observed['familiar']) == (favorable, present, familiar)
            assert (observed['session_id'], observed['position'], observed['item_id']) == (session['id'], position, item_id)
            if present:
                expected_responses.append(dict(id=f'synthetic-{case_index}-{record["datasetIndex"]}-{index + 1}', session_id=session['id'], position=position,
                                               item_id=item_id, answer=dict(status='rated', rating=4 if favorable else 2, familiar=familiar)))
        assert data['responses'] == expected_responses
        ratings = {}
        for response in data['responses']:
            if protocol['cohort'] == 'unfamiliar-only' and response['answer']['familiar']:
                continue
            person = sessions[response['session_id']]['participant_slot']
            ratings.setdefault(response['item_id'], []).append((person, int(response['answer']['rating'] >= 4)))
        person_index, spelling_index = {p: i for i, p in enumerate(people)}, {s: i for i, s in enumerate(spellings)}
        integer_bins = bins(protocol['seed'], 999 * (len(people) + len(spellings))).reshape(999, -1)
        hashes = [hashlib.sha256(json.dumps(row.tolist(), separators=(',', ':')).encode()).hexdigest() for row in integer_bins]
        assert hashes == report['rng_integer_bin_hashes']
        assert report['rng_draws'] == int(integer_bins.size)
        weights = -np.log((integer_bins.astype(np.float64) + .5) / 4294967296)
        reader_weights = weights[:, :len(people)]
        spelling_weights = weights[:, len(people):]
        reader_weights /= reader_weights.max(axis=1, keepdims=True)
        spelling_weights /= spelling_weights.max(axis=1, keepdims=True)
        contexts = [None, 'short', 'long']
        assert len(report['results']) == len(record['results']) == 3
        for context_index, stratum in enumerate(contexts):
            point, shares, reasons = {}, {}, []
            finite_shares = {}
            for condition in ['baseline', 'candidate']:
                pool = [item for item in comparison['items'] if item['condition'] == condition and (stratum is None or item['stratum'] == stratum)]
                mass = sum(len(item['draws']) for item in pool)
                finite_shares[condition] = sum(len(item['draws']) * (scenario['baselineProbability'] + (scenario['delta'] if condition == 'candidate' else 0) + scenario['spellingAmplitude'] * raw['latent']['spellingSigns'][item['spelling']]) for item in pool) / mass
                base, reader, spelling, favorable = [], [], [], []
                covered, rated_people, rated_spellings = 0, set(), set()
                for item in pool:
                    eligible = ratings.get(item['id'], [])
                    if not eligible:
                        continue
                    covered += len(item['draws'])
                    rated_spellings.add(item['spelling'])
                    for person, score in eligible:
                        rated_people.add(person)
                        base.append(len(item['draws']) / len(eligible))
                        reader.append(person_index[person])
                        spelling.append(spelling_index[item['spelling']])
                        favorable.append(score)
                if base:
                    base, favorable = np.array(base), np.array(favorable)
                    shares[condition] = ((reader_weights[:, reader] * spelling_weights[:, spelling] * base) @ favorable) / (reader_weights[:, reader] * spelling_weights[:, spelling] * base).sum(axis=1)
                    favorable_share = float((base @ favorable) / base.sum())
                else:
                    shares[condition] = None
                    favorable_share = None
                point[condition] = dict(share_4_5=favorable_share, covered_draws=covered, pool_draws=mass, draw_coverage=covered / mass,
                                        rated_participants=len(rated_people), rated_spellings=len(rated_spellings))
                for field, minimum in [('rated_participants', 8), ('rated_spellings', 8), ('draw_coverage', .8)]:
                    if point[condition][field] < minimum:
                        reasons.append(condition + ': insufficient ' + {'rated_participants': 'rated participants', 'rated_spellings': 'rated spellings', 'draw_coverage': 'covered draws'}[field])
            actual = report['results'][context_index]
            summary = record['results'][context_index]
            assert actual['stratum'] == summary['stratum'] == stratum
            assert actual['primary'] is (stratum is None)
            near(summary['truth']['unconditional'], scenario['delta'], 'unconditional truth')
            near(summary['truth']['frozenSpellingPool'], finite_shares['candidate'] - finite_shares['baseline'], 'finite pool truth')
            for condition in ['baseline', 'candidate']:
                for field, expected in point[condition].items():
                    if expected is None:
                        assert actual['point'][condition][field] is None
                    else:
                        near(actual['point'][condition][field], expected, field)
            if shares['baseline'] is None or shares['candidate'] is None:
                assert actual['replicates'] == [None] * 999
                assert actual['point']['candidate_minus_baseline'] is None
                reasons.append('unavailable bootstrap replicates retained')
                assert actual['valid_replicates'] == 0 and actual['unavailable_replicates'] == 999
            else:
                differences = shares['candidate'] - shares['baseline']
                assert np.allclose(actual['replicates'], differences, rtol=5e-12, atol=5e-13)
                near(actual['point']['candidate_minus_baseline'], point['candidate']['share_4_5'] - point['baseline']['share_4_5'], 'point contrast')
                assert actual['valid_replicates'] == 999 and actual['unavailable_replicates'] == 0
                if not reasons:
                    expected_interval = np.quantile(differences, [.025, .975], method='linear')
                    assert np.allclose(actual['interval'], expected_interval, rtol=5e-12, atol=5e-13)
            assert actual['interval_withheld_reasons'] == summary['withheldReasons'] == reasons
            if reasons:
                assert actual['interval'] is None
            assert summary['interval'] == actual['interval']
            assert summary['point'] == actual['point']['candidate_minus_baseline']
            interval = actual['interval']
            assert summary['coveredUnconditional'] == bool(interval and interval[0] <= scenario['delta'] <= interval[1])
            assert summary['coveredFinitePool'] == bool(interval and interval[0] <= summary['truth']['frozenSpellingPool'] <= interval[1])
            assert summary['rejectsZero'] == bool(interval and (interval[0] > 0 or interval[1] < 0))
        COMPLETED += 1
        COUNTS[scenario['id']] = COUNTS.get(scenario['id'], 0) + 1
        if PREFLIGHT or COMPLETED % 25 == 0:
            print(f'{scenario["id"]}/{record["datasetIndex"]}: raw law, all 999 bin hashes and all 2997 contrasts independently agree', flush=True)
    assert COMPLETED == (12 if PREFLIGHT else 14400)
    assert set(COUNTS) == {case['id'] for case in REG['cases']}
    assert set(COUNTS.values()) == ({1} if PREFLIGHT else {1200})
    after = snapshot()
    assert after == before
    save('complete.json', dict(passed=True, preflight=PREFLIGHT, datasets=COMPLETED, counts=COUNTS,
                              independentlyReconstructedContrasts=COMPLETED * 999 * 3, before=before, after=after,
                              scope='Every raw synthetic outcome/missingness/familiarity draw, source binding, factor bin, original draw-weighted point and all bootstrap contrasts/withholding/intervals reconstructed. This certifies arithmetic and DGP provenance, not passing coverage, human preference or generalization.'))
except Exception as error:
    save('failure.json', dict(error=str(error), type=type(error).__name__, datasets=COMPLETED, counts=COUNTS))
    raise

import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { existsSync } from "node:fs";
import { readFile, mkdir, writeFile, appendFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { gzipSync } from "node:zlib";
import { setTimeout as delay } from "node:timers/promises";
import { installedDependencies } from "./dependency-closure.mjs";

const tools = dirname(fileURLToPath(import.meta.url));
const registrationPath = join(tools, "registration-v2.json");
const registration = JSON.parse(await readFile(registrationPath, "utf8"));
const preflight = process.argv[2] === "--preflight";
assert(preflight ? process.argv.length === 3 : process.argv.length === 2);
const out = preflight ? "/private/tmp/q21-calibration-preflight-v1" : "/private/tmp/q21-calibration-v1";
const root = registration.sourceRoot;
const sha = bytes => createHash("sha256").update(bytes).digest("hex");
async function pin(path) { const bytes = await readFile(path); return { bytes: bytes.length, sha256: sha(bytes) }; }
const git = (...args) => execFileSync("git", args, { cwd: root, encoding: "utf8" }).trim();
async function snapshot() {
  assert.equal(git("rev-parse", "HEAD"), registration.sourceCommit);
  assert.equal(git("status", "--porcelain", "--untracked-files=no"), "");
  for (const name of ["NODE_OPTIONS", "NODE_PATH", "ESBUILD_BINARY_PATH", "TSX_TSCONFIG_PATH"]) assert(!process.env[name], name);
  const files = {};
  for (const name of git("ls-files", "-z").split("\0").filter(Boolean)) files[name] = await pin(join(root, name));
  return { commit: registration.sourceCommit, files, dependencies: await installedDependencies(root),
    registration: await pin(registrationPath), runner: await pin(fileURLToPath(import.meta.url)),
    dependencyTool: await pin(join(tools, "dependency-closure.mjs")), node: { version: process.version, ...await pin(process.execPath) },
    environment: Object.fromEntries(["PATH", "LANG", "LC_ALL", "TZ", "CI"].map(key => [key, process.env[key] ?? null])) };
}
await mkdir(out);
const save = (path, value) => writeFile(path, JSON.stringify(value) + "\n", { flag: "wx", mode: 0o600 });
const saveGzip = (path, value) => writeFile(path, gzipSync(JSON.stringify(value) + "\n"), { flag: "wx", mode: 0o600 });
let completed = 0;
async function reservedInterval() {
  const active = () => (existsSync("/private/tmp/q11b-candidate-capture-driver-v2/complete.json") || existsSync("/private/tmp/q11b-gates-v1")) && !existsSync("/private/tmp/q11b-gates-driver-v1/complete.json");
  if (!active()) return;
  await appendFile(join(out, "scheduling.jsonl"), JSON.stringify({ event: "paused-before-Q11b-audits-and-gates", completed, at: new Date().toISOString() }) + "\n");
  while (active()) {
    for (const directory of ["/private/tmp/q11b-full-audit-driver-v1", "/private/tmp/q11b-gates-driver-v1"]) {
      for (const name of ["failure.json", "upstream-failure.json"]) assert(!existsSync(join(directory, name)), `Reserved infrastructure failed: ${directory}/${name}`);
    }
    await delay(15000);
  }
  const completion = JSON.parse(await readFile("/private/tmp/q11b-gates-driver-v1/complete.json", "utf8")); assert.equal(completion.passed, true);
  await appendFile(join(out, "scheduling.jsonl"), JSON.stringify({ event: "resumed", completed, at: new Date().toISOString() }) + "\n");
}
try {
  await reservedInterval();
  const before = await snapshot(); await save(join(out, "before.json"), { before, registration, preflight });
  const importFrom = path => import(pathToFileURL(join(root, path)).href);
  const { fixtureSnapshot } = await importFrom("evaluation/review/fixtures.ts");
  const { freezeComparison } = await importFrom("evaluation/review/comparison/comparison-freeze.ts");
  const { allocateComparison } = await importFrom("evaluation/review/comparison/comparison-allocation.ts");
  const { inferWrittenComparison } = await importFrom("evaluation/review/comparison/comparison-inference.ts");
  const { createSeededRng } = await importFrom("src/index.ts");
  assert.equal(registration.cases.length, 12); assert.equal(registration.datasetsPerCase, 1200);
  assert.equal(registration.bootstrapReplicates, 999); assert.equal(registration.totalFormalDatasets, 14400);
  function alpha(index) { let value = index, text = ""; for (let i = 0; i < 3; i++) { text = String.fromCharCode(97 + value % 26) + text; value = Math.floor(value / 26); } assert.equal(value, 0); return text; }
  for (const [caseIndex, scenario] of registration.cases.entries()) {
    const directory = join(out, scenario.id); await mkdir(directory);
    const signsBound = scenario.readerAmplitude + scenario.spellingAmplitude + scenario.readerSlopeAmplitude;
    assert(scenario.baselineProbability - signsBound + Math.min(0, scenario.delta) > 0);
    assert(scenario.baselineProbability + signsBound + Math.max(0, scenario.delta) < 1);
    const count = scenario.itemsPerConditionPerStratum;
    assert(Number.isSafeInteger(count * scenario.sharedFraction));
    const snapshots = {};
    for (const condition of ["baseline", "candidate"]) {
      const spellings = [];
      for (const [stratumIndex, stratum] of ["short", "long"].entries()) for (let item = 0; item < count; item++) {
        const prefix = item < count * scenario.sharedFraction ? "s" : condition === "baseline" ? "b" : "c";
        const spelling = (stratum === "short" ? prefix + "a" : prefix + "longspelling") + alpha(stratumIndex * count + item);
        for (let duplicate = 0; duplicate < (scenario.weightedDraws ? [1, 2, 4, 8][item % 4] : 1); duplicate++) spellings.push(spelling);
      }
      snapshots[condition] = fixtureSnapshot(`calibration-${scenario.id}-${condition}`, spellings, 20);
    }
    await saveGzip(join(directory, "condition-snapshots.json.gz"), snapshots);
    const morphology = ["bare", "prefixed", "suffixed", "prefixed-and-suffixed", "applied-unspecified"];
    const iterations = preflight ? 1 : registration.datasetsPerCase;
    for (let datasetIndex = 0; datasetIndex < iterations; datasetIndex++) {
      await reservedInterval();
      const coordinate = caseIndex * registration.datasetsPerCase + datasetIndex;
      const seeds = Object.fromEntries(["latent", "observation", "bootstrap"].map(phase => [phase, registration.seeds[phase + "Base"] + coordinate]));
      const people = Array.from({ length: scenario.readers }, (_, index) => `reader-${String(index).padStart(3, "0")}`);
      const inference = { version: "written-crossed-bootstrap-v2", metric: "share-4-5", cohort: scenario.cohort,
        seed: seeds.bootstrap, replicates: registration.bootstrapReplicates, confidence: registration.confidence,
        minimum_rated_participants: registration.inferenceEligibility.minimumRatedParticipants,
        minimum_spellings_per_condition: registration.inferenceEligibility.minimumSpellingsPerCondition,
        minimum_draw_coverage: registration.inferenceEligibility.minimumDrawCoverage,
        participant_sampling_assumption: "Registered synthetic reader factors only; zero actual people.",
        spelling_sampling_assumption: "Registered synthetic spelling effects, exact duplicate draws and overlaps; no linguistic quality inference.",
        missingness_assumption: scenario.role === "bias-diagnostic" ? "Informative candidate nonresponse diagnostic; do not infer ignorable missingness." : "Independent synthetic nonresponse/familiarity as registered." };
      const comparison = freezeComparison({ version: "written-comparison-v1", study_id: `calibration-${scenario.id}`, purpose: "development-fixture",
        candidate_selection: "Fixed synthetic law registered before outcomes; no generated treatment quality claim.", population: "Zero actual participants; synthetic Rademacher and Bernoulli factors.",
        assignment_seed: registration.seeds.assignmentSeed, participant_slots: people, pairs_per_stratum: scenario.pairsPerStratum, session_length: 20,
        strata: [{ id: "short", lengths: [1, 7], syllables: [1, 10], morphology }, { id: "long", lengths: [8, 100], syllables: [1, 10], morphology }], inference }, snapshots);
      const plan = allocateComparison(comparison);
      const spellings = [...new Set(comparison.items.map(item => item.spelling))].sort();
      const latentRandom = createSeededRng(seeds.latent), observationRandom = createSeededRng(seeds.observation);
      let latentDraws = 0, observationDraws = 0;
      const sign = () => { latentDraws++; return latentRandom() < .5 ? -1 : 1; };
      const observation = () => { observationDraws++; return observationRandom(); };
      const readerSigns = Object.fromEntries(people.map(person => [person, sign()]));
      const readerSlopeSigns = Object.fromEntries(people.map(person => [person, sign()]));
      const spellingSigns = Object.fromEntries(spellings.map(spelling => [spelling, sign()]));
      const dropped = Object.fromEntries(people.map(person => [person, observation() < scenario.readerDropout]));
      const items = new Map(comparison.items.map(item => [item.id, item]));
      const responses = [], observations = [];
      for (const session of plan.sessions) for (const [position, itemId] of session.item_ids.entries()) {
        const item = items.get(itemId); const candidate = item.condition === "candidate" ? 1 : 0;
        const probability = scenario.baselineProbability + scenario.delta * candidate + scenario.readerAmplitude * readerSigns[session.participant_slot] +
          scenario.spellingAmplitude * spellingSigns[item.spelling] + scenario.readerSlopeAmplitude * readerSlopeSigns[session.participant_slot] * candidate;
        assert(probability > 0 && probability < 1);
        const favorableDraw = observation(), missingDraw = observation(), familiarityDraw = observation();
        const favorable = favorableDraw < probability;
        const retention = (1 - scenario.mcar) * (candidate && favorable ? scenario.candidateFavorableRetention : 1);
        const present = !dropped[session.participant_slot] && missingDraw < retention;
        const familiar = familiarityDraw < scenario.familiarity;
        observations.push({ session_id: session.id, position, item_id: itemId, probability, favorableDraw, missingDraw, familiarityDraw, favorable, present, familiar });
        if (present) responses.push({ id: `synthetic-${caseIndex}-${datasetIndex}-${observations.length}`, session_id: session.id, position, item_id: itemId,
          answer: { status: "rated", rating: favorable ? 4 : 2, familiar } });
      }
      const expectedAssignments = scenario.readers * 4 * scenario.pairsPerStratum;
      assert.equal(observations.length, expectedAssignments); assert.equal(observationDraws, scenario.readers + 3 * expectedAssignments);
      assert.equal(latentDraws, 2 * scenario.readers + spellings.length);
      function finiteTruth(stratum) {
        const shares = {};
        for (const condition of ["baseline", "candidate"]) {
          const pool = comparison.items.filter(item => item.condition === condition && (stratum === null || item.stratum === stratum));
          const mass = pool.reduce((sum, item) => sum + item.draws.length, 0);
          shares[condition] = pool.reduce((sum, item) => sum + item.draws.length * (scenario.baselineProbability +
            (condition === "candidate" ? scenario.delta : 0) + scenario.spellingAmplitude * spellingSigns[item.spelling]), 0) / mass;
        }
        return shares.candidate - shares.baseline;
      }
      const data = { version: "written-comparison-export-v1", comparison, plan, responses };
      const raw = { purpose: "development-fixture", scenario: scenario.id, datasetIndex, seeds, data,
        latent: { readerSigns, readerSlopeSigns, spellingSigns, dropped }, observations,
        rng: { latentDraws, observationDraws, latentNextProbe: latentRandom(), observationNextProbe: observationRandom() },
        truths: [null, "short", "long"].map(stratum => ({ stratum, unconditional: scenario.delta, frozenSpellingPool: finiteTruth(stratum) })) };
      const prefix = String(datasetIndex).padStart(4, "0");
      await saveGzip(join(directory, prefix + "-input.json.gz"), raw);
      const report = inferWrittenComparison(data);
      assert.equal(report.purpose, "development-fixture"); assert.equal(report.results.length, 3);
      assert.equal(report.rng_integer_bin_hashes.length, registration.bootstrapReplicates);
      assert.equal(report.rng_draws, registration.bootstrapReplicates * (people.length + spellings.length));
      assert(report.results.every(result => result.replicates.length === registration.bootstrapReplicates));
      await saveGzip(join(directory, prefix + "-inference.json.gz"), report);
      const results = report.results.map(result => {
        const truth = raw.truths.find(value => value.stratum === result.stratum); const interval = result.interval;
        return { stratum: result.stratum, point: result.point.candidate_minus_baseline, interval,
          withheldReasons: result.interval_withheld_reasons, truth, coveredUnconditional: interval ? interval[0] <= truth.unconditional && truth.unconditional <= interval[1] : false,
          coveredFinitePool: interval ? interval[0] <= truth.frozenSpellingPool && truth.frozenSpellingPool <= interval[1] : false,
          rejectsZero: interval ? interval[0] > 0 || interval[1] < 0 : false,
          input: await pin(join(directory, prefix + "-input.json.gz")), inference: await pin(join(directory, prefix + "-inference.json.gz")) };
      });
      await appendFile(join(out, "results.jsonl"), JSON.stringify({ scenario: scenario.id, role: scenario.role, datasetIndex, results }) + "\n");
      completed++;
      if (preflight || (datasetIndex + 1) % 25 === 0) console.log(`${scenario.id}: ${datasetIndex + 1}/${iterations} complete synthetic datasets; all 999 bootstrap replicates retained`);
    }
  }
  assert.equal(completed, preflight ? 12 : 14400);
  await reservedInterval(); const after = await snapshot(); assert.deepEqual(after, before);
  await save(join(out, "complete.json"), { passed: true, preflight, completed, bootstrapReplicates: registration.bootstrapReplicates,
    beforeSha256: (await pin(join(out, "before.json"))).sha256, results: await pin(join(out, "results.jsonl")), after,
    scope: preflight ? "Only operator shape/counter/binding preflight; no full calibration result." : "Complete registered simulation execution, not a passing calibration conclusion. Independent raw-input/result reconstruction and all registered coverage/false-positive decisions remain. No human observations or linguistic improvement claim." });
} catch (error) {
  await save(join(out, "failure.json"), { error: String(error), stack: error.stack, completed, preflight }); throw error;
}

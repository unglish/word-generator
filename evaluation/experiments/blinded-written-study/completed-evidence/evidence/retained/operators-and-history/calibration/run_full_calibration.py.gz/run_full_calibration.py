"""Run all preregistered simulations only after the complete independent preflight."""
from pathlib import Path
import hashlib
import json
import subprocess

BASE = Path(__file__).parent
OUT = Path('/private/tmp/q21-calibration-driver-v1')
NODE = '/Users/ryanbetts/.nvm/versions/node/v24.11.1/bin/node'
LOADER = '/Users/ryanbetts/Code/unglish/word-generator/node_modules/tsx/dist/loader.mjs'
PREFLIGHT = Path('/private/tmp/q21-calibration-preflight-v1/complete.json')
INDEPENDENT = Path('/private/tmp/q21-calibration-preflight-independent-v2/complete.json')


def pin(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def pins():
    return {str(path): pin(path) for path in sorted(BASE.iterdir()) if path.is_file()}


OUT.mkdir()
before = pins()
(OUT / 'before.json').write_text(json.dumps({'tools': before, 'preflight': pin(PREFLIGHT),
    'independent': pin(INDEPENDENT), 'scope': '14400 datasets, 12 regimes, 1200 datasets per regime, all 999 bootstrap replicates per dataset. Pause before the reserved Q11b audit/gate interval.'}, indent=2) + '\n')
try:
    preflight = json.loads(PREFLIGHT.read_bytes())
    independent = json.loads(INDEPENDENT.read_bytes())
    assert preflight['passed'] is True and preflight['preflight'] is True and preflight['completed'] == 12
    assert independent['passed'] is True and independent['preflight'] is True and independent['datasets'] == 12
    assert independent['independentlyReconstructedContrasts'] == 35964
    assert preflight['after']['runner'] == pin(BASE / 'run-calibration.mjs')
    assert preflight['after']['registration'] == pin(BASE / 'registration-v2.json')
    assert independent['after']['runner'] == pin(BASE / 'verify-calibration.py')
    assert independent['after']['registration'] == preflight['after']['registration']
    command = [NODE, '--import', LOADER, str(BASE / 'run-calibration.mjs')]
    print('Full Q21 calibration started: 14400 datasets / 14385600 retained bootstrap replicates; no human observations.', flush=True)
    with (OUT / 'calibration.log').open('x') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    assert result.returncode == 0, 'Full calibration execution failed; all prior outputs and failure marker retained'
    complete = Path('/private/tmp/q21-calibration-v1/complete.json')
    record = json.loads(complete.read_bytes())
    assert record['passed'] is True and record['preflight'] is False and record['completed'] == 14400
    assert pins() == before
    (OUT / 'complete.json').write_text(json.dumps({'passed': True, 'datasets': 14400, 'tools': before,
        'command': command, 'exitCode': result.returncode, 'completion': pin(complete),
        'scope': 'Registered complete simulation executed. Full independent reconstruction and registered calibration decisions remain; execution completion is not a passing-coverage or human-efficacy claim.'}, indent=2) + '\n')
except Exception as error:
    (OUT / 'failure.json').write_text(json.dumps({'error': str(error), 'type': type(error).__name__}, indent=2) + '\n')
    raise

# Q21 crossed reader/spelling inference draft

The primary outcome is the registered difference in 4–5 rating share, candidate
minus baseline. Register the cohort (`all-ratings` or `unfamiliar-only`), seed,
replicate count, confidence level, coverage requirements and sampling/missingness
assumptions before collecting observations. These settings are part of the frozen
comparison digest. The inference API rejects an external substitute protocol.

## Basis and limits

[Owen and Eckles (2012)](https://arxiv.org/html/1106.2125) motivate independent
factor reweighting when observations share crossed units. Their results concern
mean-variance estimation under stated random-effects conditions. They also
explain why holding observed missingness fixed cannot repair informative
missingness or sampling bias. Those results do not establish exact percentile
coverage for this implementation's normalized item/draw ratio.

This implementation extends that principle to the existing descriptive statistic:
each item's favorable-rating share is normalized over its observed readers, then
items are weighted by their original generator-draw multiplicity. Independent
person and spelling weights perturb the statistic in each replicate. The nested
normalization and percentile interval are an engineering choice requiring
independent arithmetic checks and simulation/calibration, not a theorem supplied
by the citation. Neither a passing fixture nor a narrow interval establishes a
real reader preference, representative recruitment or a default-promotion result.

## Registered computation

Factor lists are fixed from the complete roster and frozen spelling pool, rather
than changing when responses are missing. A spelling shared across conditions or
strata has one factor weight; a person has one weight across all their responses.
Weights are positive exponential transforms of 32-bit midpoint bins from the
public seeded RNG. Every replicate retains its result and integer-bin hash, and
the report records the exact RNG draw count. Midpoint mapping avoids endpoints
that would produce zero or infinite weights. This is a discrete numerical
approximation to continuous exponential reweighting.

For item `i`, reader `p` and observed binary favorable rating `y`:

```
item_share(i) = sum(person_weight(p) * y(p,i)) / sum(person_weight(p))
condition_share = sum(draws(i) * spelling_weight(i) * item_share(i))
                  / sum(draws(i) * spelling_weight(i))
contrast = candidate_share - baseline_share
```

Only items with eligible observed ratings enter those sums. Missing and skipped
ratings are never zero scores. Familiar ratings are excluded only when the
frozen cohort rule specifies that. Original pool/covered draws and rated reader
and spelling counts accompany every estimate. If coverage is incomplete, the
point estimate describes the covered frozen subset; bootstrap weights do not
recover unobserved outcomes.

Intervals use linear interpolation at `(1-confidence)/2` and its upper-tail
counterpart. Any unavailable replicate stays in the report and withholds the
interval; there is no replacement draw or seed retry. Registered participant,
spelling and coverage requirements also withhold intervals. Minimum counts are
eligibility rules, not evidence of adequate statistical power. The pooled
contrast is primary. Stratum intervals are exploratory without multiplicity
adjustment.

## Identity and collection

Human-mode inference requires an owner-held roster binding each participant slot
to one unique opaque person key and one verification-record hash. The roster
must cover the complete planned roster and match the comparison digest. Session
IDs are not person identities. Duplicate people, slots or verification records
and changed/incomplete rosters are rejected.

The roster is owner-attested evidence. Its hash authenticates its contents; the
program cannot prove the people or verification records exist. Keep the private
verification records, actual enrollment evidence, recruitment method and
responses for review. Development fixtures remain explicitly marked and cannot
count as human ratings. The actual study still requires collection transport,
registered precision/power choices, independently validated/calibrated analysis
and real observations.

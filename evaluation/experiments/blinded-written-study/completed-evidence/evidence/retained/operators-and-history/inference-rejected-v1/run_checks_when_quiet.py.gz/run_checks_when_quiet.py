"""Finite Q21 draft checks after reserved timing; failures retained unchanged."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/ryanbetts/.codex/worktrees/linguistic-q21-written-study/word-generator')
OUT = Path('/private/tmp/q21-inference-check-driver-v1')
OUT.mkdir()
NODE = '/Users/ryanbetts/.nvm/versions/node/v24.11.1/bin/node'
LOADER = '/Users/ryanbetts/Code/unglish/word-generator/node_modules/tsx/dist/loader.mjs'
files = sorted((ROOT / 'evaluation/review').rglob('*.ts'))
files += sorted((ROOT / 'src').rglob('*.ts'))
files += [ROOT / name for name in ['package.json', 'package-lock.json', 'tsconfig.review.json', 'vitest.review.config.ts', 'eslint.config.mjs']]
files += [path for path in BASE.iterdir() if path.is_file()]


def pin(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


before = {str(path): pin(path) for path in files}
save(OUT / 'before.json', dict(inputs=before, scope='Draft source/operator identity only; no checks have run yet.'))
try:
    q18 = Path('/private/tmp/q18-gates-driver-v1/complete.json')
    print('Q21 review types, lint, focused suite and independent arithmetic queued after reserved timing and Q19 publication preparation.', flush=True)
    while not q18.exists():
        if (q18.parent / 'failure.json').exists():
            raise RuntimeError('Q18 gate infrastructure failed; no draft checks started')
        time.sleep(15)
    assert json.loads(q18.read_text())['passed']
    publication = Path('/private/tmp/q19-publication-driver-v1')
    while not any((publication / name).exists() for name in ['complete.json', 'failure.json']):
        time.sleep(15)
    q11 = Path('/private/tmp/q11b-gates-v1')
    while q11.exists() and not Path('/private/tmp/q11b-gates-driver-v1/complete.json').exists():
        if Path('/private/tmp/q11b-gates-driver-v1/failure.json').exists():
            raise RuntimeError('Q11b gate infrastructure failed; quiet interval needs inspection')
        time.sleep(15)
    assert before == {str(path): pin(path) for path in files}
    environment = os.environ.copy()
    environment['PATH'] = str(Path(NODE).parent) + ':' + environment['PATH']
    commands = [
        ('review-types', [NODE, str(ROOT / 'node_modules/typescript/bin/tsc'), '-p', 'tsconfig.review.json']),
        ('touched-lint', [NODE, str(ROOT / 'node_modules/eslint/bin/eslint.js'), 'evaluation/review/comparison']),
        ('review-suite', [NODE, str(ROOT / 'node_modules/vitest/vitest.mjs'), 'run', '--config', 'vitest.review.config.ts']),
        ('fixture-export', [NODE, '--import', LOADER, str(BASE / 'export-fixtures.mjs')]),
        ('independent-oracle', ['python3', '-B', str(BASE / 'verify-fixtures.py')]),
    ]
    results = []
    for name, command in commands:
        assert before == {str(path): pin(path) for path in files}
        with (OUT / (name + '.log')).open('x') as log:
            result = subprocess.run(command, cwd=ROOT, env=environment, stdout=log, stderr=subprocess.STDOUT)
        results.append(dict(name=name, command=command, exitCode=result.returncode, log=pin(OUT / (name + '.log'))))
        (OUT / 'progress.json').write_text(json.dumps(results, indent=2) + '\n')
        if result.returncode:
            raise RuntimeError(name + ' failed; draft validation incomplete, source/logs retained')
    after = {str(path): pin(path) for path in files}
    assert before == after
    oracle = json.loads(Path('/private/tmp/q21-inference-oracle-v1/independent-complete.json').read_text())
    assert oracle['passed'] and len(oracle['cases']) == 6
    save(OUT / 'complete.json', dict(passed=True, before=before, after=after, results=results,
         oracle=pin(Path('/private/tmp/q21-inference-oracle-v1/independent-complete.json')),
         scope='Draft review checks and independent fixture arithmetic only. Original repository gates, calibration, collection and real human ratings remain.'))
    print('Q21 draft and independent fixture arithmetic checks passed; no human-efficacy or calibration claim.', flush=True)
except Exception as error:
    save(OUT / 'failure.json', dict(error=str(error), type=type(error).__name__))
    raise

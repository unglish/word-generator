import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
const root = '/Users/ryanbetts/.codex/worktrees/linguistic-q21-written-study/word-generator';
const out = '/private/tmp/q21-inference-oracle-v1';
const load = path => import(pathToFileURL(root + '/' + path));
const { fixtureSnapshot } = await load('evaluation/review/fixtures.ts');
const { freezeComparison } = await load('evaluation/review/comparison/comparison-freeze.ts');
const { allocateComparison } = await load('evaluation/review/comparison/comparison-allocation.ts');
const { inferWrittenComparison } = await load('evaluation/review/comparison/comparison-inference.ts');
const { digest } = await load('evaluation/review/snapshot.ts');
const cases = [];
for (const [index, name] of ['complete', 'partial', 'unfamiliar', 'all-missing', 'equal-favorable', 'attested-fixture'].entries()) {
  const inference = { version: 'written-crossed-bootstrap-v1', metric: 'share-4-5',
    cohort: name === 'unfamiliar' ? 'unfamiliar-only' : 'all-ratings', seed: [0, 1, 42, 0xffffffff, 20261002, 17][index],
    replicates: 64, confidence: .95, minimum_rated_participants: 2, minimum_spellings_per_condition: 2,
    minimum_draw_coverage: .5, participant_sampling_assumption: 'Development fixtures only; no actual participants.',
    spelling_sampling_assumption: 'Arithmetic fixtures only; no population claim.', missingness_assumption: 'Deliberately varied synthetic missingness.' };
  const registration = { version: 'written-comparison-v1', study_id: 'oracle-' + name, purpose: 'development-fixture',
    candidate_selection: 'Synthetic fixtures only; not selected by human results.', population: 'No people or observed human ratings.',
    assignment_seed: 420 + index, pairs_per_stratum: 1, session_length: 4,
    participant_slots: Array.from({ length: 8 }, (_, i) => 'p' + i), inference,
    strata: [{ id: 'short', lengths: [1, 4], syllables: [1, 10], morphology: ['bare', 'prefixed', 'suffixed', 'prefixed-and-suffixed', 'applied-unspecified'] },
      { id: 'long', lengths: [5, 100], syllables: [1, 10], morphology: ['bare', 'prefixed', 'suffixed', 'prefixed-and-suffixed', 'applied-unspecified'] }] };
  const comparison = freezeComparison(registration, {
    baseline: fixtureSnapshot('oracle-base-' + name, ['same', 'baaa', 'baaa', 'babb', 'sharedlong', 'basewide', 'baseline', 'baseline']),
    candidate: fixtureSnapshot('oracle-cand-' + name, ['same', 'caaa', 'cabb', 'sharedlong', 'candwide', 'candlong']),
  });
  const plan = allocateComparison(comparison);
  const responses = [];
  for (const [s, session] of plan.sessions.entries()) for (const [position, item_id] of session.item_ids.entries()) {
    if (name === 'all-missing' || (name === 'partial' && (s + position) % 3 === 0)) continue;
    const skipped = name === 'partial' && (s + position) % 5 === 0;
    responses.push({ id: 'r-' + s + '-' + position, session_id: session.id, position, item_id,
      answer: skipped ? { status: 'skipped', rating: null, familiar: null } : { status: 'rated',
        rating: name === 'equal-favorable' ? 5 : 1 + (s * 3 + position) % 5, familiar: (s + position) % 3 === 0 } });
  }
  const data = { version: 'written-comparison-export-v1', comparison, plan, responses };
  let roster;
  if (name === 'attested-fixture') {
    const content = { version: 'written-enrollment-v1', comparison_digest: comparison.digest,
      verification_method: 'Synthetic attestation fixture; no real enrollment.',
      entries: registration.participant_slots.map((participant_slot, i) => ({ participant_slot, person_key: 'person-' + (7 - i),
        verification_record_sha256: digest(['synthetic-record', i]) })) };
    roster = { ...content, digest: digest(content) };
  }
  const result = inferWrittenComparison(data, roster);
  assert.equal(result.purpose, 'development-fixture');
  cases.push({ name, data, roster: roster ?? null, result });
}
await mkdir(out);
await writeFile(out + '/fixtures.json', JSON.stringify({ version: 'q21-independent-arithmetic-fixtures-v1', cases }) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ cases: cases.length, replicatesPerCase: 64, scope: 'Synthetic arithmetic verification, not human evidence or calibration.' }));

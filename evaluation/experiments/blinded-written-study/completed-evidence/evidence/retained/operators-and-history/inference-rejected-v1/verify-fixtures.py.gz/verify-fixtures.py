"""Independent reconstruction from raw frozen exports, without importing TS preparation."""
import hashlib
import json
import math
from pathlib import Path

OUT = Path('/private/tmp/q21-inference-oracle-v1')
source = OUT / 'fixtures.json'
raw = source.read_bytes()
data = json.loads(raw)


def bins(seed):
    mask = 0xffffffff
    while True:
        seed = (seed + 0x6d2b79f5) & mask
        first = ((seed ^ (seed >> 15)) * (1 | seed)) & mask
        second = ((first ^ (first >> 7)) * (61 | first)) & mask
        mixed = ((first + second) & mask) ^ first
        yield (mixed ^ (mixed >> 14)) & mask


def close(actual, expected, where):
    if expected is None:
        assert actual is None, where
    else:
        assert actual is not None and math.isclose(actual, expected, rel_tol=5e-12, abs_tol=5e-13), (where, actual, expected)


def quantile(values, probability):
    values = sorted(values)
    position = probability * (len(values) - 1)
    lo, hi = math.floor(position), math.ceil(position)
    return values[lo] * (hi - position) + values[hi] * (position - lo) if lo != hi else values[lo]


records = []
for case in data['cases']:
    export, actual = case['data'], case['result']
    comparison = export['comparison']
    registration = comparison['registration']
    protocol = registration['inference']
    assert registration['purpose'] == 'development-fixture'
    person_for_slot = {entry['participant_slot']: entry['person_key'] for entry in case['roster']['entries']} if case['roster'] else {
        slot: slot for slot in registration['participant_slots']}
    people = sorted(person_for_slot.values())
    spellings = sorted({item['spelling'] for item in comparison['items']})
    assert actual['factors'] == dict(participants=people, spellings=spellings)
    sessions = {session['id']: session for session in export['plan']['sessions']}
    ratings = {}
    for response in export['responses']:
        answer = response['answer']
        if answer['status'] != 'rated' or (protocol['cohort'] == 'unfamiliar-only' and answer['familiar']):
            continue
        person = person_for_slot[sessions[response['session_id']]['participant_slot']]
        ratings.setdefault(response['item_id'], []).append((person, int(answer['rating'] >= 4)))

    def condition(condition_name, stratum, reader_weights, spelling_weights):
        items = [item for item in comparison['items'] if item['condition'] == condition_name and (stratum is None or item['stratum'] == stratum)]
        numerator = denominator = 0.0
        pool = sum(len(item['draws']) for item in items)
        covered = 0
        readers_seen, spellings_seen = set(), set()
        for item in items:
            observed = ratings.get(item['id'], [])
            if not observed:
                continue
            reader_mass = sum(reader_weights[person] for person, _ in observed)
            favorable = sum(reader_weights[person] * score for person, score in observed)
            draw_mass = len(item['draws']) * spelling_weights[item['spelling']]
            numerator += draw_mass * (favorable / reader_mass)
            denominator += draw_mass
            covered += len(item['draws'])
            readers_seen.update(person for person, _ in observed)
            spellings_seen.add(item['spelling'])
        return dict(share_4_5=numerator / denominator if denominator else None,
                    covered_draws=covered, pool_draws=pool, draw_coverage=covered / pool if pool else 0,
                    rated_participants=len(readers_seen), rated_spellings=len(spellings_seen))

    def estimate(stratum, reader_weights, spelling_weights):
        control = condition('baseline', stratum, reader_weights, spelling_weights)
        treatment = condition('candidate', stratum, reader_weights, spelling_weights)
        difference = treatment['share_4_5'] - control['share_4_5'] if treatment['share_4_5'] is not None and control['share_4_5'] is not None else None
        return dict(baseline=control, candidate=treatment, candidate_minus_baseline=difference)

    strata = [None] + [stratum['id'] for stratum in registration['strata']]
    points = [estimate(stratum, dict.fromkeys(people, 1), dict.fromkeys(spellings, 1)) for stratum in strata]
    replicates = [[] for _ in strata]
    stream = bins(protocol['seed'])
    hashes = []
    for _ in range(protocol['replicates']):
        integers = [next(stream) for _ in range(len(people) + len(spellings))]
        hashes.append(hashlib.sha256(json.dumps(integers, separators=(',', ':')).encode()).hexdigest())
        weights = [-math.log((value + .5) / 4294967296) for value in integers]
        reader_weights = dict(zip(people, weights[:len(people)]))
        spelling_weights = dict(zip(spellings, weights[len(people):]))
        for i, stratum in enumerate(strata):
            replicates[i].append(estimate(stratum, reader_weights, spelling_weights)['candidate_minus_baseline'])
    assert hashes == actual['rng_integer_bin_hashes'], case['name']
    assert actual['rng_draws'] == protocol['replicates'] * (len(people) + len(spellings))
    assert len(actual['results']) == len(strata)
    for index, result in enumerate(actual['results']):
        assert result['stratum'] == strata[index] and result['primary'] == (index == 0)
        point = points[index]
        close(result['point']['candidate_minus_baseline'], point['candidate_minus_baseline'], (case['name'], index, 'point'))
        reasons = []
        for condition_name in ['baseline', 'candidate']:
            for key, value in point[condition_name].items():
                close(result['point'][condition_name][key], value, (case['name'], index, condition_name, key))
            if point[condition_name]['rated_participants'] < protocol['minimum_rated_participants']:
                reasons.append(condition_name + ': insufficient rated participants')
            if point[condition_name]['rated_spellings'] < protocol['minimum_spellings_per_condition']:
                reasons.append(condition_name + ': insufficient rated spellings')
            if point[condition_name]['draw_coverage'] < protocol['minimum_draw_coverage']:
                reasons.append(condition_name + ': insufficient covered draws')
        values = replicates[index]
        assert len(result['replicates']) == protocol['replicates']
        for replicate, (received, expected) in enumerate(zip(result['replicates'], values)):
            close(received, expected, (case['name'], index, replicate))
        valid = [value for value in values if value is not None]
        if len(valid) != len(values):
            reasons.append('unavailable bootstrap replicates retained')
        assert result['interval_withheld_reasons'] == reasons
        assert result['valid_replicates'] == len(valid) and result['unavailable_replicates'] == len(values) - len(valid)
        if reasons:
            assert result['interval'] is None
        else:
            tail = (1 - protocol['confidence']) / 2
            close(result['interval'][0], quantile(valid, tail), (case['name'], index, 'lower'))
            close(result['interval'][1], quantile(valid, 1 - tail), (case['name'], index, 'upper'))
    records.append(dict(name=case['name'], contexts=len(strata), replicates=protocol['replicates'], integerBinHashesAgree=True))
assert source.read_bytes() == raw
result = dict(passed=True, fixture=dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()), cases=records,
              scope='Independent raw-export arithmetic, all384replicates/1152context contrasts, factor bins, coverage/withholding and percentile checks. Synthetic fixtures do not establish calibration or human efficacy.')
(OUT / 'independent-complete.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(passed=True, cases=len(records), scope=result['scope'])))

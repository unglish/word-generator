# Q21 collection boundary decision

The existing written-review path uses a single Snapshot imported by
`evaluation/review/owner-api.ts`, Supabase/PostgREST RPCs in
`demo/review/api.ts`, and an IndexedDB outbox in `demo/review/local.ts`.
It supports continuing single-study review chains and authenticated submission
retries. These observations come from the current source, not a claim about a
live deployment or tested local Supabase instance.

Q21 requires the separately frozen two-condition ComparisonPlan, fixed roster,
condition/stratum quotas and position balance across every participant's sessions.
The new collector is a separate controlled local-session path for that plan,
sharing the existing Answer validation and unchanged rubric. It does not replace
or migrate the current Supabase/IndexedDB path. There is no changed default
library API or public review deployment.

One owner-controlled local fsynced journal is authoritative. Browser views remain
blinded and authenticate with per-slot opaque tokens; roster and condition/source
artifacts stay owner-private. A saved acknowledgement follows the disk sync.
A failed or ambiguous acknowledgement can be retried identically. Concurrent
conflicting answers fail; duplicate delivery does not create a second response.
The journal lease permits one writer, and receipt validation preserves ordering,
source bindings and explicit missing/skipped outcomes on restart.

This path intentionally serves the controlled collection computer on loopback.
It does not promise remote/network participation or an offline browser outbox.
An answer still in the browser before server acknowledgement is pending, and an
unacknowledged choice can be lost if that page closes. The interface must not
label it saved. Previously acknowledged journal records remain independently
exportable. Future remote participation should extend the existing authenticated
remote infrastructure or adopt a separately reviewed transport; direct P2P adds
no value to this single-owner, same-computer workflow and is not implemented.

Copies of the complete private directory are backups; analysis exports omit
reusable participant credentials and are not restart backups. Preserve original
bytes if a receipt tail or lease needs recovery. The program rejects corruption
rather than silently reconstructing missing human responses.

The draft's intended contracts have tests queued, with no passing collector,
browser, crash/recovery or real-human claim yet. Record those results before
publication. The actual study population, precision/power choices, observed
ratings and calibrated inference are still required to complete Q21.

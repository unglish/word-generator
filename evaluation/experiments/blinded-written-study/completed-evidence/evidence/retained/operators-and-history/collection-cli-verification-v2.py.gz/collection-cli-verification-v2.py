"""Actual CLI/process lifecycle checks using explicitly synthetic responses."""
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import shutil
import signal
import subprocess
import urllib.request

ROOT = Path('/Users/ryanbetts/.codex/worktrees/linguistic-q21-written-study/word-generator')
OUT = Path('/private/tmp/q21-collection-cli-v2')
NODE = '/Users/ryanbetts/.nvm/versions/node/v24.11.1/bin/node'
LOADER = '/Users/ryanbetts/Code/unglish/word-generator/node_modules/tsx/dist/loader.mjs'
CLI = ROOT / 'evaluation/review/comparison/collection/collection-cli.ts'
COMPARE = ROOT / 'evaluation/review/comparison/comparison-cli.ts'
OUT.mkdir(mode=0o700)
assert not Path('/private/tmp/q11b-gates-v1').exists(), 'Reserved timing has begun'
paths = sorted((ROOT / 'evaluation/review').rglob('*.ts')) + [Path(__file__)]


def pins():
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}


def save(path, data):
    with path.open('x') as stream:
        stream.write(json.dumps(data, indent=2) + '\n')
    path.chmod(0o600)


before = pins()
save(OUT / 'before.json', before)
data = json.loads(Path('/private/tmp/q21-inference-oracle-v2/fixtures.json').read_text())['cases'][0]['data']
assert data['comparison']['registration']['purpose'] == 'development-fixture'
save(OUT / 'comparison.json', data['comparison'])
save(OUT / 'plan.json', data['plan'])
results = []


def command(label, script, args, expected=0):
    with (OUT / (label + '.log')).open('x') as log:
        result = subprocess.run([NODE, '--import', LOADER, str(script), *args], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    results.append(dict(name=label, exitCode=result.returncode, expectedExitCode=expected))
    assert result.returncode == expected, label


collection = OUT / 'collection'
command('initialize', CLI, ['initialize', '--input', str(OUT / 'comparison.json'), '--plan', str(OUT / 'plan.json'), '--out', str(collection)])
assert collection.stat().st_mode & 0o777 == 0o700
for name in ['manifest.json', 'credentials.json', 'responses.jsonl']:
    assert (collection / name).stat().st_mode & 0o777 == 0o600
credentials = json.loads((collection / 'credentials.json').read_text())
token = credentials['participants'][0]['token']
owner = credentials['owner_token']
process = None


def start(label):
    global process
    process = subprocess.Popen([NODE, '--import', LOADER, str(CLI), 'serve', '--input', str(collection), '--port', '0'],
                               cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    readiness = selectors.DefaultSelector()
    readiness.register(process.stdout, selectors.EVENT_READ)
    assert readiness.select(20), 'CLI server readiness timed out'
    line = process.stdout.readline()
    readiness.close()
    (OUT / (label + '.log')).write_text(line)
    match = re.search(r'http://127\.0\.0\.1:(\d+)/', line)
    assert match, 'CLI failed before loopback readiness'
    return 'http://127.0.0.1:' + match[1]


def request(base, path, credential, value=None):
    headers = {'Authorization': 'Bearer ' + credential}
    raw = None
    if value is not None:
        raw = json.dumps(value).encode()
        headers['Content-Type'] = 'application/json'
    with urllib.request.urlopen(urllib.request.Request(base + path, data=raw, headers=headers), timeout=10) as response:
        return json.load(response)


try:
    url = start('serve-first')
    first = request(url, '/api/next', token)
    assert first['position'] == 0
    answer = dict(session_id=first['packet']['session_id'], position=0,
                  answer=dict(status='rated', rating=4, familiar=False, comment='Explicit synthetic CLI fixture.'))
    assert request(url, '/api/answer', token, answer)['duplicate'] is False
    assert request(url, '/api/answer', token, answer)['duplicate'] is True
    saved = request(url, '/api/export', owner)
    assert len(saved['responses']) == 1
    process.send_signal(signal.SIGINT)
    assert process.wait(timeout=15) == 0
    assert not (collection / 'writer.lock').exists()
    results.append(dict(name='graceful-stop', exitCode=0, retainedResponses=1))
    url = start('serve-restart')
    resumed = request(url, '/api/next', token)
    assert resumed['packet']['session_id'] == first['packet']['session_id'] and resumed['position'] == 1
    assert request(url, '/api/answer', token, answer)['duplicate'] is True
    skipped = dict(session_id=resumed['packet']['session_id'], position=1, answer=dict(status='skipped', rating=None, familiar=None))
    assert request(url, '/api/answer', token, skipped)['duplicate'] is False
    assert len(request(url, '/api/export', owner)['responses']) == 2
    lease = json.loads((collection / 'writer.lock').read_text())
    assert lease['pid'] == process.pid
    process.kill()
    assert process.wait(timeout=15) == -signal.SIGKILL
    assert (collection / 'writer.lock').exists()
    command('stale-lease-refusal', CLI, ['serve', '--input', str(collection), '--port', '0'], expected=1)
    # This fixture owns the exact process above; wait() has verified its death.
    shutil.copytree(collection, OUT / 'crash-preserved-copy')
    (collection / 'writer.lock').unlink()
    url = start('serve-recovered')
    assert request(url, '/api/next', token)['position'] == 2
    assert request(url, '/api/answer', token, skipped)['duplicate'] is True
    assert len(request(url, '/api/export', owner)['responses']) == 2
    process.send_signal(signal.SIGINT)
    assert process.wait(timeout=15) == 0
    results.append(dict(name='explicit-owned-process-crash-recovery', retainedResponses=2, staleLeaseRefused=True,
                        scope='Actual process SIGKILL after acknowledged fsync; not power-loss/storage-hardware validation.'))
    exported = OUT / 'export'
    command('export', CLI, ['export', '--input', str(collection), '--out', str(exported)])
    command('no-overwrite-export', CLI, ['export', '--input', str(collection), '--out', str(exported)], expected=1)
    command('report', COMPARE, ['report', '--input', str(exported / 'export.json'), '--out', str(OUT / 'report.json')])
    command('infer', COMPARE, ['infer', '--input', str(exported / 'export.json'), '--out', str(OUT / 'inference.json')])
    export = json.loads((exported / 'export.json').read_text())
    assert export['comparison']['registration']['purpose'] == 'development-fixture' and len(export['responses']) == 2
    assert pins() == before
    save(OUT / 'complete.json', dict(passed=True, before=before, after=pins(), results=results, syntheticResponses=2,
         scope='Actual CLI permissions, authenticated save/retry, graceful restart, owned-process crash/stale-lease recovery, export/report/infer. No human responses, visual browser validation, power-loss guarantees or statistical calibration.'))
    print('Synthetic CLI lifecycle passed:2 responses preserved across restart and explicit crash recovery; no human evidence.')
except Exception as error:
    save(OUT / 'failure.json', dict(error=str(error), type=type(error).__name__, results=results))
    raise
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        process.wait(timeout=15)

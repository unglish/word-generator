"""Install/review the collector only after the preceding inference draft has passed."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/ryanbetts/.codex/worktrees/linguistic-q21-written-study/word-generator')
DEST = ROOT / 'evaluation/review/comparison/collection'
OUT = Path('/private/tmp/q21-collection-check-driver-v1')
OUT.mkdir()
NODE = '/Users/ryanbetts/.nvm/versions/node/v24.11.1/bin/node'
files = sorted(path for path in BASE.iterdir() if path.is_file())


def pin(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


pins = {str(path): pin(path) for path in files}
save(OUT / 'before.json', dict(draft=pins, scope='Uncopied collector draft; waits for corrected V2 inference and quiet interval.'))
try:
    prerequisite = Path('/private/tmp/q21-inference-check-driver-v2/complete.json')
    print('Q21 collector installation and checks queued behind V2 inference; no collector code copied or tests run.', flush=True)
    while not prerequisite.exists():
        if (prerequisite.parent / 'failure.json').exists():
            raise RuntimeError('Corrected inference checks failed; collector not copied')
        time.sleep(15)
    report = json.loads(prerequisite.read_text())
    assert report['passed'] and report['before'] == report['after']
    for path, expected in report['after'].items():
        assert pin(Path(path)) == expected, path
    q11 = Path('/private/tmp/q11b-gates-v1')
    while q11.exists() and not Path('/private/tmp/q11b-gates-driver-v1/complete.json').exists():
        if Path('/private/tmp/q11b-gates-driver-v1/failure.json').exists():
            raise RuntimeError('Q11b timing infrastructure failed; quiet interval needs inspection')
        time.sleep(15)
    assert pins == {str(path): pin(path) for path in files}
    DEST.mkdir()
    for path in files:
        if path.suffix == '.ts':
            with (DEST / path.name).open('xb') as stream:
                stream.write(path.read_bytes())
    document = ROOT / 'docs/written-collection.md'
    with document.open('xb') as stream:
        stream.write((BASE / 'written-collection.md').read_bytes())
    installed = {str(path): pin(path) for path in DEST.iterdir() if path.is_file()}
    installed[str(document)] = pin(document)
    save(OUT / 'installed.json', installed)
    environment = os.environ.copy()
    environment['PATH'] = str(Path(NODE).parent) + ':' + environment['PATH']
    commands = [('review-types', [NODE, str(ROOT / 'node_modules/typescript/bin/tsc'), '-p', 'tsconfig.review.json']),
                ('collector-lint', [NODE, str(ROOT / 'node_modules/eslint/bin/eslint.js'), 'evaluation/review/comparison/collection']),
                ('review-suite', [NODE, str(ROOT / 'node_modules/vitest/vitest.mjs'), 'run', '--config', 'vitest.review.config.ts'])]
    results = []
    for name, command in commands:
        with (OUT / (name + '.log')).open('x') as log:
            result = subprocess.run(command, cwd=ROOT, env=environment, stdout=log, stderr=subprocess.STDOUT)
        results.append(dict(name=name, command=command, exitCode=result.returncode, log=pin(OUT / (name + '.log'))))
        (OUT / 'progress.json').write_text(json.dumps(results, indent=2) + '\n')
        if result.returncode:
            raise RuntimeError(name + ' failed; draft and all logs retained, no publication claim')
    for path, expected in report['after'].items():
        assert pin(Path(path)) == expected, path
    assert installed == {path: pin(Path(path)) for path in installed}
    assert pins == {str(path): pin(path) for path in files}
    save(OUT / 'complete.json', dict(passed=True, installed=installed, draft=pins, results=results,
          previousInference=pin(prerequisite), scope='Typed/linted local collector and full review behavior suite. Browser visual pass, CLI workflow, real enrollment/ratings, study-host recovery and calibration still remain.'))
    print('Collector source and review tests passed; no real participant or study-quality claim.', flush=True)
except Exception as error:
    save(OUT / 'failure.json', dict(error=str(error), type=type(error).__name__))
    raise

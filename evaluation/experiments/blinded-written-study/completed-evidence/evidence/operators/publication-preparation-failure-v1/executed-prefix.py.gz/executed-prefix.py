import hashlib,json
from datetime import datetime,timezone
from pathlib import Path
summary_path=Path('/private/tmp/q21-calibration-summary-v1/summary.json')
raw=summary_path.read_bytes(); summary=json.loads(raw)
assert summary['sourceCommit']=='5796cb441e9eb806266406becfcea2f822103e95'
assert summary['calibrationPassed'] and summary['datasets']==14400 and summary['replicates']==999

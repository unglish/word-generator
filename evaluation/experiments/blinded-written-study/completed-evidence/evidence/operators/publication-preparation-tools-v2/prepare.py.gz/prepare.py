"""Prepare reviewer material from the complete independently verified Q21 summary."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
SUMMARY = Path('/private/tmp/q21-calibration-summary-v1/summary.json')
REGISTRATION = BASE / 'calibration/registration-v2.json'
OUT = BASE / 'publication-preparation-v2'


def pin(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def rows(summary):
    result = []
    for case in summary['cases']:
        scenario = case['scenario']
        overall = [context for context in case['contexts'] if context['stratum'] is None]
        assert len(overall) == 1 and overall[0]['primary']
        value = overall[0]['summary']
        coverage = value['coverage']['unconditional']['allDatasets']
        rejection = value['rejectsZero']['allDatasets']
        decision = 'diagnostic'
        if case['decision']['includedInGate']:
            assert case['decision']['passed']
            decision = 'pass'
        result.append({'id': scenario['id'], 'cohort': scenario['cohort'], 'role': scenario['role'],
            'datasets': value['datasets'], 'available': value['intervalAvailability']['numerator'],
            'availableRate': value['intervalAvailability']['estimate'], 'covered': coverage['numerator'],
            'coverageRate': coverage['estimate'], 'coverageWilson95': coverage['wilson95'],
            'zeroRejections': rejection['numerator'], 'zeroRejectionRate': rejection['estimate'],
            'zeroRejectionWilson95': rejection['wilson95'],
            'meanBias': value['coverage']['unconditional']['biasAmongAvailablePoints']['mean'],
            'meanIntervalWidth': value['intervalWidthAmongAvailable']['mean'],
            'directionalDetection': value['directionalDetection'], 'decision': decision})
    assert len(result) == 12 and sum(row['decision'] == 'pass' for row in result) == 11
    return result


def readme(values):
    text = '''# Blinded written baseline/candidate comparisons

The owner can now freeze two source populations, allocate balanced blinded trials, collect ratings locally, and preserve original evidence through analysis. Previously the written-review workflow froze one condition and lacked a complete baseline/candidate comparison with crossed listener/spelling analysis.

The comparison retains original draw multiplicity, exhaustive registered strata, complete spelling matching and no repeated spelling across sessions. Condition order is counterbalanced at planned positions; missing responses and observed position coverage expose attrition. The collector preserves the first presented trial and accepted answer through reload, interrupted transport and process recovery. Source and condition records remain in owner artifacts; reviewer packets expose the registered blinded instrument.

The optional analysis protocol is frozen before outcomes. A distinct owner-attested enrollment roster, shared positive listener/spelling factors, fixed eligible-rating counts and global original-draw-weighted ratios preserve exposure and dependence. All missing, skipped and familiarity observations remain; insufficient coverage withholds intervals and retains every replicate. Owner attestations and response slots do not establish actual people, truthful independence or attention.

## Completed synthetic calibration

Measured source: `5796cb441e9eb806266406becfcea2f822103e95`, relative to control `58baeaa388ee2d83e670764a94f649506b098464`. The generator code is unchanged. Registration retains 12 scenarios with 1,200 datasets each, 999 replicates per dataset and all three contexts. Independent reconstruction checks every original source/assignment/latent/rating/missingness/familiarity/RNG input and all 43,156,800 contrasts across 14,400 datasets. No seed or failed/withheld dataset was removed.

Each row below is the prospectively registered pooled context. Short/long contexts, finite-pool truths, Monte Carlo errors, widths, direction and all denominators remain in the complete summary. Withheld intervals count as not covered in the all-dataset rate.

| Scenario | Cohort | Availability | Full-population coverage | Zero rejection | Mean bias | Registered decision |
| --- | --- | ---: | ---: | ---: | ---: | --- |
'''
    for row in values:
        text += f"| {row['id']} | {row['cohort']} | {row['available']}/1200 | {row['covered']}/1200 ({100 * row['coverageRate']:.3f}%) | {row['zeroRejections']}/1200 | {row['meanBias']:+.6f} | {row['decision']} |\n"
    text += '''
All 11 calibration regimes pass the original availability, coverage and null-rejection criteria under the registered synthetic laws. Their observed pooled coverage is 98.5%–99.833%, indicating conservative intervals in these cases. This establishes neither universal interval coverage nor actual reader preference. Benefit/harm detection remains a power report without a retrospectively added gate.

The informative-candidate-nonresponse diagnostic retains only 28/1,200 full-truth covers (2.333%) and mean contrast bias −0.1946573. Candidate-favorable retention of 0.4 produces strong selection bias despite every interval being available. Successful ignorable-availability calibration supplies no correction for this loss.

## Verification and current publication state

Existing engineering evidence includes strict types, focused lint, a 49-test review suite, six-case independent numerical checks, actual owner CLI/process/crash/recovery tests and a complete four-answer synthetic browser slot. The browser exercised invalid answers, reload, immutable pending skip, interrupted loopback transport and exact journal/export recovery. All observations were development fixtures.

The exact original checks are queued: baseline/candidate unit tests, lint, compiler, quality/trigram/trace diagnostics, review types/suite and six adjacent pairs of unchanged native performance runs. These have not executed yet; passing calibration does not replace them. Complete original raw inputs, failed attempts, decisions, source files and installed runtime dependencies have a separate retention job queued. Publication remains pending both evidence steps.

No actual readers, piloted stopping rule, observed preference, identity/attention validation or generator-quality improvement is established. The generated-word distribution is unchanged; this PR supplies the reproducible written comparison and its bounded synthetic analysis evidence.
'''
    return text


if __name__ == '__main__':
    before = {'summary': pin(SUMMARY), 'registration': pin(REGISTRATION), 'operator': pin(Path(__file__))}
    summary, registration = [json.loads(path.read_bytes()) for path in (SUMMARY, REGISTRATION)]
    assert summary['sourceCommit'] == registration['sourceCommit'] == '5796cb441e9eb806266406becfcea2f822103e95'
    assert summary['calibrationPassed'] and summary['datasets'] == 14400
    assert registration['bootstrapReplicates'] == 999
    assert summary['replicates'] == 14400 * 999 and summary['contexts'] == 14400 * 999 * 3
    assert summary['registration'] == before['registration']
    values = rows(summary)
    OUT.mkdir(mode=0o700)
    (OUT / 'calibration-summary.json').write_bytes(SUMMARY.read_bytes())
    (OUT / 'registration.json').write_bytes(REGISTRATION.read_bytes())
    (OUT / 'pooled-calibration.json').write_text(json.dumps({'sourceCommit': summary['sourceCommit'], 'sourceSummary': before['summary'],
        'rows': values, 'scope': 'All12registered pooled contexts from the completed summary. No subset simulation, human preference or repository gate verdict.'}, indent=2) + '\n')
    (OUT / 'README.md').write_text(readme(values))
    (OUT / 'pr-body-preparation.md').write_text('''The written-review workflow previously lacked a complete blinded baseline/candidate comparison. This adds immutable two-condition sources, balanced complete spelling matching, owner/private packets, durable local collection and a prospectively registered crossed listener/spelling stability analysis. Original draw multiplicity, skips, missing responses, familiarity and withheld intervals remain visible. The generator is unchanged.

The full registered synthetic calibration retains 14,400 datasets and 999 replicates each. Independent reconstruction checks all 43,156,800 contrasts and original source/assignment/rating/RNG inputs. All 11 specified calibration regimes pass; pooled coverage is 98.5%–99.833% under these laws. The informative-nonresponse diagnostic retains only 2.333% full-truth coverage and bias −0.1946573, demonstrating that these intervals do not correct response selection. There are no actual reader judgments or demonstrated output-quality gains.

Existing types/lint, 49 review tests, six numerical fixtures and actual synthetic CLI/browser/crash/recovery evidence pass. Complete exact baseline/candidate repository gates, six paired native timing runs and raw proof retention are queued. This preparation is not ready to publish until their actual results are incorporated.
''')
    assert pin(SUMMARY) == before['summary'] and pin(REGISTRATION) == before['registration']
    assert pin(Path(__file__)) == before['operator']
    index = {'passed': True, 'status': 'reviewable-calibration-materials-original-gates-and-retention-pending',
        'createdAt': datetime.now(timezone.utc).isoformat(), 'sourceCommit': summary['sourceCommit'], 'before': before,
        'files': {file.name: pin(file) for file in sorted(OUT.iterdir())},
        'scope': 'Draft material from exact complete registered evidence. Not publication, repository gate success or actual human quality.'}
    (OUT / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
    print('Complete Q21 reviewer materials prepared; scientific inputs unchanged and original gates/retention remain pending')

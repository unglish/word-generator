"""Give calibrated Q21 an earlier publication interval without changing science.

Hold only the still-waiting owned Q23 scheduler, wait for all earlier bulk
work to finish, run all original Q21/control checks and resume the same Q23
process. Never restart a run, select a dataset subset or lower a gate.
"""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import traceback

HERE = Path(__file__).resolve().parent
REGISTRATION = HERE / 'q21-registration-v1.json'
DRIVER = Path('/private/tmp/q21-original-gates-driver-v1')
MAIN = Path('/Users/ryanbetts/.codex/worktrees/d9c28566-8f5b-432e-a246-5e4070782624/word-generator')
NODE = '/Users/ryanbetts/.nvm/versions/node/v24.11.1/bin/node'
PYTHON = '/Users/ryanbetts/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
LOADER = '/Users/ryanbetts/Code/unglish/word-generator/node_modules/tsx/dist/loader.mjs'
Q23_PID = 74692
Q23_COMMAND = '/Users/ryanbetts/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B .local-evidence/read-aloud-study/categorical-control-v2/run_driver.py full'


def pin(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def inputs():
    return {file.name: pin(file) for file in sorted(HERE.iterdir())}


def q23_state():
    value = subprocess.check_output(['ps', '-p', str(Q23_PID), '-o', 'pid=,ppid=,state=,command='], text=True).strip().split(None, 3)
    assert len(value) == 4 and int(value[0]) == Q23_PID and value[3] == Q23_COMMAND
    return {'pid': int(value[0]), 'parentPid': int(value[1]), 'state': value[2], 'command': value[3]}


def confirmed_hold():
    for _ in range(40):
        state = q23_state()
        if 'T' in state['state']:
            return state
        time.sleep(.05)
    raise AssertionError('Owned Q23 scheduler did not enter its recorded hold')


def wait_terminal(root, name='complete.json'):
    while True:
        for file in (name, 'failure.json', 'upstream-failure.json'):
            path = root / file
            if path.exists():
                return {'marker': str(path), 'pin': pin(path), 'kind': file}
        assert 'T' in q23_state()['state'], 'Owned Q23 scheduler must remain held during the reserved interval'
        time.sleep(15)


def run(command, log):
    with log.open('x') as stream:
        result = subprocess.run(command, cwd=MAIN, stdout=stream, stderr=subprocess.STDOUT)
    assert result.returncode == 0, str(command) + ' exit ' + str(result.returncode)
    return {'command': command, 'exitCode': result.returncode, 'log': pin(log)}


if __name__ == '__main__':
    DRIVER.mkdir(mode=0o700)
    held = False
    try:
        expected = inputs()
        registration = json.loads(REGISTRATION.read_bytes())
        (DRIVER / 'queued-inputs.json').write_text(json.dumps(expected, indent=2) + '\n')
        before = q23_state()
        assert 'T' not in before['state']
        assert not Path('/private/tmp/q20-paired-summary-driver-v2/complete.json').exists()
        assert not Path('/private/tmp/q23-categorical-full-driver-v1/execution.log').exists()
        assert not Path('/private/tmp/q23-categorical-calibration-v1/before.json').exists()
        os.kill(Q23_PID, signal.SIGSTOP)
        held = True
        after = confirmed_hold()
        assert 'T' in after['state'] and before['parentPid'] == after['parentPid']
        (DRIVER / 'scheduler-held.json').write_text(json.dumps({'before': before, 'held': after, 'at': time.time(),
            'scope': 'Execution-order hold before any Q23 formal child or dataset; source, scientific operators, registration, seeds and sizes unchanged.'}, indent=2) + '\n')
        earlier = []
        for name in ('q20-paired-summary-driver-v2', 'q22-auditory-law-driver-v1', 'q21-full-retention-driver-v1', 'q22-inference-retention-driver-v1'):
            earlier.append(wait_terminal(Path('/private/tmp') / name))
        earlier.append(wait_terminal(Path('/private/tmp/q22-auditory-pipeline-driver-v1'), 'preflight-complete.json'))
        assert inputs() == expected and 'T' in q23_state()['state']
        # Terminal numerical/preflight failures permit unrelated Q21 checks;
        # their failure verdicts remain explicit prerequisites for their own PRs.
        (DRIVER / 'earlier-terminal-inputs.json').write_text(json.dumps(earlier, indent=2) + '\n')
        (DRIVER / 'timing-reservation.json').write_text(json.dumps({'active': True, 'entry': 'Q21', 'at': time.time(),
            'scope': 'No new thread-owned bulk work until this driver has a terminal marker;28original commands including12native timing runs.'}, indent=2) + '\n')
        baseline = Path(registration['roots']['control'])
        assert not baseline.exists()
        baseline.parent.mkdir(mode=0o700)
        creation = run(['git', 'worktree', 'add', '--detach', str(baseline), registration['commits']['control']], DRIVER / 'control-creation.log')
        (baseline / 'node_modules').symlink_to('/Users/ryanbetts/Code/unglish/word-generator/node_modules', target_is_directory=True)
        source = json.loads(Path('/private/tmp/q21-calibration-v1/before.json').read_bytes())['before']
        candidate = Path(registration['roots']['candidate'])
        assert source['commit'] == registration['commits']['candidate']
        assert source['files'] == {name: pin(candidate / name) for name in source['files']}
        checks = run([NODE, '--import', LOADER, str(HERE / 'run-gates.mjs'), str(REGISTRATION)], DRIVER / 'gates.log')
        verification = run([PYTHON, '-B', str(HERE / 'verify-gates.py'), '--registration', str(REGISTRATION)], DRIVER / 'independent.log')
        result = json.loads((Path(registration['out']) / 'independent-verification.json').read_bytes())
        assert result['passed'] and result['commands'] == 28
        assert inputs() == expected
        (DRIVER / 'complete.json').write_text(json.dumps({'passed': True, 'entry': 'Q21', 'commands': 28,
            'creation': creation, 'checks': checks, 'verification': verification, 'earlierTerminalInputs': earlier,
            'results': pin(Path(registration['out']) / 'independent-verification.json'), 'operators': expected,
            'scope': 'All exact original/control requirements and independent evidence checks complete; repository command failures remain retained and distinct from execution success.'}, indent=2) + '\n')
    except Exception as error:
        (DRIVER / 'failure.json').write_text(json.dumps({'error': repr(error), 'traceback': traceback.format_exc()}, indent=2) + '\n')
        raise
    finally:
        if held:
            before_resume = q23_state()
            assert 'T' in before_resume['state']
            os.kill(Q23_PID, signal.SIGCONT)
            (DRIVER / 'scheduler-resumed.json').write_text(json.dumps({'before': before_resume, 'pid': Q23_PID, 'signal': 'SIGCONT', 'at': time.time(),
                'scope': 'Resume the same original Q23 scheduler; no restart or changed scientific input.'}, indent=2) + '\n')

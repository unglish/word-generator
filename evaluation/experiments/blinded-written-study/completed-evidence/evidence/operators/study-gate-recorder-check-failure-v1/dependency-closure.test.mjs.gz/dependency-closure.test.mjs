import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { mkdir, mkdtemp, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { test } from 'node:test';
import { installedDependencies, resolveManifest } from './dependency-closure.mjs';

test('records type-only and private metadata through nested Node lookup order', async () => {
  const root = await mkdtemp(join(tmpdir(), 'q21-dependency-resolution-v2-'));
  async function install(base, name, metadata, files = {}) {
    const directory = join(base, 'node_modules', name);
    await mkdir(directory, { recursive: true });
    await writeFile(join(directory, 'package.json'), JSON.stringify({ name, version: '1.0.0', ...metadata }));
    for (const [file, content] of Object.entries(files)) await writeFile(join(directory, file), content);
    return directory;
  }
  await writeFile(join(root, 'package.json'), '{"name":"resolution-fixture"}');
  const parent = await install(root, 'parent', { exports: './index.js', dependencies: {
    '@fixture/types': '1', declarations: '1', runtime: '1', shadow: '1' }, optionalDependencies: { absent: '1' } }, { 'index.js': '' });
  const types = await install(root, '@fixture/types', { exports: { types: './index.d.ts' } }, { 'index.d.ts': 'export type X = string;' });
  const declarations = await install(root, 'declarations', { types: './index.d.ts' }, { 'index.d.ts': 'export type Y = number;' });
  const runtime = await install(root, 'runtime', { exports: './index.js' }, { 'index.js': 'export default 1;' });
  await install(root, 'shadow', {}, { 'index.d.ts': 'outer' });
  const shadow = await install(parent, 'shadow', {}, { 'index.d.ts': 'inner' });
  const closure = await installedDependencies(root, ['parent']);
  assert.equal(Object.keys(closure.packages).length, 5);
  for (const directory of [parent, types, declarations, runtime, shadow]) assert(closure.packages[join(directory, 'package.json')]);
  assert(closure.resolutions.some(record => record.name === 'absent' && record.optional && record.manifest === null));
  assert.equal(closure.packages[join(shadow, 'package.json')].files['index.d.ts'].bytes, 5);
  await assert.rejects(installedDependencies(root, ['absent']), { code: 'MODULE_NOT_FOUND' });
  const malformed = await install(root, 'malformed', { exports: { types: './index.d.ts' } });
  await writeFile(join(malformed, 'package.json'), 'invalid JSON');
  await assert.rejects(resolveManifest(createRequire(join(root, 'package.json')), 'malformed'), SyntaxError);
  const mismatch = await install(root, 'mismatch', { exports: { types: './index.d.ts' } });
  await writeFile(join(mismatch, 'package.json'), JSON.stringify({ name: 'wrong', exports: { types: './index.d.ts' } }));
  await assert.rejects(resolveManifest(createRequire(join(root, 'package.json')), 'mismatch'), /metadata mismatch/);
});

test('retains installed ESLint type-only and declaration packages', async () => {
  const root = '/Users/ryanbetts/Code/unglish/word-generator';
  const require = createRequire(join(root, 'package.json'));
  for (const name of ['@eslint/core', '@types/node']) {
    const manifest = await resolveManifest(require, name);
    assert(manifest.endsWith('/' + name + '/package.json'));
    const closure = await installedDependencies(root, [name]);
    assert(closure.packages[manifest]);
    assert(Object.keys(closure.packages[manifest].files).length > 1);
  }
});

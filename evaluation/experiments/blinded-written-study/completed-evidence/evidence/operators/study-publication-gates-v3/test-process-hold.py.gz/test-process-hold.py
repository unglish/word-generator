"""Prove same-process pause/resume retains a complete deterministic Node stream.

Engineering control check only; it does not replace any registered study draw,
dataset, replicate, quality gate or calibration observation.
"""
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import time

HERE = Path(__file__).resolve().parent
OUT = Path('/private/tmp/q21-process-hold-check-v3')
NODE = '/Users/ryanbetts/.nvm/versions/node/v24.11.1/bin/node'


if __name__ == '__main__':
    OUT.mkdir(mode=0o700)
    spec = importlib.util.spec_from_file_location('gate_control', HERE / 'run_when_quiet.py')
    control = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(control)
    worker = OUT / 'worker.mjs'
    worker.write_text("""import { appendFileSync } from 'node:fs';
import { setTimeout as delay } from 'node:timers/promises';
let state = 42;
for (let block = 0; block < 10; block++) {
  const values = [];
  for (let index = 0; index < 1000; index++) {
    state ^= state << 13; state ^= state >>> 17; state ^= state << 5;
    values.push(state >>> 0);
  }
  appendFileSync(process.argv[2], JSON.stringify({block,values,state:state>>>0})+'\\n');
  await delay(20);
}
""")
    baseline = OUT / 'baseline.jsonl'
    subprocess.run([NODE, str(worker), str(baseline)], check=True)
    actual = OUT / 'held.jsonl'
    process = subprocess.Popen([NODE, str(worker), str(actual)])
    expected = None
    held = False
    try:
        for _ in range(100):
            if actual.exists() and actual.stat().st_size:
                break
            assert process.poll() is None
            time.sleep(.005)
        else:
            raise AssertionError('Engineering worker did not create its first stream block')
        expected = control.process_table()[process.pid]
        os.kill(process.pid, signal.SIGSTOP)
        held = True
        stopped = control.confirm_stopped(expected)
        preserved = actual.read_bytes()
        time.sleep(.1)
        assert actual.read_bytes() == preserved
        assert 'T' in control.same_process(expected)['state']
        wrong = {**expected, 'command': expected['command'] + 'wrong'}
        try:
            control.same_process(wrong)
        except AssertionError:
            pass
        else:
            raise AssertionError('Changed process identity accepted')
        os.kill(process.pid, signal.SIGCONT)
        held = False
        assert process.wait(timeout=5) == 0
        assert actual.read_bytes() == baseline.read_bytes()
        rows = [json.loads(row) for row in actual.read_text().splitlines()]
        assert len(rows) == 10 and sum(len(row['values']) for row in rows) == 10000
        (OUT / 'complete.json').write_text(json.dumps({'passed': True, 'originalPid': process.pid,
            'sameProcessResumed': True, 'heldJournalUnchanged': True, 'byteIdenticalStream': True,
            'numericDraws': 10000, 'wrongIdentityRejected': True, 'before': expected, 'stopped': stopped,
            'scope': 'Ephemeral deterministic Node engineering process only; no scientific producer, samples or gates were changed.'}, indent=2) + '\n')
        print(json.dumps({'passed': True, 'numericDraws': 10000, 'sameProcessResumed': True, 'byteIdenticalStream': True}))
    finally:
        if held and expected is not None:
            control.same_process(expected)
            os.kill(process.pid, signal.SIGCONT)
        if process.poll() is None:
            process.wait(timeout=5)

"""Original study gates with a resumable, owned simulation hold for Q21.

This changes execution order only. No simulation restarts, source changes,
RNG changes, sample reductions or timing overrides are permitted.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import traceback

HERE = Path(__file__).resolve().parent
MAIN = HERE.parent.parent
NODE = '/Users/ryanbetts/.nvm/versions/node/v24.11.1/bin/node'
PYTHON = '/Users/ryanbetts/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
LOADER = '/Users/ryanbetts/Code/unglish/word-generator/node_modules/tsx/dist/loader.mjs'


def pin(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def inputs():
    return {file.name: pin(file) for file in sorted(HERE.iterdir())}


def process_table():
    rows = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,state=,lstart=,command='], text=True).splitlines()
    result = {}
    for row in rows:
        fields = row.split(None, 8)
        assert len(fields) == 9
        result[int(fields[0])] = {'pid': int(fields[0]), 'parentPid': int(fields[1]), 'state': fields[2],
                                 'started': ' '.join(fields[3:8]), 'command': fields[8]}
    return result


def same_process(expected):
    current = process_table().get(expected['pid'])
    assert current is not None
    for key in ('pid', 'parentPid', 'started', 'command'):
        assert current[key] == expected[key], (key, current, expected)
    return current


def confirm_stopped(expected):
    for _ in range(40):
        current = same_process(expected)
        if 'T' in current['state']:
            return current
        time.sleep(.05)
    raise AssertionError('Owned process did not enter its recorded hold')


def stop_unexecuted_v2(out):
    registration = json.loads((HERE / 'unexecuted-v2-supersession.json').read_bytes())
    cancelled = []
    for entry, pid in registration['sessionPids'].items():
        root = Path('/private/tmp/' + entry.lower() + '-original-gates-driver-v2')
        assert (root / 'queued-inputs.json').exists()
        assert not any((root / name).exists() for name in ('timing-reservation.json', 'control-creation.log', 'gates.log', 'failure.json', 'complete.json'))
        current = process_table()[pid]
        assert current['parentPid'] == registration['parentPid']
        assert current['command'] == registration['commandPrefix'] + entry
        assert 'S' in current['state'] and 'T' not in current['state']
        os.kill(pid, signal.SIGSTOP)
        held = confirm_stopped(current)
        # Recheck after the scheduler is stopped; no check may have started.
        assert not any((root / name).exists() for name in ('timing-reservation.json', 'control-creation.log', 'gates.log'))
        os.kill(pid, signal.SIGTERM)
        os.kill(pid, signal.SIGCONT)
        for _ in range(40):
            observed = process_table().get(pid)
            if observed is None or 'Z' in observed['state']:
                break
            time.sleep(.05)
        else:
            raise AssertionError('Dormant superseded scheduler did not terminate')
        record = {'entry': entry, 'before': current, 'held': held, 'signals': ['SIGSTOP', 'SIGTERM', 'SIGCONT'],
                  'originalCommandsExecuted': 0, 'replacementRegistration': str(HERE / (entry.lower() + '-registration-v3.json')),
                  'scope': 'Externally cancelled dormant gate scheduler, before any original test/timing. Scientific jobs and all required gate counts unchanged.'}
        (root / 'external-supersession.json').write_text(json.dumps(record, indent=2) + '\n')
        (root / 'failure.json').write_text(json.dumps({'passed': False, 'externalSupersession': record,
            'reason': 'Unexecuted V2 scheduling superseded by preregistered V3; not a failed repository check or scientific dataset.'}, indent=2) + '\n')
        cancelled.append(record)
    (out / 'unexecuted-v2-supersession.json').write_text(json.dumps(cancelled, indent=2) + '\n')
    return cancelled


def hold_science(registration, out, held):
    expected = registration['scienceHold']
    root = process_table()[expected['rootPid']]
    assert root['parentPid'] == expected['parentPid'] and root['command'] == expected['command']
    assert root['started'] == ' '.join(expected['started'].split()) and 'T' not in root['state']
    assert not Path('/private/tmp/q23-categorical-full-driver-v1/complete.json').exists()
    assert not Path('/private/tmp/q23-categorical-full-driver-v1/failure.json').exists()
    os.kill(root['pid'], signal.SIGSTOP)
    held.append(root)
    confirm_stopped(root)
    # The Node process is stopped first, so it cannot spawn more helpers.
    table = process_table()
    descendants = {root['pid']}
    while True:
        children = {pid for pid, record in table.items() if record['parentPid'] in descendants}
        updated = descendants | children
        if updated == descendants:
            break
        descendants = updated
    for pid in sorted(descendants - {root['pid']}):
        child = table[pid]
        assert '/node_modules/' in child['command'] and ('/esbuild' in child['command'] or '/tsx/' in child['command'])
        assert 'T' not in child['state']
        os.kill(pid, signal.SIGSTOP)
        held.append(child)
        confirm_stopped(child)
    source = Path('/private/tmp/q23-categorical-calibration-v1')
    seal = {'before': pin(source / 'before.json'), 'producerJournal': pin(source / 'results.jsonl')}
    (out / 'science-held.json').write_text(json.dumps({'processes': held, 'sourcePins': seal, 'at': time.time(),
        'scope': 'Same in-memory deterministic simulation and RNG stream held; source, scientific operators, registration, samples and existing dataset bytes unchanged. No restart or human observations.'}, indent=2) + '\n')
    return seal


def wait_success(root):
    while not (root / 'complete.json').exists():
        assert not (root / 'failure.json').exists(), str(root / 'failure.json')
        time.sleep(15)
    assert json.loads((root / 'complete.json').read_bytes())['passed']
    return {'path': str(root / 'complete.json'), 'pin': pin(root / 'complete.json')}


def run(command, log):
    with log.open('x') as stream:
        process = subprocess.run(command, cwd=MAIN, stdout=stream, stderr=subprocess.STDOUT)
    assert process.returncode == 0, str(command) + ' exit ' + str(process.returncode)
    return {'command': command, 'exitCode': process.returncode, 'log': pin(log)}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('entry', choices=('Q21', 'Q22', 'Q23'))
    entry = parser.parse_args().entry
    registration_path = HERE / (entry.lower() + '-registration-v3.json')
    registration = json.loads(registration_path.read_bytes())
    out = Path('/private/tmp/' + entry.lower() + '-original-gates-driver-v3')
    out.mkdir(mode=0o700)
    held = []
    try:
        before = inputs()
        (out / 'queued-inputs.json').write_text(json.dumps(before, indent=2) + '\n')
        prerequisites = [wait_success(Path('/private/tmp') / name) for name in registration['prerequisiteDrivers']]
        assert inputs() == before
        if entry == 'Q21':
            supersession = stop_unexecuted_v2(out)
            scientific_seal = hold_science(registration, out, held)
            assert Path('/private/tmp/q22-auditory-pipeline-driver-v1/preflight-complete.json').exists()
            assert not Path('/private/tmp/q22-auditory-pipeline-driver-v1/full.log').exists()
            for name in ('q20-publication-driver-v1', 'q21-storage-sharing-v1', 'q21-full-retention-driver-v1', 'q22-inference-retention-driver-v1'):
                wait_success(Path('/private/tmp') / name)
        identity = json.loads(Path(registration['fullSourceIdentity']).read_bytes())['before']
        candidate = Path(registration['roots']['candidate'])
        commit = identity['commit'] if entry == 'Q21' else identity['sourceCommit']
        files = identity['files'] if entry == 'Q21' else identity['sourceFiles']
        assert commit == registration['commits']['candidate']
        assert files == {name: pin(candidate / name) for name in files}
        (out / 'timing-reservation.json').write_text(json.dumps({'active': True, 'entry': entry, 'at': time.time(),
            'scope': 'No new owned bulk work before terminal marker; unchanged28original commands and12native timing runs. For Q21 the original owned simulation is held and resumes in finally.'}, indent=2) + '\n')
        baseline = Path(registration['roots']['control'])
        assert not baseline.exists()
        baseline.parent.mkdir(mode=0o700)
        creation = run(['git', 'worktree', 'add', '--detach', str(baseline), registration['commits']['control']], out / 'control-creation.log')
        (baseline / 'node_modules').symlink_to('/Users/ryanbetts/Code/unglish/word-generator/node_modules', target_is_directory=True)
        checks = run([NODE, '--import', LOADER, str(HERE / 'run-gates.mjs'), str(registration_path)], out / 'gates.log')
        verification = run([PYTHON, '-B', str(HERE / 'verify-gates.py'), '--registration', str(registration_path)], out / 'independent.log')
        result = json.loads((Path(registration['out']) / 'independent-verification.json').read_bytes())
        assert result['passed'] and result['commands'] == 28 and inputs() == before
        if held:
            for process in held:
                assert 'T' in same_process(process)['state']
            root = Path('/private/tmp/q23-categorical-calibration-v1')
            assert scientific_seal == {'before': pin(root / 'before.json'), 'producerJournal': pin(root / 'results.jsonl')}
        (out / 'complete.json').write_text(json.dumps({'passed': True, 'entry': entry, 'commands': 28,
            'creation': creation, 'checks': checks, 'verification': verification, 'prerequisites': prerequisites,
            'results': pin(Path(registration['out']) / 'independent-verification.json'), 'operators': before,
            'scope': 'All exact original commands, source/compiler/report/log/timing evidence independently checked. Repository failures remain failed; no human benefit or promotion.'}, indent=2) + '\n')
    except Exception as error:
        (out / 'failure.json').write_text(json.dumps({'error': repr(error), 'traceback': traceback.format_exc()}, indent=2) + '\n')
        raise
    finally:
        resumed = []
        errors = []
        for process in reversed(held):
            try:
                current = same_process(process)
                assert 'T' in current['state']
                os.kill(process['pid'], signal.SIGCONT)
                resumed.append({'before': current, 'signal': 'SIGCONT', 'at': time.time()})
            except Exception as error:
                errors.append({'expected': process, 'error': repr(error)})
        if held:
            (out / 'science-resumed.json').write_text(json.dumps({'processes': resumed, 'errors': errors,
                'scope': 'Resume the same original processes and in-memory RNG state, including after any gate/operator failure; no restarted datasets.'}, indent=2) + '\n')
        assert not errors, errors

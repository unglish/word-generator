"""Losslessly compress archived text and reverify the exact staged Q21 packet."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import traceback

HERE = Path(__file__).resolve().parent
ROOT = Path('/Users/ryanbetts/.codex/worktrees/linguistic-q21-written-study/word-generator')
TARGET = ROOT / 'evaluation/experiments/blinded-written-study/completed-evidence'
ORIGINAL = Path('/private/tmp/q21-publication-stage-v4')
OUT = Path('/private/tmp/q21-publication-staging-v2')
PYTHON = '/Users/ryanbetts/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'


def pin_bytes(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def pin(path):
    return pin_bytes(path.read_bytes())


def run(name, command):
    log = OUT / (name + '.log')
    with log.open('x') as stream:
        process = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    record = {'name': name, 'command': command, 'exitCode': process.returncode, 'log': pin(log)}
    with (OUT / 'progress.jsonl').open('a') as stream:
        stream.write(json.dumps(record) + '\n')
    assert process.returncode == 0, record
    print(json.dumps(record), flush=True)
    return record


if __name__ == '__main__':
    OUT.mkdir(mode=0o700)
    try:
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == '5796cb441e9eb806266406becfcea2f822103e95'
        index = json.loads((TARGET / 'validation-index.json').read_bytes())
        old = json.loads((ORIGINAL / 'validation-index.json').read_bytes())
        assert index == old
        operators = {file.name: pin(file) for file in sorted(HERE.iterdir())}
        (OUT / 'before.json').write_text(json.dumps({'index': pin(TARGET / 'validation-index.json'), 'operators': operators}, indent=2) + '\n')
        changed = []
        for record in index['records']:
            source = ORIGINAL / record['path']
            target = TARGET / record['path']
            assert pin(target) == pin(source) == record['saved']
            if record['path'].startswith('evidence/') and record['compression'] == 'none':
                raw = target.read_bytes()
                assert pin_bytes(raw) == record['original']
                saved = target.with_name(target.name + '.gz')
                assert not saved.exists()
                encoded = gzip.compress(raw, mtime=0)
                saved.write_bytes(encoded)
                assert gzip.decompress(saved.read_bytes()) == raw
                changed.append({'from': record['path'], 'to': saved.relative_to(TARGET).as_posix(), 'original': record['original']})
                target.unlink()  # Only the derived Git packet; originals remain.
                record.update(path=saved.relative_to(TARGET).as_posix(), compression='gzip', saved=pin(saved))
        index['encodingRevision'] = 'Lossless historical-text gzip v5; all original decoded bytes preserved.'
        (TARGET / 'validation-index.json').write_text(json.dumps(index, indent=2) + '\n')
        for before, after in zip(old['records'], index['records']):
            assert before['origin'] == after['origin'] and before['original'] == after['original']
            raw = (TARGET / after['path']).read_bytes()
            decoded = gzip.decompress(raw) if after['compression'] == 'gzip' else raw
            assert pin_bytes(decoded) == before['original']
        commands = [run('independent-full', [PYTHON, '-B', str(TARGET / 'verify.py'), '--root', str(TARGET), '--full-local']),
                    run('negative-checks', [PYTHON, '-B', str(HERE / 'corruptions.py')])]
        (TARGET / 'independent-verification.json').write_bytes((OUT / 'independent-full.log').read_bytes())
        (TARGET / 'independent-corruptions.json').write_bytes(Path('/private/tmp/q21-publication-corruptions-v5/complete.json').read_bytes())
        proof = json.loads((TARGET / 'publication-proof-index.json').read_bytes())
        supplements = [Path('/private/tmp/q21-publication-staging-v1/complete.json'),
                       Path('/private/tmp/q21-publication-staging-v1/whitespace-check.log'),
                       Path('/private/tmp/q21-stage-publication-v1.py'), ORIGINAL / 'validation-index.json',
                       OUT / 'before.json', OUT / 'progress.jsonl', OUT / 'independent-full.log', OUT / 'negative-checks.log']
        supplements += sorted(HERE.iterdir())
        for source in supplements:
            encoded = gzip.compress(source.read_bytes(), mtime=0)
            relative = 'publication-proof/encoding-v5/' + source.parent.name + '/' + source.name + '.gz'
            saved = TARGET / relative
            saved.parent.mkdir(parents=True, exist_ok=True)
            saved.write_bytes(encoded)
            proof['records'].append({'path': relative, 'origin': str(source), 'original': pin(source), 'saved': pin(saved), 'compression': 'gzip'})
        proof.update(validationIndex=pin(TARGET / 'validation-index.json'), independent=pin(TARGET / 'independent-verification.json'),
                     corruptions=pin(TARGET / 'independent-corruptions.json'), losslessReencodedFiles=changed)
        (TARGET / 'publication-proof-index.json').write_text(json.dumps(proof, indent=2) + '\n')
        for record in proof['records']:
            saved = TARGET / record['path']
            assert pin(saved) == record['saved'] and pin_bytes(gzip.decompress(saved.read_bytes())) == record['original']
        assert {file.name: pin(file) for file in sorted(HERE.iterdir())} == operators
        for name, identity in index['sourcePins'].items():
            assert pin(ROOT / name) == identity
        scope = TARGET.relative_to(ROOT).as_posix()
        subprocess.run(['git', 'add', '-A', '--', scope], cwd=ROOT, check=True)
        commands.append(run('whitespace', ['git', 'diff', '--cached', '--check']))
        paths = [name for name in subprocess.check_output(['git', 'diff', '--cached', '--name-only', '-z'], cwd=ROOT).decode().split('\0') if name]
        expected = {file.relative_to(ROOT).as_posix() for file in TARGET.rglob('*') if file.is_file()} | {'docs/written-study-evidence.md'}
        assert set(paths) == expected
        result = {'passed': True, 'files': len(paths), 'losslessReencodedFiles': len(changed), 'commands': commands,
                  'index': pin(TARGET / 'validation-index.json'), 'proofIndex': pin(TARGET / 'publication-proof-index.json'),
                  'stagedPaths': paths, 'operators': operators, 'scope': 'Every original byte preserved; only historical text encoding changed. All full-local, six negative-package and whitespace checks pass; runtime source unchanged.'}
        (OUT / 'complete.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps({key: value for key, value in result.items() if key not in ('stagedPaths', 'commands', 'operators')}))
    except Exception as error:
        (OUT / 'failure.json').write_text(json.dumps({'error': repr(error), 'traceback': traceback.format_exc()}, indent=2) + '\n')
        raise

"""Stage only Q21's verified public evidence and its results entry point."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

ROOT=Path('/Users/ryanbetts/.codex/worktrees/linguistic-q21-written-study/word-generator')
SOURCE=Path('/private/tmp/q21-publication-stage-v4')
TARGET=ROOT/'evaluation/experiments/blinded-written-study/completed-evidence'
MEASURED='5796cb441e9eb806266406becfcea2f822103e95'
DOC=ROOT/'docs/written-study-evidence.md'
OUT=Path('/private/tmp/q21-publication-staging-v1')


def pin(path):
    raw=path.read_bytes()
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


if __name__=='__main__':
    OUT.mkdir(mode=0o700)
    complete=json.loads(Path('/private/tmp/q21-publication-driver-v4/complete.json').read_bytes())
    assert complete['passed'] and complete['validationIndex']==pin(SOURCE/'validation-index.json')
    assert complete['independent']==pin(SOURCE/'independent-verification.json')
    assert complete['corruptions']==pin(SOURCE/'independent-corruptions.json')
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==MEASURED
    assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True).strip()
    index=json.loads((SOURCE/'validation-index.json').read_bytes())
    for name,identity in index['sourcePins'].items():assert pin(ROOT/name)==identity,name
    assert not TARGET.exists() and not DOC.exists()
    shutil.copytree(SOURCE,TARGET)
    supplemental=[]
    for label in ('q21-publication-driver-v3','q21-publication-driver-v4','q21-publication-corruptions-v3','q21-publication-corruptions-v4'):
        source=Path('/private/tmp')/label
        # Complete altered packages remain private; retain their verdicts only.
        files=[source/'complete.json'] if 'corruptions' in label else sorted(source.iterdir())
        for file in files:
            assert file.is_file()
            raw=file.read_bytes()
            encoded=gzip.compress(raw,mtime=0)
            relative='publication-proof/'+label+'/'+file.name+'.gz'
            target=TARGET/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(encoded)
            supplemental.append({'path':relative,'origin':str(file),'original':pin(file),'saved':pin(target),'compression':'gzip'})
    DOC.write_text('''# Written comparison evidence

Q21 adds frozen baseline/candidate written comparisons, balanced blinded assignments, a durable local collector and a prospectively registered crossed reader/spelling analysis. The generator and original gate sources are unchanged relative to measured control `58baeaa388ee2d83e670764a94f649506b098464`.

Start with [the complete results and limitations](../evaluation/experiments/blinded-written-study/completed-evidence/RESULTS.md). The protocol and workflow are described in [written comparison](written-comparison.md), [collection and recovery](written-collection.md) and [inference assumptions](written-inference-method.md). Implementation entry points are the freeze/allocation/report modules under `evaluation/review/comparison/`; collector persistence and recovery live under its `collection/` directory.

All 14,400 registered synthetic datasets, 999 replicates each and 43,156,800 contrasts were independently reconstructed. Eleven specified calibration regimes pass; pooled observed coverage is 98.5%–99.833%, conservative under these laws. Informative candidate nonresponse retains only 28/1,200 full-truth covers and mean bias −0.1946573. It supplies no correction for informative human attrition. Benefit/harm detection is reported without adding a retrospective power gate.

All 28 original baseline/candidate commands completed: 26 passed and two lint runs failed with the same 11 inherited errors. Unit tests, compiler, quality, trigram/trace diagnostics, review checks and all 12 native performance runs passed. The median candidate/control throughput ratio is 0.992709 from the original rounded logs; this is not an output-quality gain. Original sample sizes, timeouts and floors remain unchanged. The earlier dependency-recorder failure and dormant scheduling supersession remain in the evidence.

The public packet verifies every compact artifact and independently recounts all 36 calibration contexts. Six altered complete packages were rejected, including missing original data, falsified native outcomes, false informative-loss success and a credential-value injection. Run `python3 verify.py --root .` inside `evaluation/experiments/blinded-written-study/completed-evidence` to recheck it. The supplemental `publication-proof-index.json` binds the final operators and verdict logs; retained local indexes expose every original path and hash.

All 30,263 original archive files and 7,676 additional gate-provenance entries were rehashed on the evidence owner's machine. `--full-local` repeats original/retained raw, source and installed-runtime checks there. Four fixture credential files retain original bytes only in the verified local archive; public evidence includes hashes and scans all decoded artifacts against all 27 authentication-value hashes. Filesystem clones have independent inodes and share extents; this is local retention, not an independent-device backup.

The PR uses the preserved exact control branch `depatched/written-study-control-58baeaa`; the current baseline PR has advanced beyond the measured control. No actual readers, piloted stopping rule, verified identity/attention, observed preference or generated-quality improvement are established. Study infrastructure and bounded synthetic calibration do not complete the actual human-study requirement or establish merge readiness.
''')
    (TARGET/'publication-proof-index.json').write_text(json.dumps({'passed':True,'sourceCommit':MEASURED,'records':supplemental,'validationIndex':pin(TARGET/'validation-index.json'),'results':pin(TARGET/'RESULTS.md'),'independent':pin(TARGET/'independent-verification.json'),'corruptions':pin(TARGET/'independent-corruptions.json'),'scope':'Final publication operators/outcomes; original V3 complete packet and altered copies remain retained locally.'},indent=2)+'\n')
    for file in sorted(SOURCE.rglob('*')):
        if file.is_file():assert pin(file)==pin(TARGET/file.relative_to(SOURCE))
    token_hashes=set(index['privateAuthentication']['tokenHashes'])
    files=[file for file in TARGET.rglob('*') if file.is_file()]+[DOC]
    for file in files:
        raw=file.read_bytes()
        if file.suffix=='.gz':raw=gzip.decompress(raw)
        assert not any(hashlib.sha256(match.group(1)).hexdigest() in token_hashes for match in re.finditer(rb'(?=([0-9a-f]{64}))',raw)),file
    names=sorted(file.relative_to(ROOT).as_posix() for file in files)
    subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
    actual=subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=ROOT).decode().split('\0')
    assert {name for name in actual if name}==set(names)
    for name,identity in index['sourcePins'].items():assert pin(ROOT/name)==identity,name
    result={'passed':True,'head':MEASURED,'files':len(names),'index':pin(TARGET/'validation-index.json'),'proofIndex':pin(TARGET/'publication-proof-index.json'),'docs':pin(DOC),'stagedPaths':names,'scope':'Only verified Q21 synthetic evidence and results documentation; runtime source unchanged and authentication values stay local.'}
    (OUT/'complete.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({key:value for key,value in result.items() if key!='stagedPaths'}))

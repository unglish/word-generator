"""Retain and reject altered complete Q21 publication packages."""
import gzip
import importlib.util
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
STAGE = Path('/private/tmp/q21-publication-stage-v4')
OUT = Path('/private/tmp/q21-publication-corruptions-v4')
MAIN = '/Users/ryanbetts/.codex/worktrees/d9c28566-8f5b-432e-a246-5e4070782624/word-generator/.local-evidence/'


def replace_report(root, index, origin, mutate, verifier):
    records = [record for record in index['records'] if record['origin'] == origin]
    assert records
    for record in records:
        path = root / record['path']
        encoded = path.read_bytes()
        raw = gzip.decompress(encoded) if record['compression'] == 'gzip' else encoded
        report = json.loads(raw)
        mutate(report)
        original = (json.dumps(report, indent=2) + '\n').encode()
        saved = gzip.compress(original, mtime=0) if record['compression'] == 'gzip' else original
        path.write_bytes(saved)
        record['saved'], record['original'] = verifier.pin_bytes(saved), verifier.pin_bytes(original)


if __name__ == '__main__':
    OUT.mkdir(mode=0o700)
    spec = importlib.util.spec_from_file_location('q21_verifier', HERE / 'verify.py')
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    results = []
    for name in ('wrong-gate-count', 'forged-native-exit', 'missing-original-dataset',
                 'false-mnar-success', 'corrupted-log-byte', 'credential-value-injection'):
        root = OUT / name
        shutil.copytree(STAGE, root)
        index = json.loads((root / 'validation-index.json').read_bytes())
        if name == 'wrong-gate-count':
            index['originalGateOutcomes']['commands'] = 27
        elif name == 'forged-native-exit':
            def mutate(report):
                next(row for row in report['results'] if row['name'] == 'native-pair-1-candidate')['code'] = 1
            replace_report(root, index, '/private/tmp/q21-original-gates-v3/complete.json', mutate, verifier)
        elif name == 'missing-original-dataset':
            def mutate(report):
                ordinal = next(i for i, record in enumerate(report['records'])
                               if record['original'].startswith('/private/tmp/q21-calibration-v1/')
                               and record['original'].endswith('-input.json.gz'))
                report['records'].pop(ordinal)
            replace_report(root, index, MAIN + 'blinded-written-study/full-calibration-retained-local-v1/index.json', mutate, verifier)
        elif name == 'false-mnar-success':
            def mutate(report):
                diagnostic = next(case for case in report['cases'] if case['scenario']['role'] == 'bias-diagnostic')
                diagnostic['decision']['includedInGate'] = True
                diagnostic['decision']['passed'] = True
            replace_report(root, index, '/private/tmp/q21-calibration-summary-v1/summary.json', mutate, verifier)
        elif name == 'credential-value-injection':
            record = next(record for record in index['records'] if record['origin'] == '/private/tmp/q21-original-gates-v3/original-candidate-unit.log')
            path = root / record['path']
            saved = path.read_bytes()
            original = gzip.decompress(saved) if record['compression'] == 'gzip' else saved
            token = json.loads(Path('/private/tmp/q21-collection-browser-v1/collection/credentials.json').read_bytes())['owner_token']
            original += ('\n' + token + '\n').encode()
            saved = gzip.compress(original, mtime=0) if record['compression'] == 'gzip' else original
            path.write_bytes(saved)
            record['saved'], record['original'] = verifier.pin_bytes(saved), verifier.pin_bytes(original)
        else:
            record = next(record for record in index['records']
                          if record['origin'] == '/private/tmp/q21-original-gates-v3/original-candidate-unit.log')
            path = root / record['path']
            path.write_bytes(path.read_bytes() + b'corrupted')
        (root / 'validation-index.json').write_text(json.dumps(index, indent=2) + '\n')
        try:
            verifier.verify(root)
        except (AssertionError, KeyError, ValueError, OSError) as error:
            results.append({'case': name, 'rejected': True, 'error': repr(error), 'preservedPackage': str(root)})
        else:
            raise AssertionError('Altered package accepted: ' + name)
    (OUT / 'complete.json').write_text(json.dumps({'passed': True, 'corruptions': len(results), 'results': results,
        'scope': 'Complete altered copies preserve all originals; incorrect counts, self-consistent altered native exit, missing raw dataset, false diagnostic success and corrupted bytes rejected.'}, indent=2) + '\n')
    print(json.dumps({'passed': True, 'corruptions': len(results)}))
